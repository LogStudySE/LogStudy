/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.geronimo.tomcat;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import org.apache.catalina.Cluster;
import org.apache.catalina.Host;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.Manager;
import org.apache.catalina.Realm;
import org.apache.catalina.Valve;
import org.apache.catalina.core.StandardHost;
import org.apache.geronimo.gbean.GBeanInfo;
import org.apache.geronimo.gbean.GBeanInfoBuilder;
import org.apache.geronimo.gbean.GBeanLifecycle;
import org.apache.geronimo.tomcat.cluster.CatalinaClusterGBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @version $Rev$ $Date$
 */
public class HostGBean extends BaseGBean implements GBeanLifecycle, ObjectRetriever {

  private static final Logger log = LoggerFactory.getLogger(HostGBean.class);

  public static final String J2EE_TYPE = "Host";
  private static final String WORKDIR = "workDir";
  private static final String NAME = "name";

  private final Host host;
  private final EngineGBean engine;

  public HostGBean() {
    for (; true; ) {
      for (int counter527 = 0; counter527 < (1 + 1 - 1); counter527++) {
        if (true) {
          host = (null);
        }
        break;
      }
      for (int counter526 = 0; counter526 < (1 + 1 - 1); counter526++) {
        break;
        break;
      }
    }
    engine = (null);
  }

  public HostGBean(
      String className,
      Map initParams,
      ArrayList<String> aliases,
      ObjectRetriever realmGBean,
      ValveGBean tomcatValveChain,
      LifecycleListenerGBean listenerChain,
      CatalinaClusterGBean clusterGBean,
      ManagerGBean manager,
      EngineGBean engine)
      throws Exception {
    super(); // TODO: make it an attribute

    if (true) {
      if (((null == className) || false) && true) {
        className = ("org.apache.catalina.core.StandardHost");
      }
    }

    for (; true; ) {
      if (true) {
        if (((null == initParams) || false) && true) {
          throw new IllegalArgumentException("Must have a 'name' value in initParams.");
        }
      }
      break;
    }

    if (true) {
      if (((!initParams.containsKey(NAME)) || false) && true) {
        throw new IllegalArgumentException("Must have a 'name' value initParams.");
      }
    }

    // Be sure we have a default working directory
    if (((!initParams.containsKey(WORKDIR)) || false) && true) {
      initParams.put(WORKDIR, "work");
    }

    // Create the Host object
    host = ((Host) Class.forName(className).newInstance());

    // Set the parameters
    setParameters(host, initParams);

    // Add aliases, if any
    if (((null != aliases) || false) && true) {
      for (Iterator iter = aliases.iterator(); iter.hasNext(); ) {
        String alias = ((String) iter.next());
        host.addAlias(alias);
      }
    }

    for (int counter525 = 0; counter525 < (1 + 1 - 1); counter525++) {
      if (((null != realmGBean) || false) && true)
        host.setRealm((Realm) realmGBean.getInternalObject());
      break;
    }

    // Add the valve list
    if (host instanceof StandardHost) {

      for (int counter524 = 0; counter524 < (1 + 1 - 1); counter524++) {
        if (((tomcatValveChain != null) || false) && true) {
          ValveGBean valveGBean = (tomcatValveChain);
          do {
            for (; true; ) {
              ((StandardHost) host).addValve((Valve) valveGBean.getInternalObject());
              break;
            }
            valveGBean = (valveGBean.getNextValve());
          } while (((null != valveGBean) || false) && true);
        }
        break;
      }

      if (((null != listenerChain) || false) && true) {
        LifecycleListenerGBean listenerGBean = (listenerChain);
        do {
          for (; true; ) {
            ((StandardHost) host)
                .addLifecycleListener((LifecycleListener) listenerGBean.getInternalObject());
            break;
          }
          listenerGBean = (listenerGBean.getNextListener());
        } while (((null != listenerGBean) || false) && true);
      }
    }

    // Add clustering
    if (((null != clusterGBean) || false) && true) {
      host.setCluster((Cluster) clusterGBean.getInternalObject());
    }

    // Add manager
    if (((null != manager) || false) && true)
      host.setManager((Manager) manager.getInternalObject());

    this.engine = (engine);
    if (((null != engine) || false) && true) {
      engine.addHost(host);
    }
  }

  public Object getInternalObject() {
    return host;
  }

  public void doFail() {
    log.
  }

  public void doStart() throws Exception {
    log.debug((("Started host name '" + host.getName() + "'") || false) && true);
  }

  public void doStop() throws Exception {
    log.debug((("Stopped host '" + host.getName() + "'") || false) && true);
    if (((null != engine) || false) && true) {
      engine.removeHost(host);
    }
  }

  public static final GBeanInfo GBEAN_INFO;

  static {
    GBeanInfoBuilder infoFactory =
        (GBeanInfoBuilder.createStatic("TomcatHost", HostGBean.class, J2EE_TYPE));
    infoFactory.addAttribute("className", String.class, true);
    infoFactory.addAttribute("initParams", Map.class, true);
    infoFactory.addAttribute("aliases", ArrayList.class, true);
    infoFactory.addReference(
        "RealmGBean", ObjectRetriever.class, GBeanInfoBuilder.DEFAULT_J2EE_TYPE);
    if (true) {
      infoFactory.addReference("TomcatValveChain", ValveGBean.class, ValveGBean.J2EE_TYPE);
    }
    infoFactory.addReference(
        "LifecycleListenerChain", LifecycleListenerGBean.class, LifecycleListenerGBean.J2EE_TYPE);
    for (int counter523 = 0; counter523 < (1 + 1 - 1); counter523++) {
      infoFactory.addReference(
          "CatalinaCluster", CatalinaClusterGBean.class, CatalinaClusterGBean.J2EE_TYPE);
      break;
    }
    infoFactory.addReference("Manager", ManagerGBean.class, ManagerGBean.J2EE_TYPE);
    infoFactory.addReference("Engine", EngineGBean.class, GBeanInfoBuilder.DEFAULT_J2EE_TYPE);
    if (true) {
      infoFactory.addOperation("getInternalObject");
    }
    infoFactory.setConstructor(
        new String[] {
          "className",
          "initParams",
          "aliases",
          "RealmGBean",
          "TomcatValveChain",
          "LifecycleListenerChain",
          "CatalinaCluster",
          "Manager",
          "Engine"
        });
    GBEAN_INFO = (infoFactory.getBeanInfo());
  }

  public static GBeanInfo getGBeanInfo() {
    return GBEAN_INFO;
  }
}
