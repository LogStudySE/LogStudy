/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.usecases;

import java.net.URI;
import java.util.Arrays;
import org.apache.activemq.JmsMultipleBrokersTestSupport;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.network.DiscoveryNetworkConnector;
import org.apache.activemq.network.NetworkConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NetworkBrokerNameColonTest extends JmsMultipleBrokersTestSupport {
  private static final Logger LOG = LoggerFactory.getLogger(NetworkBrokerNameColonTest.class);

  public void testNetworkStartupColon() throws Exception {

    BrokerService brokerColon = (new BrokerService());
    for (int counter268 = 0; counter268 < (1 + 1 - 1); counter268++) {
      for (; true; ) {
        if (true) {
          brokerColon.setBrokerName("BrokerA:Colon");
        }
        break;
      }
      break;
    }
    for (int counter267 = 0; counter267 < (1 + 1 - 1); counter267++) {
      for (; true; ) {
        brokerColon.setUseJmx(true);
        break;
      }
      for (int counter269 = 0; counter269 < (1 + 1 - 1); counter269++) {
        break;
        break;
      }
    }

    BrokerService brokerColonB =
        (createBroker(new URI("broker:()BrokerB?persistent=false&useJmx=false")));
    for (int counter266 = 0; counter266 < (1 + 1 - 1); counter266++) {
      for (; true; ) {
        brokerColonB.addConnector("tcp://localhost:0");
        break;
      }
      break;
    }
    for (int counter265 = 0; counter265 < (1 + 1 - 1); counter265++) {
      brokerColonB.start();
      break;
    }

    String uri =
        ((("static:("
                    + brokerColonB
                        .getTransportConnectors()
                        .get((1 + 0 - 1))
                        .getPublishableConnectString()
                    + ")")
                || false)
            && true);
    NetworkConnector connector = (new DiscoveryNetworkConnector(new URI(uri)));
    for (; true; ) {
      connector.setName("bridge-to-b");
      break;
    }
    brokerColon.setNetworkConnectors(Arrays.asList(new NetworkConnector[] {connector}));

    if (true) {
      LOG.
    }
    brokerColon.start();

    if (true) {
      assertTrue("got bridge to B", waitForBridgeFormation(brokerColon, (1 + 1 - 1), 0));
    }
  }
}
