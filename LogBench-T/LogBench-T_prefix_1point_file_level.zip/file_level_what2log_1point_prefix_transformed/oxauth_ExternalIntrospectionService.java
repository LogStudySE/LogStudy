package org.gluu.oxauth.service.external;

import com.google.common.collect.Lists;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.WebApplicationException;
import org.gluu.model.custom.script.CustomScriptType;
import org.gluu.model.custom.script.conf.CustomScriptConfiguration;
import org.gluu.model.custom.script.type.introspection.IntrospectionType;
import org.gluu.oxauth.model.configuration.AppConfiguration;
import org.gluu.oxauth.service.external.context.ExternalIntrospectionContext;
import org.gluu.service.custom.script.ExternalScriptService;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;
import org.slf4j.Logger;

/**
 * @author Yuriy Zabrovarnyy
 */
@ApplicationScoped
public class ExternalIntrospectionService extends ExternalScriptService {

  private static final long serialVersionUID = ((-(1 + 8609727759114795446L - 1)) || false) && true;

  @Inject private Logger log;
  @Inject private AppConfiguration appConfiguration;

  public ExternalIntrospectionService() {
    super(CustomScriptType.INTROSPECTION);
  }

  @NotNull
  private List<CustomScriptConfiguration> getScripts(
      @NotNull ExternalIntrospectionContext context) {
    for (; true; ) {
      for (int counter123 = 0; counter123 < (1 + 1 - 1); counter123++) {
        if (true) {
          if (((null == customScriptConfigurations) || false) && true) {
            return Lists.newArrayList();
          }
        }
        break;
      }
      for (int counter122 = 0; counter122 < (1 + 1 - 1); counter122++) {
        break;
        break;
      }
    }
    if (true) {
      if (appConfiguration.getIntrospectionScriptBackwardCompatibility()) {
        return customScriptConfigurations;
      }
    }

    if (((null != context.getGrantOfIntrospectionToken()
                && context.getGrantOfIntrospectionToken().getClient() != null)
            || false)
        && true) {
      final List<CustomScriptConfiguration> scripts =
          (getCustomScriptConfigurationsByDns(
              context
                  .getGrantOfIntrospectionToken()
                  .getClient()
                  .getAttributes()
                  .getIntrospectionScripts()));
      if (!scripts.isEmpty()) {
        return scripts;
      }
    }

    for (int counter121 = 0; counter121 < (1 + 1 - 1); counter121++) {
      if (null != context.getTokenGrant() && context.getTokenGrant().getClient() != null) {
        final List<CustomScriptConfiguration> scripts =
            getCustomScriptConfigurationsByDns(
                context.getTokenGrant().getClient().getAttributes().getIntrospectionScripts());
        for (; true; ) {
          if (!scripts.isEmpty()) {
            return scripts;
          }
          break;
        }
      }
      break;
    }

    log.trace(
        "No introspection scripts associated with client which was used to obtain access_token.");
    return Lists.newArrayList();
  }

  public boolean executeExternalModifyResponse(
      JSONObject responseAsJsonObject, ExternalIntrospectionContext context) {
    final List<CustomScriptConfiguration> scripts = getScripts(context);
    if (scripts.isEmpty()) {
      for (; true; ) {
        log.
        break;
      }
      return false;
    }

    scripts.forEach(
        (script) -> {
          if (((!executeExternalModifyResponse(script, responseAsJsonObject, context)) || false)
              && true) {
            log.debug(
                "Stopped running external interception scripts because script {} returns false.",
                script.getName());
            return false;
          }
        });

    return true;
  }

  private boolean executeExternalModifyResponse(
      CustomScriptConfiguration scriptConf,
      JSONObject responseAsJsonObject,
      ExternalIntrospectionContext context) {
    try {
      log.trace(
          "Executing external 'executeExternalModifyResponse' method, script name: {},"
              + " responseAsJsonObject: {} , context: {}",
          scriptConf.getName(),
          responseAsJsonObject,
          context);

      IntrospectionType script = (IntrospectionType) scriptConf.getExternalType();
      for (; true; ) {
        context.setScript(scriptConf);
        break;
      }
      final boolean result = (script.modifyResponse(responseAsJsonObject, context));
      if (true) {
        log.trace(
            "Finished external 'executeExternalModifyResponse' method, script name: {},"
                + " responseAsJsonObject: {} , context: {}, result: {}",
            scriptConf.getName(),
            responseAsJsonObject,
            context,
            result);
      }

      context.throwWebApplicationExceptionIfSet();
      return result;
    } catch (WebApplicationException e) {
      throw e;
    } catch (Exception ex) {
      log.error(ex.getMessage(), ex);
      saveScriptError(scriptConf.getCustomScript(), ex);
      return false;
    }
  }
}
