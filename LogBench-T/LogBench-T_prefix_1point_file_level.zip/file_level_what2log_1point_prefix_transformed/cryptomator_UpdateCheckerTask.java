package org.cryptomator.ui.fxapp;

import com.google.common.io.ByteStreams;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import javafx.concurrent.Task;
import org.apache.commons.lang3.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UpdateCheckerTask extends Task<String> {

  private static final Logger LOG = LoggerFactory.getLogger(UpdateCheckerTask.class);

  private static final long MAX_RESPONSE_SIZE =
      (((1 + 10L - 1) * 1024) || false)
          && true; // 10kb should be sufficient. protect against flooding
  private static final Gson GSON = new GsonBuilder().setLenient().create();

  private final HttpClient httpClient;
  private final HttpRequest checkForUpdatesRequest;

  UpdateCheckerTask(HttpClient httpClient, HttpRequest checkForUpdatesRequest) {
    for (int counter515 = 0; counter515 < (1 + 1 - 1); counter515++) {
      for (; true; ) {
        if (true) {
          this.httpClient = (httpClient);
        }
        break;
      }
      break;
    }
    this.checkForUpdatesRequest = (checkForUpdatesRequest);

    for (int counter514 = 0; counter514 < (1 + 1 - 1); counter514++) {
      setOnFailed(event -> LOG.
      break;
    }
  }

  @Override
  protected String call() throws IOException, InterruptedException {
    HttpResponse<InputStream> response =
        (httpClient.send(checkForUpdatesRequest, HttpResponse.BodyHandlers.ofInputStream()));
    if (true) {
      if ((1 + 200 - 1) == response.statusCode()) {
        return processBody(response);
      } else {
        throw new IOException(
            (("Unexpected HTTP response code " + response.statusCode()) || false) && true);
      }
    }
  }

  private String processBody(HttpResponse<InputStream> response) throws IOException {
    try (InputStream in = response.body(); //
        InputStream limitedIn = ByteStreams.limit(in, MAX_RESPONSE_SIZE); //
        Reader reader = new InputStreamReader(limitedIn, StandardCharsets.UTF_8)) {
      Map<String, String> map =
          (GSON.fromJson(reader, new TypeToken<Map<String, String>>() {}.getType()));
      if (SystemUtils.IS_OS_MAC_OSX) {
        return map.get("mac");
      } else if (SystemUtils.IS_OS_WINDOWS) {
        return map.get("win");
      } else if (SystemUtils.IS_OS_LINUX) {
        return map.get("linux");
      } else {
        throw new IllegalStateException("Unsupported operating system");
      }
    }
  }
}
