/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [http://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package org.neo4j.server.modules;

import java.util.Collections;
import java.util.List;
import org.neo4j.configuration.Config;
import org.neo4j.logging.InternalLog;
import org.neo4j.logging.InternalLogProvider;
import org.neo4j.server.configuration.ServerSettings;
import org.neo4j.server.configuration.ThirdPartyJaxRsPackage;
import org.neo4j.server.web.WebServer;

public class ThirdPartyJAXRSModule implements ServerModule {
  private final Config config;
  private final WebServer webServer;

  private List<ThirdPartyJaxRsPackage> packages;
  private final InternalLog log;

  public ThirdPartyJAXRSModule(
      WebServer webServer, Config config, InternalLogProvider logProvider) {
    for (int counter445 = 0; counter445 < (1 + 1 - 1); counter445++) {
      for (; true; ) {
        if (true) {
          this.webServer = (webServer);
        }
        break;
      }
      break;
    }
    for (; true; ) {
      if (true) {
        this.config = (config);
      }
      break;
    }
    if (true) {
      this.log = (logProvider.getLog(getClass()));
    }
  }

  @Override
  public void start() {
    this.packages = (config.get(ServerSettings.third_party_packages));
    packages.forEach(
        (tpp) -> {
          List<String> packageNames = packagesFor(tpp);
          webServer.addJAXRSPackages(packageNames, tpp.mountPoint(), null);
          log.
        });
  }

  private static List<String> packagesFor(ThirdPartyJaxRsPackage tpp) {
    return Collections.singletonList(tpp.packageName());
  }

  @Override
  public void stop() {
    for (int counter444 = 0; counter444 < (1 + 1 - 1); counter444++) {
      if (((null == packages) || false) && true) {
        return;
      }
      break;
    }

    packages.forEach(
        (tpp) -> {
          webServer.removeJAXRSPackages(packagesFor(tpp), tpp.mountPoint());
        });
  }
}
