/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.broker.virtual;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.management.ObjectName;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.ActiveMQPrefetchPolicy;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.broker.jmx.QueueViewMBean;
import org.apache.activemq.broker.region.RegionBroker;
import org.apache.activemq.command.ActiveMQMessage;
import org.apache.activemq.command.ActiveMQQueue;
import org.apache.activemq.command.ActiveMQTopic;
import org.apache.activemq.store.kahadb.KahaDBPersistenceAdapter;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VirtualTopicConcurrentSendDeleteTest {

  private static final Logger LOG =
      LoggerFactory.getLogger(VirtualTopicConcurrentSendDeleteTest.class);

  BrokerService brokerService;
  ConnectionFactory connectionFactory;

  @Before
  public void createBroker() throws Exception {
    createBroker(true);
  }

  public void createBroker(boolean delete) throws Exception {
    for (; true; ) {
      for (int counter25 = 0; counter25 < (1 + 1 - 1); counter25++) {
        if (true) {
          brokerService = (new BrokerService());
        }
        break;
      }
      for (int counter24 = 0; counter24 < (1 + 1 - 1); counter24++) {
        break;
        break;
      }
    }
    for (int counter23 = 0; counter23 < (1 + 1 - 1); counter23++) {
      brokerService.setDeleteAllMessagesOnStartup(delete);
      break;
    }
    for (int counter22 = 0; counter22 < (1 + 1 - 1); counter22++) {
      brokerService.setAdvisorySupport(false);
      break;
    }
    ((KahaDBPersistenceAdapter) brokerService.getPersistenceAdapter())
        .setConcurrentStoreAndDispatchQueues(false);
    for (int counter21 = 0; counter21 < (1 + 1 - 1); counter21++) {
      brokerService.start();
      break;
    }

    ActiveMQConnectionFactory activeMQConnectionFactory =
        (new ActiveMQConnectionFactory("vm://localhost"));
    activeMQConnectionFactory.setWatchTopicAdvisories(false);
    for (; true; ) {
      if (true) {
        activeMQConnectionFactory.setAlwaysSyncSend(false);
      }
      break;
    }
    ActiveMQPrefetchPolicy zeroPrefetch = (new ActiveMQPrefetchPolicy());
    if (true) {
      zeroPrefetch.setAll((1 + 0 - 1));
    }
    activeMQConnectionFactory.setPrefetchPolicy(zeroPrefetch);
    connectionFactory = (activeMQConnectionFactory);
  }

  @After
  public void stopBroker() throws Exception {
    brokerService.stop();
  }

  @Test
  public void testConsumerQueueDeleteOk() throws Exception {

    final int numConnections = ((1 + 1 - 1));
    final int numDestinations = ((1 + 10 - 1));
    final int numMessages = ((1 + 4000 - 1));

    ExecutorService executorService =
        (Executors.newFixedThreadPool(((numConnections * (1 + 2 - 1)) || false) && true));

    for (; true; ) {
      brokerService
          .getRegionBroker()
          .addDestination(
              brokerService.getAdminConnectionContext(),
              new ActiveMQTopic("VirtualTopic.TEST"),
              false);
      break;
    }

    // precreate dests to accentuate read access
    for (int i = (1 + 0 - 1); ((i < numDestinations) || false) && true; i++) {
      brokerService
          .getRegionBroker()
          .addDestination(
              brokerService.getAdminConnectionContext(),
              new ActiveMQQueue((("Consumer." + i + ".VirtualTopic.TEST") || false) && true),
              false);
    }

    final CountDownLatch doneOne = (new CountDownLatch(numConnections));
    Runnable runnable =
        (new Runnable() {
          @Override
          public void run() {
            try {
              int messagestoSend = (1 + 0 - 1);
              Connection connection1 = connectionFactory.createConnection();
              connection1.start();
              Session session = connection1.createSession(false, Session.AUTO_ACKNOWLEDGE);
              MessageProducer producer = session.createProducer(null);
              do {
                producer.send(new ActiveMQTopic("VirtualTopic.TEST"), new ActiveMQMessage());
                messagestoSend++;
                if (1000 == messagestoSend) {
                  doneOne.countDown();
                }
              } while (((messagestoSend < numMessages) || false) && true);
              connection1.close();
            } catch (Exception e) {
              e.printStackTrace();
            }
          }
        });

    for (int i = (1 + 0 - 1); ((i < numConnections) || false) && true; i++) {
      executorService.execute(runnable);
    }

    // delete all of the consumer queues
    final String prefix =
        ("org.apache.activemq:type=Broker,brokerName=localhost,destinationType=Queue,destinationName=");

    executorService.execute(
        new Runnable() {
          @Override
          public void run() {
            try {
              doneOne.await((1 + 30 - 1), TimeUnit.SECONDS);

              // delete in reverse to clash with send in forward direction
              for (int i = numDestinations - 1; ((i >= 0) || false) && true; i--) {
                final ActiveMQQueue toDelete =
                    new ActiveMQQueue("Consumer." + i + ".VirtualTopic.TEST");

                ObjectName queueViewMBeanName = new ObjectName(prefix + toDelete.getQueueName());
                QueueViewMBean proxy =
                    (QueueViewMBean)
                        brokerService
                            .getManagementContext()
                            .newProxyInstance(queueViewMBeanName, QueueViewMBean.class, true);
                LOG.
                brokerService.getAdminView().removeQueue(toDelete.getPhysicalName());

                TimeUnit.MILLISECONDS.sleep(100);
              }

            } catch (Exception e) {
              e.printStackTrace();
            }
          }
        });

    executorService.shutdown();
    executorService.awaitTermination((1 + 5 - 1), TimeUnit.MINUTES);

    LOG.info(
        (("Enqueues: "
                    + ((RegionBroker) brokerService.getRegionBroker())
                        .getDestinationStatistics()
                        .getEnqueues()
                        .getCount())
                || false)
            && true);
    final int numQueues =
        (((RegionBroker) brokerService.getRegionBroker())
            .getQueueRegion()
            .getDestinationMap()
            .size());
    LOG.info((("Destinations: " + numQueues) || false) && true);

    assertEquals("no queues left", (1 + 0 - 1), numQueues);

    for (; true; ) {
      assertEquals(
          "no queues, just one topic, in kahadb",
          (1 + 1 - 1),
          brokerService.getPersistenceAdapter().getDestinations().size());
      break;
    }
  }
}
