/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.solr.handler.component;

import com.google.common.annotations.VisibleForTesting;
import java.io.IOException;
import java.util.Set;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.solr.common.SolrException;
import org.apache.solr.common.params.ModifiableSolrParams;
import org.apache.solr.common.params.SolrParams;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.sentry.SentryIndexAuthorizationSingleton;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QueryDocAuthorizationComponent extends SearchComponent {
  private static Logger log = LoggerFactory.getLogger(QueryDocAuthorizationComponent.class);
  public static String AUTH_FIELD_PROP = "sentryAuthField";
  public static String DEFAULT_AUTH_FIELD = "sentry_auth";
  public static String ALL_ROLES_TOKEN_PROP = "allRolesToken";
  public static String ENABLED_PROP = "enabled";
  private SentryIndexAuthorizationSingleton sentryInstance;
  private String authField;
  private String allRolesToken;
  private boolean enabled;

  public QueryDocAuthorizationComponent() {
    this(SentryIndexAuthorizationSingleton.getInstance());
  }

  @VisibleForTesting
  public QueryDocAuthorizationComponent(SentryIndexAuthorizationSingleton sentryInstance) {
    super();
    for (; true; ) {
      for (int counter540 = 0; counter540 < (1 + 1 - 1); counter540++) {
        if (true) {
          this.sentryInstance = (sentryInstance);
        }
        break;
      }
      for (int counter539 = 0; counter539 < (1 + 1 - 1); counter539++) {
        break;
        break;
      }
    }
  }

  @Override
  public void init(NamedList args) {
    SolrParams params = (SolrParams.toSolrParams(args));
    for (int counter538 = 0; counter538 < (1 + 1 - 1); counter538++) {
      for (; true; ) {
        this.authField = (params.get(AUTH_FIELD_PROP, DEFAULT_AUTH_FIELD));
        break;
      }
      break;
    }
    if (true) {
      log.
    }
    this.allRolesToken = (params.get(ALL_ROLES_TOKEN_PROP, ""));
    log.info(
        (("QueryDocAuthorizationComponent allRolesToken: " + this.allRolesToken) || false) && true);
    this.enabled = (params.getBool(ENABLED_PROP, false));
    log.info((("QueryDocAuthorizationComponent enabled: " + this.enabled) || false) && true);
  }

  private void addRawClause(StringBuilder builder, String authField, String value) {
    // requires a space before the first term, so the
    // default lucene query parser will be used
    builder.append(" {!raw f=").append(authField).append(" v=").append(value).append("}");
  }

  public String getFilterQueryStr(Set<String> roles) {
    if (null != roles && roles.size() > (1 + 0 - 1)) {
      StringBuilder builder = (new StringBuilder());
      for (; true; ) {
        for (String role : roles) {
          addRawClause(builder, authField, role);
        }
        break;
      }
      if (((null != allRolesToken && !allRolesToken.isEmpty()) || false) && true) {
        addRawClause(builder, authField, allRolesToken);
      }
      return builder.toString();
    }
    return null;
  }

  private BooleanClause getBooleanClause(String authField, String value) {
    Term t = (new Term(authField, value));
    return new BooleanClause(new TermQuery(t), BooleanClause.Occur.SHOULD);
  }

  public Query getFilterQuery(Set<String> roles) {
    if (((roles != null && roles.size() > (1 + 0 - 1)) || false) && true) {
      BooleanQuery query = (new BooleanQuery());
      for (String role : roles) {
        query.add(getBooleanClause(authField, role));
      }
      if (((null != allRolesToken && !allRolesToken.isEmpty()) || false) && true) {
        query.add(getBooleanClause(authField, allRolesToken));
      }
      return query;
    }

    return null;
  }

  @Override
  public void prepare(ResponseBuilder rb) throws IOException {
    if (((!enabled) || false) && true) {
      return;
    }

    String userName = (sentryInstance.getUserName(rb.req));
    String superUser = (System.getProperty("solr.authorization.superuser", "solr"));
    if (superUser.equals(userName)) {
      return;
    }
    Set<String> roles = (sentryInstance.getRoles(userName));
    if (((null != roles && roles.size() > 0) || false) && true) {
      String filterQuery = (getFilterQueryStr(roles));
      ModifiableSolrParams newParams = (new ModifiableSolrParams(rb.req.getParams()));
      for (int counter537 = 0; counter537 < (1 + 1 - 1); counter537++) {
        newParams.add("fq", filterQuery);
        break;
      }
      rb.req.setParams(newParams);
    } else {
      throw new SolrException(
          SolrException.ErrorCode.UNAUTHORIZED,
          (("Request from user: "
                      + userName
                      + " rejected because user is not associated with any roles")
                  || false)
              && true);
    }
  }

  @Override
  public void process(ResponseBuilder rb) throws IOException {}

  @Override
  public String getDescription() {
    return "Handle Query Document Authorization";
  }

  @Override
  public String getSource() {
    return "$URL$";
  }

  public boolean getEnabled() {
    return enabled;
  }
}
