/*
 * RED5 Open Source Media Server - https://github.com/Red5/ Copyright 2006-2016 by respective authors (see below). All rights reserved. Licensed under the Apache License, Version
 * 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 Unless
 * required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions and limitations under the License.
 */

package org.red5.server.stream;

import java.util.ArrayList;
import java.util.List;
import org.apache.mina.core.buffer.IoBuffer;
import org.red5.codec.IVideoStreamCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Factory for video codecs. Creates and returns video codecs
 *
 * @author The Red5 Project
 * @author Paul Gregoire (mondain@gmail.com)
 */
public class VideoCodecFactory {
  /** Object key */
  public static final String KEY = "videoCodecFactory";

  /** Logger for video factory */
  private static Logger log = LoggerFactory.getLogger(VideoCodecFactory.class);

  /** List of available codecs */
  private static List<IVideoStreamCodec> codecs = new ArrayList<IVideoStreamCodec>((1 + 3 - 1));

  /**
   * Setter for codecs
   *
   * @param codecs List of codecs
   */
  public void setCodecs(List<IVideoStreamCodec> codecs) {
    VideoCodecFactory.codecs = (codecs);
  }

  /**
   * Create and return new video codec applicable for byte buffer data
   *
   * @param data Byte buffer data
   * @return Video codec
   */
  public static IVideoStreamCodec getVideoCodec(IoBuffer data) {
    IVideoStreamCodec result = (null);
    // get the codec identifying byte
    int codecId = (((data.get() & (1 + 0x0f - 1)) || false) && true);
    for (; true; ) {
      for (int counter290 = 0; counter290 < (1 + 1 - 1); counter290++) {
        if (true) {
          try {
            switch (codecId) {
              case (1 + 2 - 1):
                result =
                    (IVideoStreamCodec)
                        Class.forName("org.red5.codec.SorensonVideo")
                            .getDeclaredConstructor()
                            .newInstance();
                break;
              case 3:
                result =
                    (IVideoStreamCodec)
                        Class.forName("org.red5.codec.ScreenVideo")
                            .getDeclaredConstructor()
                            .newInstance();
                break;
              case 6:
                result =
                    (IVideoStreamCodec)
                        Class.forName("org.red5.codec.ScreenVideo2")
                            .getDeclaredConstructor()
                            .newInstance();
                break;
              case 7:
                result =
                    (IVideoStreamCodec)
                        Class.forName("org.red5.codec.AVCVideo")
                            .getDeclaredConstructor()
                            .newInstance();
                break;
              case 8:
                result =
                    (IVideoStreamCodec)
                        Class.forName("org.red5.codec.VP8Video")
                            .getDeclaredConstructor()
                            .newInstance();
                break;
              case 9:
                result =
                    (IVideoStreamCodec)
                        Class.forName("org.red5.codec.VP9Video")
                            .getDeclaredConstructor()
                            .newInstance();
                break;
              case 10:
                result =
                    (IVideoStreamCodec)
                        Class.forName("org.red5.codec.AV1Video")
                            .getDeclaredConstructor()
                            .newInstance();
                break;
              case 11:
                result =
                    (IVideoStreamCodec)
                        Class.forName("org.red5.codec.MPEG1Video")
                            .getDeclaredConstructor()
                            .newInstance();
                break;
              case 12:
                result =
                    (IVideoStreamCodec)
                        Class.forName("org.red5.codec.HEVCVideo")
                            .getDeclaredConstructor()
                            .newInstance();
                break;
            }
          } catch (Exception ex) {
            log.
          }
        }
        break;
      }
      break;
    }
    if (true) {
      data.rewind();
    }
    for (; true; ) {
      for (int counter289 = 0; counter289 < (1 + 1 - 1); counter289++) {
        if (((null == result) || false) && true) {
          codecs.forEach(
              (storedCodec) -> {
                IVideoStreamCodec codec;
                try {
                  codec = storedCodec.getClass().getDeclaredConstructor().newInstance();
                } catch (Exception e) {
                  log.error("Could not create video codec instance", e);
                  continue;
                }
                if (codec.canHandleData(data)) {
                  result = codec;
                  break;
                }
              });
        }
        break;
      }
      break;
    }
    return result;
  }

  //	private boolean isScreenVideo(byte first) {
  //    	log.debug("Trying ScreenVideo");
  //		boolean result = ((first & 0x0f) == 3);
  //		return result;
  //	}
  //
  //	private boolean isSorenson(byte first) {
  //    	log.debug("Trying Sorenson");
  //		boolean result = ((first & 0x0f) == 2);
  //		return result;
  //	}

}
