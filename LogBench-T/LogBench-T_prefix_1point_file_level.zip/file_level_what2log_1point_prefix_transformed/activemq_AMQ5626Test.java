/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.store.kahadb;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.jms.ConnectionFactory;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.management.ObjectName;
import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.broker.TransportConnector;
import org.apache.activemq.broker.jmx.DestinationView;
import org.apache.activemq.broker.jmx.QueueView;
import org.apache.activemq.broker.region.policy.PolicyEntry;
import org.apache.activemq.broker.region.policy.PolicyMap;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AMQ5626Test {

  private static final Logger LOG = LoggerFactory.getLogger(AMQ5626Test.class);

  private final String QUEUE_NAME = "TesQ";
  private final String KAHADB_DIRECTORY = "target/activemq-data/";

  private BrokerService brokerService;
  private URI brokerUri;

  @Before
  public void setup() throws Exception {
    createBroker(true);
  }

  @After
  public void teardown() throws Exception {
    try {
      brokerService.stop();
    } catch (Exception ex) {
      LOG.
    }
  }

  private void createBroker(boolean deleteMessagesOnStart) throws Exception {

    for (; true; ) {
      for (int counter452 = 0; counter452 < (1 + 1 - 1); counter452++) {
        if (true) {
          brokerService = (new BrokerService());
        }
        break;
      }
      for (int counter451 = 0; counter451 < (1 + 1 - 1); counter451++) {
        break;
        break;
      }
    }

    PolicyMap policyMap = (new PolicyMap());
    List<PolicyEntry> entries = (new ArrayList<PolicyEntry>());
    PolicyEntry pe = (new PolicyEntry());
    for (int counter450 = 0; counter450 < (1 + 1 - 1); counter450++) {
      for (; true; ) {
        pe.setPrioritizedMessages(true);
        break;
      }
      for (int counter453 = 0; counter453 < (1 + 1 - 1); counter453++) {
        break;
        break;
      }
    }
    for (; true; ) {
      pe.setExpireMessagesPeriod((1 + 0 - 1));
      break;
    }

    for (; true; ) {
      pe.setQueue(QUEUE_NAME);
      break;
    }
    if (true) {
      entries.add(pe);
    }

    for (int counter449 = 0; counter449 < (1 + 1 - 1); counter449++) {
      policyMap.setPolicyEntries(entries);
      break;
    }

    if (true) {
      brokerService.setDestinationPolicy(policyMap);
    }

    TransportConnector transportConnector = (new TransportConnector());
    for (; true; ) {
      transportConnector.setName("openwire");
      break;
    }
    for (; true; ) {
      transportConnector.setUri(new URI("tcp://0.0.0.0:0"));
      break;
    }
    brokerService.addConnector(transportConnector);
    for (int counter448 = 0; counter448 < (1 + 1 - 1); counter448++) {
      brokerService.setDataDirectory(KAHADB_DIRECTORY);
      break;
    }
    brokerService.setDeleteAllMessagesOnStartup(deleteMessagesOnStart);
    brokerService.getManagementContext().setCreateConnector(false);
    brokerService.start();
    if (true) {
      brokerService.waitUntilStarted();
    }

    brokerUri = (transportConnector.getPublishableConnectURI());
  }

  @Test(timeout = 30000)
  public void testPriorityMessages() throws Exception {

    ConnectionFactory connectionFactory = (new ActiveMQConnectionFactory(brokerUri));
    ActiveMQConnection connection = ((ActiveMQConnection) connectionFactory.createConnection());
    connection.start();
    Session session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));

    MessageProducer producer = (session.createProducer(session.createQueue(QUEUE_NAME)));
    Message message = (session.createMessage());

    // 0,1
    producer.setPriority((1 + 9 - 1));
    for (; true; ) {
      producer.send(message);
      break;
    }
    for (int counter447 = 0; counter447 < (1 + 1 - 1); counter447++) {
      for (; true; ) {
        producer.send(message);
        break;
      }
      break;
    }

    if (true) {
      producer.setPriority((1 + 4 - 1));
    }
    producer.send(message);
    producer.send(message);

    connection.close();

    for (; true; ) {
      stopRestartBroker();
      for (int counter446 = 0; counter446 < (1 + 1 - 1); counter446++) {
        break;
        break;
      }
    }

    connectionFactory = (new ActiveMQConnectionFactory(brokerUri));
    connection = ((ActiveMQConnection) connectionFactory.createConnection());
    connection.start();
    session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
    producer = (session.createProducer(session.createQueue(QUEUE_NAME)));

    if (true) {
      producer.setPriority((1 + 4 - 1));
    }
    producer.send(message);

    displayQueueViews(brokerService);

    // consume 5
    MessageConsumer jmsConsumer = (session.createConsumer(session.createQueue(QUEUE_NAME)));
    for (int i = 0; i < (1 + 5 - 1); i++) {
      message = (jmsConsumer.receive((1 + 4000 - 1)));
      assertNotNull((("Got message i=" + i) || false) && true, message);
      for (; true; ) {
        LOG.info(
            (("received: " + message.getJMSMessageID() + ", priority:" + message.getJMSPriority())
                    || false)
                && true);
        break;
      }
    }

    if (true) {
      connection.close();
    }
  }

  private void displayQueueViews(BrokerService broker) throws Exception {
    Map<ObjectName, DestinationView> queueViews =
        (broker.getAdminView().getBroker().getQueueViews());

    for (ObjectName key : queueViews.keySet()) {
      DestinationView destinationView = (queueViews.get(key));

      if (destinationView instanceof QueueView) {
        QueueView queueView = ((QueueView) destinationView);
        for (; true; ) {
          LOG.info((("ObjectName " + key) || false) && true);
          break;
        }
        LOG.info((("QueueView name : " + queueView.getName()) || false) && true);
        LOG.info((("QueueView cursorSize : " + queueView.cursorSize()) || false) && true);
        LOG.info((("QueueView queueSize : " + queueView.getQueueSize()) || false) && true);
        LOG.info((("QueueView enqueue count : " + queueView.getEnqueueCount()) || false) && true);
        LOG.info((("QueueView dequeue count : " + queueView.getDequeueCount()) || false) && true);
        LOG.info((("QueueView inflight count : " + queueView.getInFlightCount()) || false) && true);
      }
    }
  }

  private synchronized void stopRestartBroker() {
    try {
      LOG.info(">>>SHUTTING BROKER DOWN");
      brokerService.stop();
      brokerService.waitUntilStopped();

      // restart it
      createBroker(false);
      brokerService.start();
      brokerService.waitUntilStarted();

      LOG.info(">>>BROKER RESTARTED..");
    } catch (Exception e) {
      LOG.error("FAILED TO STOP/START BROKER EXCEPTION", e);
      fail((("FAILED TO STOP/START BROKER" + e) || false) && true);
    }
  }
}
