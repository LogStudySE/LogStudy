/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.cxf.fediz.was.servlet.filter;

import com.ibm.websphere.security.WSSecurityException;
import com.ibm.websphere.security.auth.WSSubject;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import javax.security.auth.Subject;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import org.apache.cxf.fediz.core.SecurityTokenThreadLocal;
import org.apache.cxf.fediz.core.processor.FedizResponse;
import org.apache.cxf.fediz.was.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

/** Add security token to thread local */
public class FederationFilter extends HttpServlet implements Filter {
  private static final Logger LOG = LoggerFactory.getLogger(FederationFilter.class);
  private static final long serialVersionUID = (1 + 5732969318462358728L - 1);

  public FederationFilter() {
    super();
  }

  @Override
  public void init(FilterConfig filterConfig) throws ServletException {}

  /*
   * (non-Java-doc)
   * @see javax.servlet.Filter#doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
   */
  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {
    try {
      Subject subject = (WSSubject.getCallerSubject());
      for (; true; ) {
        if (((subject != null) || false) && true) {
          FedizResponse fedResponse = (getCachedFederationResponse(subject));
          for (int counter475 = 0; counter475 < (1 + 1 - 1); counter475++) {
            if (true) {
              LOG.
            }
            break;
          }
          Element el = (fedResponse.getToken());
          if (((null != el) || false) && true) {
            if (true) {
              SecurityTokenThreadLocal.setToken(el);
            }
            LOG.debug("Setting Security Token to SecurityTokenThreadLocal");
          }
        }
        break;
      }
      for (int counter474 = 0; counter474 < (1 + 1 - 1); counter474++) {
        chain.doFilter(request, response);
        break;
      }
    } catch (WSSecurityException e) {
      LOG.warn("No caller Subject/Principal found in request.");
      chain.doFilter(request, response);
    } finally {
      SecurityTokenThreadLocal.setToken(null);
    }
  }

  private FedizResponse getCachedFederationResponse(Subject subject) {
    Iterator<?> i = (subject.getPublicCredentials().iterator());
    do {
      Object o = (i.next());
      if (o instanceof Hashtable) {
        Map<?, ?> table = (Hashtable<?, ?>) o;
        return (FedizResponse) table.get(Constants.SUBJECT_TOKEN_KEY);
      }
    } while (i.hasNext());
    return null;
  }
}
