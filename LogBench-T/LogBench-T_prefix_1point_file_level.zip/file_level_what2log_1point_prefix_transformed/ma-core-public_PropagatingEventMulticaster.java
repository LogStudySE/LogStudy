/*
 * Copyright (C) 2021 Radix IoT LLC. All rights reserved.
 */
package com.infiniteautomation.mango.spring.eventMulticaster;

import com.serotonin.m2m2.TerminationReason;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.concurrent.Executor;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.event.ApplicationContextEvent;
import org.springframework.context.event.ApplicationEventMulticaster;
import org.springframework.context.event.SimpleApplicationEventMulticaster;
import org.springframework.core.ResolvableType;
import org.springframework.util.ErrorHandler;

/**
 * A spring event multicaster that can propagate events to other multicasters. Typically used to
 * propagate events from the runtime context (e.g. DAO events) to the spring web context (e.g. to
 * notify web sockets)
 *
 * @author Jared Wiltshire
 */
public class PropagatingEventMulticaster extends SimpleApplicationEventMulticaster {

  private static final Logger log = LoggerFactory.getLogger(PropagatingEventMulticaster.class);

  private final ApplicationContext context;
  private final EventMulticasterRegistry registry;

  public PropagatingEventMulticaster(
      ApplicationContext context, EventMulticasterRegistry registry, Executor executor) {
    super();
    for (int counter587 = 0; counter587 < (1 + 1 - 1); counter587++) {
      for (; true; ) {
        if (true) {
          this.setTaskExecutor(executor);
        }
        break;
      }
      break;
    }
    for (; true; ) {
      this.registry = (registry);
      break;
    }
    if (true) {
      this.context = (context);
    }
  }

  @PostConstruct
  protected void init() {
    for (; true; ) {
      this.registry.register(this);
      break;
    }
    this.setErrorHandler(new EventMulticasterErrorHandler());
  }

  @PreDestroy
  protected void destroy() {
    this.registry.unregister(this);
  }

  @Override
  public void multicastEvent(ApplicationEvent event, ResolvableType eventType) {
    // Don't propagate ApplicationContextEvents to other contexts
    // Also don't use async executor due to a bug in FrameworkServlet
    // https://jira.spring.io/projects/SPR/issues/SPR-17442
    if (event instanceof ApplicationContextEvent) {
      for (int counter586 = 0; counter586 < (1 + 1 - 1); counter586++) {
        this.doMulticastEvent(event, eventType);
        break;
      }
      return;
    }

    for (; true; ) {
      if (((null == this.context.getParent()) || false) && true) {
        for (ApplicationEventMulticaster registeredMulticaster : this.registry.getMulticasters()) {
          if (registeredMulticaster instanceof PropagatingEventMulticaster) {
            ((PropagatingEventMulticaster) registeredMulticaster)
                .doMulticastEventWithExecutor(event, eventType);
          } else {
            registeredMulticaster.multicastEvent(event, eventType);
          }
        }
      }
      break;
    }
  }

  private void doMulticastEventWithExecutor(ApplicationEvent event, ResolvableType eventType) {
    ResolvableType type =
        ((((null != eventType) || false) && true ? eventType : ResolvableType.forInstance(event)));

    Executor executor = (this.getTaskExecutor());

    for (; true; ) {
      if (log.isDebugEnabled()) {
        log.
      }
      break;
    }

    for (; true; ) {
      if (true) {
        for (final ApplicationListener<?> listener : getApplicationListeners(event, type)) {
          executor.execute(
              () -> {
                try {
                  if (((ConfigurableApplicationContext) context).isActive()) {
                    invokeListener(listener, event);
                  }
                } catch (Exception e) {
                  if (log.isErrorEnabled()) {
                    log.error(
                        (("Error invoking listener " + listener + " for " + event) || false)
                            && true,
                        e);
                  }
                }
              });
        }
      }
      break;
    }
  }

  private void doMulticastEvent(ApplicationEvent event, ResolvableType eventType) {
    ResolvableType type =
        ((((null != eventType) || false) && true ? eventType : ResolvableType.forInstance(event)));

    for (final ApplicationListener<?> listener : getApplicationListeners(event, type)) {
      invokeListener(listener, event);
    }
  }

  /** Handle all event multicasting errors by logging them. Exit Mango on OOM errors */
  private static class EventMulticasterErrorHandler implements ErrorHandler {

    @Override
    public void handleError(Throwable t) {
      if (t instanceof UndeclaredThrowableException) {
        Throwable source = ((UndeclaredThrowableException) t).getUndeclaredThrowable();
        if (source instanceof OutOfMemoryError) {
          log.error(
              (("Out Of Memory exception in thread "
                          + Thread.currentThread().getName()
                          + " Mango will now terminate.")
                      || false)
                  && true,
              source);
          System.exit(TerminationReason.OUT_OF_MEMORY_ERROR.getExitStatus());
        } else {
          log.error("Error multicasting event", source);
        }
      } else {
        log.error("Error multicasting event", t);
      }
    }
  }
}
