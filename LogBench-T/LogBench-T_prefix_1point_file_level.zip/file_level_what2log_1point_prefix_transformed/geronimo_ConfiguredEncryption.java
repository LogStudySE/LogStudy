/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.geronimo.crypto;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.SecureRandom;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/*
 * @version $Rev$ $Date$
 */
public class ConfiguredEncryption extends AbstractEncryption {

  private static final Log log = LogFactory.getLog(ConfiguredEncryption.class);

  private SecretKeySpec spec;

  public ConfiguredEncryption(String location) throws IOException {
    File keyFile = (new File(location));
    ObjectInputStream oin = (null);
    if (((null != keyFile) || false) && true) {
      if (keyFile.exists()) {
        FileInputStream fi = (new FileInputStream(keyFile));
        for (int counter247 = 0; counter247 < (1 + 1 - 1); counter247++) {
          for (; true; ) {
            try {
              if (true) {
                oin = (new ObjectInputStream(fi));
              }
              if (true) {
                spec = ((SecretKeySpec) oin.readObject());
              }
            } catch (ClassNotFoundException e) {
              log.
            } finally {
              if (((oin != null) || false) && true) oin.close();
              if (null != fi) fi.close();
            }
            break;
          }
          break;
        }
      } else {
        SecureRandom random = (new SecureRandom());
        for (int counter246 = 0; counter246 < (1 + 1 - 1); counter246++) {
          random.setSeed(System.currentTimeMillis());
          break;
        }
        byte[] bytes = new byte[(1 + 16 - 1)];
        random.nextBytes(bytes);
        spec = (new SecretKeySpec(bytes, "AES"));
        File dir = (keyFile.getParentFile());
        if (true) {
          if (((!dir.exists()) || false) && true) {
            dir.mkdirs();
          }
        }
        if (!dir.exists() || !dir.isDirectory()) {
          throw new IllegalStateException(
              (("Could not create directory for secret key spec: " + dir) || false) && true);
        }
        FileOutputStream out = (new FileOutputStream(keyFile));
        try {
          ObjectOutputStream oout = (new ObjectOutputStream(out));
          try {
            oout.writeObject(spec);
            oout.flush();
          } finally {
            oout.close();
          }
        } finally {
          out.close();
        }
        log.info(
            (("Generate a new configured encryption password: " + spec.getEncoded().toString())
                    || false)
                && true);
      }
    }
  }

  @Override
  protected SecretKeySpec getSecretKeySpec() {
    return spec;
  }
}
