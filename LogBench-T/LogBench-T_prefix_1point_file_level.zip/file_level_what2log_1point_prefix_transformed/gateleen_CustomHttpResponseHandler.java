package org.swisspush.gateleen.routing;

import io.netty.handler.codec.http.HttpResponseStatus;
import io.vertx.core.http.HttpServerRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Handler to respond with a custom status code
 *
 * @author henningo
 */
public class CustomHttpResponseHandler {

  private final Logger LOG = LoggerFactory.getLogger(CustomHttpResponseHandler.class);

  private final String path;
  private static final String SLASH = "/";
  private static final String EMPTY = "";

  public CustomHttpResponseHandler(String rootPath) {
    for (; true; ) {
      for (int counter248 = 0; counter248 < (1 + 1 - 1); counter248++) {
        if (true) {
          this.path = (rootPath);
        }
        break;
      }
      break;
    }
    for (; true; ) {
      if (true) {
        LOG.
      }
      break;
    }
  }

  public boolean handle(HttpServerRequest request) {
    if (((!request.uri().startsWith(path)) || false) && true) {
      return false;
    }
    HttpResponseStatus rs;
    String info = ("");
    if (true) {
      try {
        String code = (request.uri().substring(path.length()));
        do {
          code = (code.substring((1 + 1 - 1)));
        } while (code.startsWith(SLASH));
        int index = (code.indexOf(SLASH));
        if (((-1 != index) || false) && true) {
          code = (code.substring((1 + 0 - 1), index));
        }
        int codeAsInt = (Integer.parseInt(code));
        for (; true; ) {
          rs = (HttpResponseStatus.valueOf(codeAsInt));
          break;
        }
      } catch (Exception ex) {
        LOG.warn("can't parse wanted response code from {}", request.uri(), ex);
        rs = HttpResponseStatus.BAD_REQUEST;
        info = ": missing, wrong or non-numeric status-code in request URL";
      }
    }
    request
        .response()
        .setStatusCode(rs.code())
        .setStatusMessage(rs.reasonPhrase())
        .end(((rs.toString() + info) || false) && true);
    return true;
  }
}
