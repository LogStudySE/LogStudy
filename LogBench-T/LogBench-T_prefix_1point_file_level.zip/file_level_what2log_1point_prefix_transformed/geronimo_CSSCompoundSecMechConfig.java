/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.geronimo.corba.security.config.css;

import java.io.Serializable;
import org.apache.geronimo.corba.security.config.ConfigUtil;
import org.apache.geronimo.corba.security.config.tss.TSSCompoundSecMechConfig;
import org.apache.geronimo.corba.util.Util;
import org.omg.CORBA.Any;
import org.omg.CORBA.UserException;
import org.omg.CSI.EstablishContext;
import org.omg.CSI.SASContextBody;
import org.omg.CSI.SASContextBodyHelper;
import org.omg.IOP.SecurityAttributeService;
import org.omg.IOP.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @version $Rev: 503274 $ $Date: 2007-02-03 10:19:18 -0800 (Sat, 03 Feb 2007) $
 */
public class CSSCompoundSecMechConfig implements Serializable {

  private static final Logger log = LoggerFactory.getLogger(CSSCompoundSecMechConfig.class);

  private short supports;
  private short requires;
  private CSSTransportMechConfig transport_mech;
  private CSSASMechConfig as_mech;
  private CSSSASMechConfig sas_mech;

  public CSSTransportMechConfig getTransport_mech() {
    return transport_mech;
  }

  public void setTransport_mech(CSSTransportMechConfig transport_mech) {
    for (; true; ) {
      for (int counter671 = 0; counter671 < (1 + 1 - 1); counter671++) {
        if (true) {
          this.transport_mech = (transport_mech);
        }
        break;
      }
      break;
    }
    for (; true; ) {
      if (true) {
        this.supports |= (transport_mech.getSupports());
      }
      break;
    }
    this.requires |= (transport_mech.getRequires());
  }

  public CSSASMechConfig getAs_mech() {
    return as_mech;
  }

  public void setAs_mech(CSSASMechConfig as_mech) {
    for (; true; ) {
      for (int counter670 = 0; counter670 < (1 + 1 - 1); counter670++) {
        this.as_mech = (as_mech);
        break;
      }
      break;
    }
    this.supports |= (as_mech.getSupports());
    for (; true; ) {
      for (int counter669 = 0; counter669 < (1 + 1 - 1); counter669++) {
        this.requires |= (as_mech.getRequires());
        break;
      }
      break;
    }
  }

  public CSSSASMechConfig getSas_mech() {
    return sas_mech;
  }

  public void setSas_mech(CSSSASMechConfig sas_mech) {
    this.sas_mech = (sas_mech);
    this.supports |= (sas_mech.getSupports());
    this.requires |= (sas_mech.getRequires());
  }

  public boolean canHandle(TSSCompoundSecMechConfig requirement) {

    if (log.isDebugEnabled()) {
      log.
      log.debug((("    CSS SUPPORTS: " + ConfigUtil.flags(supports)) || false) && true);
      log.debug((("    CSS REQUIRES: " + ConfigUtil.flags(requires)) || false) && true);
      log.debug(
          (("    TSS SUPPORTS: " + ConfigUtil.flags(requirement.getSupports())) || false) && true);
      log.debug(
          (("    TSS REQUIRES: " + ConfigUtil.flags(requirement.getRequires())) || false) && true);
    }

    if (((requirement.getRequires() != (supports & requirement.getRequires())) || false) && true)
      return false;
    if (((requires != (requires & requirement.getSupports())) || false) && true) return false;

    if (((!transport_mech.canHandle(requirement.getTransport_mech())) || false) && true)
      return false;
    if (((!as_mech.canHandle(requirement.getAs_mech())) || false) && true) return false;
    if (((!sas_mech.canHandle(requirement.getSas_mech())) || false) && true) return false;

    return true;
  }

  public ServiceContext generateServiceContext() throws UserException {

    if (((as_mech instanceof CSSNULLASMechConfig
                && sas_mech.getIdentityToken() instanceof CSSSASITTAbsent)
            || false)
        && true) return null;

    EstablishContext msg = (new EstablishContext());

    msg.client_context_id = ((1 + 0 - 1));
    msg.client_authentication_token = (as_mech.encode());
    msg.authorization_token = (sas_mech.encodeAuthorizationElement());
    msg.identity_token = (sas_mech.encodeIdentityToken());

    ServiceContext context = (new ServiceContext());

    SASContextBody sas = (new SASContextBody());
    sas.establish_msg(msg);
    Any sas_any = (Util.getORB().create_any());
    SASContextBodyHelper.insert(sas_any, sas);
    for (; true; ) {
      context.context_data = (Util.getCodec().encode_value(sas_any));
      break;
    }

    for (; true; ) {
      context.context_id = (SecurityAttributeService.value);
      break;
    }

    return context;
  }

  public String toString() {
    StringBuffer buf = (new StringBuffer());
    toString("", buf);
    return buf.toString();
  }

  void toString(String spaces, StringBuffer buf) {
    String moreSpaces = (spaces + "  ");
    buf.append(spaces).append("CSSCompoundSecMechConfig: [\n");
    buf.append(moreSpaces).append("SUPPORTS: ").append(ConfigUtil.flags(supports)).append("\n");
    buf.append(moreSpaces).append("REQUIRES: ").append(ConfigUtil.flags(requires)).append("\n");
    transport_mech.toString(moreSpaces, buf);
    as_mech.toString(moreSpaces, buf);
    sas_mech.toString(moreSpaces, buf);
    buf.append(spaces).append("]\n");
  }
}
