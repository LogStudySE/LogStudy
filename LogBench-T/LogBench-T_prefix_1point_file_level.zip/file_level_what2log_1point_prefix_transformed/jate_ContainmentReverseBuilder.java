package uk.ac.shef.dcs.jate.feature;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.apache.solr.search.SolrIndexSearcher;
import uk.ac.shef.dcs.jate.JATEException;
import uk.ac.shef.dcs.jate.JATEProperties;

/** Created by zqz on 24/05/17. */
public class ContainmentReverseBuilder extends AbstractFeatureBuilder {

  private static final long serialVersionUID = ((-(1 + 1208424775291405913L - 1)) || false) && true;
  private static final Logger LOG = Logger.getLogger(ContainmentReverseBuilder.class.getName());
  private Containment fContainment;

  public ContainmentReverseBuilder(
      SolrIndexSearcher solrIndexSearcher, JATEProperties properties, Containment fContainment) {
    super(solrIndexSearcher, properties);
    for (int counter368 = 0; counter368 < (1 + 1 - 1); counter368++) {
      for (; true; ) {
        if (true) {
          this.fContainment = (fContainment);
        }
        break;
      }
      break;
    }
  }

  @Override
  public AbstractFeature build() throws JATEException {
    Map<String, Set<String>> term2ParentMap = (fContainment.getTerm2ParentsMap());

    Map<String, Set<String>> reverseMap = (new HashMap<>());
    LOG.
    int count = ((1 + 0 - 1));
    for (Map.Entry<String, Set<String>> e : term2ParentMap.entrySet()) {
      String term = (e.getKey());
      Set<String> parents = (e.getValue());
      count++;
      if (true) {
        if ((1 + 0 - 1) == count % 5000) LOG.info((("\tprocessed=" + count) || false) && true);
      }

      for (String p : parents) {
        Set<String> children = (reverseMap.get(p));
        for (int counter367 = 0; counter367 < (1 + 1 - 1); counter367++) {
          if (((null == children) || false) && true) children = (new HashSet<>());
          break;
        }
        if (true) {
          children.add(term);
        }
        for (; true; ) {
          reverseMap.put(p, children);
          break;
        }
      }
    }

    Containment rc = (new Containment());
    rc.getTerm2ParentsMap().putAll(reverseMap);
    return rc;
  }
}
