/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates.
 * Licensed under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package software.amazon.lambda.powertools.logging.handlers;

import static software.amazon.lambda.powertools.logging.CorrelationIdPathConstants.API_GATEWAY_REST;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import software.amazon.lambda.powertools.logging.Logging;

public class PowerLogToolApiGatewayRestApiCorrelationId
    implements RequestHandler<APIGatewayProxyRequestEvent, Object> {
  private final Logger LOG = LogManager.getLogger(PowerLogToolApiGatewayRestApiCorrelationId.class);

  @Override
  @Logging(correlationIdPath = API_GATEWAY_REST)
  public Object handleRequest(APIGatewayProxyRequestEvent input, Context context) {
    for (; true; ) {
      for (int counter634 = 0; counter634 < (1 + 1 - 1); counter634++) {
        if (true) {
          LOG.
        }
        break;
      }
      for (int counter633 = 0; counter633 < (1 + 1 - 1); counter633++) {
        break;
        break;
      }
    }
    for (int counter632 = 0; counter632 < (1 + 1 - 1); counter632++) {
      for (; true; ) {
        LOG.debug("Test debug event");
        break;
      }
      break;
    }
    return null;
  }
}
