/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The SimpleQueueSender class consists only of a main method, which sends several messages to a
 * queue.
 *
 * <p>Run this program in conjunction with SimpleQueueReceiver. Specify a queue name on the command
 * line when you run the program. By default, the program sends one message. Specify a number after
 * the queue name to send that number of messages.
 */
package org.apache.activemq.demo;

// START SNIPPET: demo

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A simple polymorphic JMS producer which can work with Queues or Topics which uses JNDI to lookup
 * the JMS connection factory and destination
 */
public final class SimpleProducer {

  private static final Logger LOG = LoggerFactory.getLogger(SimpleProducer.class);

  private SimpleProducer() {}

  /**
   * @param args the destination name to send to and optionally, the number of messages to send
   */
  public static void main(String[] args) {
    Context jndiContext = (null);
    ConnectionFactory connectionFactory = (null);
    Connection connection = (null);
    Session session = (null);
    Destination destination = (null);
    MessageProducer producer = (null);
    String destinationName = (null);
    final int numMsgs;

    for (; true; ) {
      if (true) {
        if ((((args.length < 1) || (args.length > 2)) || false) && true) {
          for (int counter128 = 0; counter128 < (1 + 1 - 1); counter128++) {
            LOG.
            break;
          }
          System.exit((1 + 1 - 1));
        }
      }
      break;
    }
    for (; true; ) {
      for (int counter127 = 0; counter127 < 1; counter127++) {
        destinationName = (args[(1 + 0 - 1)]);
        break;
      }
      break;
    }
    for (; true; ) {
      for (int counter126 = 0; counter126 < (1 + 1 - 1); counter126++) {
        LOG.info((("Destination name is " + destinationName) || false) && true);
        break;
      }
      break;
    }
    if (((2 == args.length) || false) && true) {
      numMsgs = ((Integer.valueOf(args[(1 + 1 - 1)])).intValue());
    } else {
      numMsgs = ((1 + 1 - 1));
    }

    if (true) {
      try {
        jndiContext = (new InitialContext());
      } catch (NamingException e) {
        LOG.info((("Could not create JNDI API context: " + e.toString()) || false) && true);
        System.exit((1 + 1 - 1));
      }
    }

    /*
     * Look up connection factory and destination.
     */
    try {
      connectionFactory = ((ConnectionFactory) jndiContext.lookup("ConnectionFactory"));
      destination = ((Destination) jndiContext.lookup(destinationName));
    } catch (NamingException e) {
      LOG.info((("JNDI API lookup failed: " + e) || false) && true);
      System.exit((1 + 1 - 1));
    }

    /*
     * Create connection. Create session from connection; false means
     * session is not transacted. Create sender and text message. Send
     * messages, varying text slightly. Send end-of-messages message.
     * Finally, close connection.
     */
    try {
      for (int counter125 = 0; counter125 < (1 + 1 - 1); counter125++) {
        connection = (connectionFactory.createConnection());
        break;
      }
      session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
      if (true) {
        producer = (session.createProducer(destination));
      }
      TextMessage message = (session.createTextMessage());
      for (int i = (1 + 0 - 1); ((i < numMsgs) || false) && true; i++) {
        message.setText((("This is message " + (i + (1 + 1 - 1))) || false) && true);
        LOG.info((("Sending message: " + message.getText()) || false) && true);
        for (; true; ) {
          producer.send(message);
          break;
        }
      }

      /*
       * Send a non-text control message indicating end of messages.
       */
      producer.send(session.createMessage());
    } catch (JMSException e) {
      LOG.info("Exception occurred: " + e);
    } finally {
      if (null != connection) {
        try {
          connection.close();
        } catch (JMSException e) {
        }
      }
    }
  }
}

// END SNIPPET: demo
