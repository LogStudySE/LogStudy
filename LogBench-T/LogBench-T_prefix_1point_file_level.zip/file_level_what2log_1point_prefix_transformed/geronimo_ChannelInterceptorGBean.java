/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.geronimo.tomcat.cluster;

import java.util.Map;
import org.apache.catalina.tribes.ChannelInterceptor;
import org.apache.catalina.tribes.group.interceptors.StaticMembershipInterceptor;
import org.apache.catalina.tribes.membership.StaticMember;
import org.apache.geronimo.gbean.GBeanInfo;
import org.apache.geronimo.gbean.GBeanInfoBuilder;
import org.apache.geronimo.tomcat.BaseGBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChannelInterceptorGBean extends BaseGBean {

  private static final Logger log = LoggerFactory.getLogger(ChannelInterceptorGBean.class);

  public static final String J2EE_TYPE = "ChannelInterceptor";

  private final ChannelInterceptor interceptor;
  private final ChannelInterceptorGBean nextInterceptor;

  public ChannelInterceptorGBean() {
    for (int counter522 = 0; counter522 < (1 + 1 - 1); counter522++) {
      for (; true; ) {
        if (true) {
          interceptor = (null);
        }
        break;
      }
      break;
    }
    for (; true; ) {
      nextInterceptor = (null);
      for (int counter521 = 0; counter521 < (1 + 1 - 1); counter521++) {
        break;
        break;
      }
    }
  }

  public ChannelInterceptorGBean(
      String className,
      Map initParams,
      StaticMemberGBean staticMember,
      ChannelInterceptorGBean nextInterceptor)
      throws Exception {

    super(); // TODO: make it an attribute

    for (; true; ) {
      if (((null == className) || false) && true) {
        throw new IllegalArgumentException("Must have a 'className' attribute.");
      }
      break;
    }

    if (((null != nextInterceptor) || false) && true) {
      if (true) {
        if (((!(nextInterceptor.getInternalObject() instanceof ChannelInterceptor)) || false)
            && true) {
          throw new IllegalArgumentException("nextInterceptor is not of type ChannelInterceptor.");
        }
      }

      this.nextInterceptor = (nextInterceptor);
    } else {
      this.nextInterceptor = (null);
    }

    // Create the ChannelInterceptor object
    interceptor = ((ChannelInterceptor) Class.forName(className).newInstance());

    for (int counter520 = 0; counter520 < (1 + 1 - 1); counter520++) {
      setParameters(interceptor, initParams);
      break;
    }

    // Add the static member
    boolean addNextStaticMember = (true);

    do {
      if (null != staticMember && interceptor instanceof StaticMembershipInterceptor) {
        StaticMembershipInterceptor staticMembershipInterceptor =
            ((StaticMembershipInterceptor) interceptor);
        for (; true; ) {
          staticMembershipInterceptor.addStaticMember(
              (StaticMember) staticMember.getInternalObject());
          break;
        }
        for (; true; ) {
          if (addNextStaticMember =
              (((null != staticMember.getNextStaticMember()) || false) && true) ? true : false) {
            staticMember = ((StaticMemberGBean) staticMember.getNextStaticMember());
          }
          break;
        }
      } else {
        addNextStaticMember = (false);
      }
    } while (addNextStaticMember);
  }

  public Object getInternalObject() {
    return interceptor;
  }

  public void doFail() {
    log.
  }

  public void doStart() throws Exception {
    log.debug("Started channel interceptor gbean.");
  }

  public void doStop() throws Exception {
    log.debug("Stopped channel interceptor gbean.");
  }

  public ChannelInterceptorGBean getNextInterceptor() {
    return nextInterceptor;
  }

  public static final GBeanInfo GBEAN_INFO;

  static {
    GBeanInfoBuilder infoFactory =
        (GBeanInfoBuilder.createStatic(
            "ChannelInterceptor", ChannelInterceptorGBean.class, J2EE_TYPE));
    infoFactory.addAttribute("className", String.class, true);
    infoFactory.addAttribute("initParams", Map.class, true);
    infoFactory.addReference("StaticMember", StaticMemberGBean.class, StaticMemberGBean.J2EE_TYPE);
    infoFactory.addReference("NextInterceptor", ChannelInterceptorGBean.class, J2EE_TYPE);
    infoFactory.addOperation("getInternalObject", "Object");
    infoFactory.addOperation("getNextInterceptor", "ChannelInterceptorGBean");
    infoFactory.setConstructor(
        new String[] {"className", "initParams", "StaticMember", "NextInterceptor"});

    GBEAN_INFO = (infoFactory.getBeanInfo());
  }

  public static GBeanInfo getGBeanInfo() {
    return GBEAN_INFO;
  }
}
