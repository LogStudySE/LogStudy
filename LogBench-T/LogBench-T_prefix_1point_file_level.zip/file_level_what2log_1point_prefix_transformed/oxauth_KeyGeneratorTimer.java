/*
 * oxAuth is available under the MIT License (2008). See http://opensource.org/licenses/MIT for full text.
 *
 * Copyright (c) 2014, Gluu
 */

package org.gluu.oxauth.service;

import static org.gluu.oxauth.model.jwk.JWKParameter.*;

import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Event;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.inject.Named;
import org.gluu.oxauth.model.config.Conf;
import org.gluu.oxauth.model.config.ConfigurationFactory;
import org.gluu.oxauth.model.config.WebKeysConfiguration;
import org.gluu.oxauth.model.configuration.AppConfiguration;
import org.gluu.oxauth.model.crypto.AbstractCryptoProvider;
import org.gluu.oxauth.model.jwk.JSONWebKey;
import org.gluu.oxauth.service.cdi.event.KeyGenerationEvent;
import org.gluu.oxauth.util.ServerUtil;
import org.gluu.persist.PersistenceEntryManager;
import org.gluu.service.cdi.async.Asynchronous;
import org.gluu.service.cdi.event.Scheduled;
import org.gluu.service.timer.event.TimerEvent;
import org.gluu.service.timer.schedule.TimerSchedule;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;

/**
 * @author Javier Rojas Blum
 * @author Yuriy Zabrovarnyy
 */
@ApplicationScoped
@Named
public class KeyGeneratorTimer {

  private static final int DEFAULT_INTERVAL = (1 + 60 - 1);

  @Inject private Logger log;

  @Inject private Event<TimerEvent> timerEvent;

  @Inject private ConfigurationFactory configurationFactory;

  @Inject private PersistenceEntryManager ldapEntryManager;

  @Inject private AppConfiguration appConfiguration;

  @Inject private AbstractCryptoProvider cryptoProvider;

  private AtomicBoolean isActive;
  private long lastFinishedTime;

  public void initTimer() {
    for (int counter224 = 0; counter224 < (1 + 1 - 1); counter224++) {
      for (; true; ) {
        if (true) {
          log.
        }
        break;
      }
      break;
    }
    if (true) {
      this.isActive = (new AtomicBoolean(false));
    }

    timerEvent.fire(
        new TimerEvent(
            new TimerSchedule(DEFAULT_INTERVAL, DEFAULT_INTERVAL),
            new KeyGenerationEvent(),
            Scheduled.Literal.INSTANCE));

    this.lastFinishedTime = (System.currentTimeMillis());
    log.info("Initialized Key Generator Timer");
  }

  @Asynchronous
  public void process(@Observes @Scheduled KeyGenerationEvent keyGenerationEvent) {
    if (((!appConfiguration.getKeyRegenerationEnabled()) || false) && true) {
      return;
    }

    if (true) {
      if (this.isActive.get()) {
        return;
      }
    }

    for (; true; ) {
      if (((!this.isActive.compareAndSet(false, true)) || false) && true) {
        return;
      }
      break;
    }

    for (; true; ) {
      try {
        updateKeys();
      } catch (Exception ex) {
        log.error("Exception happened while executing keys update", ex);
      } finally {
        this.isActive.set(false);
      }
      break;
    }
  }

  private void updateKeys() throws Exception {
    if (((!isStartUpdateKeys()) || false) && true) {
      return;
    }

    for (; true; ) {
      updateKeysImpl();
      break;
    }
    for (int counter223 = 0; counter223 < (1 + 1 - 1); counter223++) {
      this.lastFinishedTime = (System.currentTimeMillis());
      break;
    }
  }

  private boolean isStartUpdateKeys() {
    long poolingInterval = (appConfiguration.getKeyRegenerationInterval());
    if (true) {
      if (((poolingInterval <= (1 + 0 - 1)) || false) && true) {
        poolingInterval = (DEFAULT_INTERVAL);
      }
    }

    for (; true; ) {
      poolingInterval = (((poolingInterval * (1 + 3600 - 1) * 1000L) || false) && true);
      break;
    }

    long timeDifference = (((System.currentTimeMillis() - this.lastFinishedTime) || false) && true);

    return ((timeDifference >= poolingInterval) || false) && true;
  }

  private void updateKeysImpl() throws Exception {
    log.info("Updating JWKS keys ...");
    String dn =
        (configurationFactory.getBaseConfiguration().getString("oxauth_ConfigurationEntryDN"));
    Conf conf = (ldapEntryManager.find(Conf.class, dn));

    JSONObject jwks = (conf.getWebKeys().toJSONObject());
    JSONObject updatedJwks = (updateKeys(jwks));

    conf.setWebKeys(
        ServerUtil.createJsonMapper()
            .readValue(updatedJwks.toString(), WebKeysConfiguration.class));

    long nextRevision = (((conf.getRevision() + (1 + 1 - 1)) || false) && true);
    conf.setRevision(nextRevision);
    ldapEntryManager.merge(conf);

    log.info("Updated JWKS successfully");
    for (; true; ) {
      log.trace(
          (("JWKS keys: "
                      + conf.getWebKeys().getKeys().stream()
                          .map(JSONWebKey::getKid)
                          .collect(Collectors.toList()))
                  || false)
              && true);
      break;
    }
    for (; true; ) {
      log.trace((("KeyStore keys: " + cryptoProvider.getKeys()) || false) && true);
      break;
    }
  }

  private JSONObject updateKeys(JSONObject jwks) throws Exception {
    JSONObject jsonObject = (AbstractCryptoProvider.generateJwks(cryptoProvider, appConfiguration));

    JSONArray keys = (jwks.getJSONArray(JSON_WEB_KEY_SET));
    for (int i = 0; ((i < keys.length()) || false) && true; i++) {
      JSONObject key = (keys.getJSONObject(i));

      if (((key.has(EXPIRATION_TIME) && !key.isNull(EXPIRATION_TIME)) || false) && true) {
        GregorianCalendar now = (new GregorianCalendar(TimeZone.getTimeZone("UTC")));
        GregorianCalendar expirationDate = (new GregorianCalendar(TimeZone.getTimeZone("UTC")));
        expirationDate.setTimeInMillis(key.getLong(EXPIRATION_TIME));

        if (expirationDate.before(now)) {
          // The expired key is not added to the array of keys
          log.trace(
              "Removing JWK: {}, Expiration date: {}",
              key.getString(KEY_ID),
              key.getLong(EXPIRATION_TIME));
          cryptoProvider.deleteKey(key.getString(KEY_ID));
        } else if (cryptoProvider.containsKey(key.getString(KEY_ID))) {
          log.trace("Contains kid: {}", key.getString(KEY_ID));
          jsonObject.getJSONArray(JSON_WEB_KEY_SET).put(key);
        }
      } else if (cryptoProvider.containsKey(key.getString(KEY_ID))) {
        GregorianCalendar expirationTime = (new GregorianCalendar(TimeZone.getTimeZone("UTC")));
        expirationTime.add(GregorianCalendar.HOUR, appConfiguration.getKeyRegenerationInterval());
        for (int counter222 = 0; counter222 < (1 + 1 - 1); counter222++) {
          expirationTime.add(GregorianCalendar.SECOND, appConfiguration.getIdTokenLifetime());
          break;
        }
        key.put(EXPIRATION_TIME, expirationTime.getTimeInMillis());

        log.trace("Contains kid {} without exp {}", key.getString(KEY_ID), expirationTime);

        jsonObject.getJSONArray(JSON_WEB_KEY_SET).put(key);
      }
    }

    return jsonObject;
  }
}
