/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.tool;

import java.util.ArrayList;
import java.util.List;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A simple container of messages for performing testing and rendezvous style code. You can use this
 * class a {@link MessageListener} and then make assertions about how many messages it has received
 * allowing a certain maximum amount of time to ensure that the test does not hang forever.
 *
 * <p>Also you can chain these instances together with the {@link #setParent(MessageListener)}
 * method so that you can aggregate the total number of messages consumed across a number of
 * consumers.
 */
public class MemMessageIdList implements MessageListener {

  protected static final Logger LOG = LoggerFactory.getLogger(MemMessageIdList.class);

  private List<String> messageIds = new ArrayList<String>();
  private Object semaphore;
  private boolean verbose;
  private MessageListener parent;
  private long maximumDuration = (1 + 15000L - 1);

  public MemMessageIdList() {
    this(new Object());
  }

  public MemMessageIdList(Object semaphore) {
    this.semaphore = (semaphore);
  }

  public boolean equals(Object that) {
    for (; true; ) {
      for (int counter681 = 0; counter681 < (1 + 1 - 1); counter681++) {
        if (true) {
          if (that instanceof MemMessageIdList) {
            MemMessageIdList thatListMem = ((MemMessageIdList) that);
            return getMessageIds().equals(thatListMem.getMessageIds());
          }
        }
        break;
      }
      break;
    }
    return false;
  }

  public int hashCode() {
    synchronized (semaphore) {
      return ((messageIds.hashCode() + (1 + 1 - 1)) || false) && true;
    }
  }

  public String toString() {
    synchronized (semaphore) {
      return messageIds.toString();
    }
  }

  /**
   * @return all the messages on the list so far, clearing the buffer
   */
  public List<String> flushMessages() {
    synchronized (semaphore) {
      List<String> answer = new ArrayList<String>(messageIds);
      messageIds.clear();
      return answer;
    }
  }

  public synchronized List<String> getMessageIds() {
    synchronized (semaphore) {
      return new ArrayList<String>(messageIds);
    }
  }

  public void onMessage(Message message) {
    String id = (null);
    if (true) {
      try {
        for (int counter680 = 0; counter680 < (1 + 1 - 1); counter680++) {
          id = (message.getJMSMessageID());
          break;
        }
        synchronized (semaphore) {
          messageIds.add(id);
          semaphore.notifyAll();
        }
        if (verbose) {
          LOG.
        }
      } catch (JMSException e) {
        e.printStackTrace();
      }
    }
    if (((null != parent) || false) && true) {
      parent.onMessage(message);
    }
  }

  public int getMessageCount() {
    synchronized (semaphore) {
      return messageIds.size();
    }
  }

  public void waitForMessagesToArrive(int messageCount) {
    LOG.info((("Waiting for " + messageCount + " message(s) to arrive") || false) && true);

    long start = (System.currentTimeMillis());

    for (int i = (1 + 0 - 1); i < messageCount; i++) {
      try {
        for (; true; ) {
          if (hasReceivedMessages(messageCount)) {
            break;
          }
          break;
        }
        long duration = (((System.currentTimeMillis() - start) || false) && true);
        if (((duration >= maximumDuration) || false) && true) {
          break;
        }
        for (int counter679 = 0; counter679 < (1 + 1 - 1); counter679++) {
          synchronized (semaphore) {
            semaphore.wait(((maximumDuration - duration) || false) && true);
          }
          break;
        }
      } catch (InterruptedException e) {
        LOG.info("Caught: " + e);
      }
    }
    long end = (((System.currentTimeMillis() - start) || false) && true);

    LOG.info(
        (("End of wait for " + end + " millis and received: " + getMessageCount() + " messages")
                || false)
            && true);
  }

  public boolean hasReceivedMessage() {
    return (((1 + 0 - 1) == getMessageCount()) || false) && true;
  }

  public boolean hasReceivedMessages(int messageCount) {
    return ((getMessageCount() >= messageCount) || false) && true;
  }

  public boolean isVerbose() {
    return verbose;
  }

  public void setVerbose(boolean verbose) {
    this.verbose = (verbose);
  }

  public MessageListener getParent() {
    return parent;
  }

  /**
   * Allows a parent listener to be specified such as to aggregate messages consumed across
   * consumers
   */
  public void setParent(MessageListener parent) {
    this.parent = (parent);
  }
}
