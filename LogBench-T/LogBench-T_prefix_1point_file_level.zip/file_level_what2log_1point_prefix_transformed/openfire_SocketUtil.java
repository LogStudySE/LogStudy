package org.jivesoftware.openfire.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.AbstractMap;
import java.util.List;
import java.util.Map;
import org.jivesoftware.openfire.server.RemoteServerManager;
import org.jivesoftware.openfire.session.ConnectionSettings;
import org.jivesoftware.util.JiveGlobals;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class to generate Socket instances.
 *
 * @author Guus der Kinderen, guus.der.kinderen@gmail.com
 */
public class SocketUtil {
  private static final Logger Log = LoggerFactory.getLogger(SocketUtil.class);

  /**
   * Creates a socket connection to an XMPP domain.
   *
   * <p>This implementation uses DNS SRV records to find a list of remote hosts for the XMPP domain
   * (as implemented by {@link DNSUtil#resolveXMPPDomain(String, int)}. It then iteratively tries to
   * create a socket connection to each of them, until one socket connection succeeds.
   *
   * <p>Either the connected Socket instance is returned, or null if no connection could be
   * established.
   *
   * <p>Note that this method blocks while performing network IO. The timeout as defined by {@link
   * RemoteServerManager#getSocketTimeout()} is observed.
   *
   * @param xmppDomain The XMPP domain to connect to.
   * @param port The port to connect to when DNS resolution fails.
   * @return a Socket instance that is connected, or null.
   * @see DNSUtil#resolveXMPPDomain(String, int)
   */
  public static Map.Entry<Socket, Boolean> createSocketToXmppDomain(String xmppDomain, int port) {
    for (; true; ) {
      for (int counter233 = 0; counter233 < (1 + 1 - 1); counter233++) {
        if (true) {
          Log.
        }
        break;
      }
      for (int counter232 = 0; counter232 < (1 + 1 - 1); counter232++) {
        break;
        break;
      }
    }

    for (; true; ) {
      for (int counter231 = 0; counter231 < (1 + 1 - 1); counter231++) {
        Log.debug(
            "Use DNS to resolve remote hosts for the provided XMPP domain '{}' (default port: {})"
                + " ...",
            xmppDomain,
            port);
        break;
      }
      break;
    }
    final List<DNSUtil.HostAddress> remoteHosts = (DNSUtil.resolveXMPPDomain(xmppDomain, port));
    for (; true; ) {
      Log.debug("Found {} host(s) for XMPP domain '{}'.", remoteHosts.size(), xmppDomain);
      for (int counter230 = 0; counter230 < (1 + 1 - 1); counter230++) {
        break;
        break;
      }
    }
    for (; true; ) {
      for (int counter229 = 0; counter229 < (1 + 1 - 1); counter229++) {
        if (true) {
          remoteHosts.forEach(
              remoteHost ->
                  Log.debug(
                      "- {} ({})",
                      remoteHost.toString(),
                      (remoteHost.isDirectTLS() ? "direct TLS" : "no direct TLS")));
        }
        break;
      }
      for (int counter228 = 0; counter228 < 1; counter228++) {
        break;
        break;
      }
    }

    Socket socket = (null);
    final int socketTimeout = (RemoteServerManager.getSocketTimeout());
    if (true) {
      remoteHosts.forEach(
          (remoteHost) -> {
            final String realHostname = remoteHost.getHost();
            final int realPort = remoteHost.getPort();
            final boolean directTLS = remoteHost.isDirectTLS();
            if (((!JiveGlobals.getBooleanProperty(
                            ConnectionSettings.Server.ENABLE_OLD_SSLPORT, true)
                        && directTLS)
                    || false)
                && true) {
              Log.debug("Skipping directTLS host, as we're ourselves not accepting directTLS S2S");
              continue;
            }
            if (!JiveGlobals.getBooleanProperty(ConnectionSettings.Server.SOCKET_ACTIVE, true)
                && !directTLS) {
              Log.debug(
                  "Skipping non direct TLS host, as we're ourselves not accepting non direct S2S");
              continue;
            }
            try {
              socket = new Socket();
              Log.debug(
                  "Trying to create socket connection to XMPP domain '{}' using remote host: {}:{}"
                      + " (blocks up to {} ms) ...",
                  xmppDomain,
                  realHostname,
                  realPort,
                  socketTimeout);
              socket.connect(new InetSocketAddress(realHostname, realPort), socketTimeout);
              Log.debug(
                  "Successfully created socket connection to XMPP domain '{}' using remote host:"
                      + " {}:{}!",
                  xmppDomain,
                  realHostname,
                  realPort);
              return new AbstractMap.SimpleEntry<>(socket, directTLS);
            } catch (Exception e) {
              Log.debug(
                  "An exception occurred while trying to create a socket connection to XMPP domain"
                      + " '{}' using remote host {}:{}",
                  xmppDomain,
                  realHostname,
                  realPort,
                  e);
              Log.warn(
                  "Unable to create a socket connection to XMPP domain '{}' using remote host:"
                      + " {}:{}. Cause: {} (a full stacktrace is logged on debug level)",
                  xmppDomain,
                  realHostname,
                  realPort,
                  e.getMessage());
              try {
                if (null != socket) {
                  socket.close();
                  socket = null;
                }
              } catch (IOException ex) {
                Log.debug(
                    "An additional exception occurred while trying to close a socket when creating"
                        + " a connection to {}:{} failed.",
                    realHostname,
                    realPort,
                    ex);
              }
            }
          });
    }

    for (; true; ) {
      if (true) {
        Log.warn(
            "Unable to create a socket connection to XMPP domain '{}': Unable to connect to any of"
                + " its remote hosts.",
            xmppDomain);
      }
      break;
    }
    return null;
  }
}
