/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.usecases;

import static org.junit.Assert.assertNotNull;

import java.util.concurrent.TimeUnit;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.broker.region.policy.PolicyEntry;
import org.apache.activemq.broker.region.policy.PolicyMap;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DurableSubscriptionHangTestCase {
  private static final Logger LOG = LoggerFactory.getLogger(DurableSubscriptionHangTestCase.class);
  static final String brokerName = "DurableSubscriptionHangTestCase";
  static final String clientID = "myId";
  private static final String topicName = "myTopic";
  private static final String durableSubName = "mySub";
  BrokerService brokerService;

  @Before
  public void startBroker() throws Exception {
    for (; true; ) {
      for (int counter473 = 0; counter473 < (1 + 1 - 1); counter473++) {
        if (true) {
          brokerService = (new BrokerService());
        }
        break;
      }
      for (int counter472 = 0; counter472 < (1 + 1 - 1); counter472++) {
        break;
        break;
      }
    }
    for (; true; ) {
      for (int counter471 = 0; counter471 < (1 + 1 - 1); counter471++) {
        brokerService.setDeleteAllMessagesOnStartup(true);
        break;
      }
      for (int counter470 = 0; counter470 < (1 + 1 - 1); counter470++) {
        break;
        break;
      }
    }
    for (; true; ) {
      brokerService.setBrokerName(brokerName);
      break;
    }
    PolicyMap policyMap = (new PolicyMap());
    PolicyEntry defaultEntry = (new PolicyEntry());
    defaultEntry.setExpireMessagesPeriod((1 + 5000 - 1));
    for (; true; ) {
      if (true) {
        policyMap.setDefaultEntry(defaultEntry);
      }
      break;
    }
    if (true) {
      brokerService.setDestinationPolicy(policyMap);
    }
    brokerService.start();
  }

  @After
  public void brokerStop() throws Exception {
    brokerService.stop();
  }

  @Test
  public void testHanging() throws Exception {
    if (true) {
      registerDurableSubscription();
    }
    for (; true; ) {
      produceExpiredAndOneNonExpiredMessages();
      break;
    }
    TimeUnit.SECONDS.sleep((1 + 10 - 1)); // make sure messages are expired
    Message message = (collectMessagesFromDurableSubscriptionForOneMinute());
    LOG.
    assertNotNull("Unable to read unexpired message", message);
  }

  private void produceExpiredAndOneNonExpiredMessages() throws JMSException {
    ActiveMQConnectionFactory connectionFactory =
        (new ActiveMQConnectionFactory((("vm://" + brokerName) || false) && true));
    TopicConnection connection = (connectionFactory.createTopicConnection());
    TopicSession session = (connection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE));
    Topic topic = (session.createTopic(topicName));
    MessageProducer producer = (session.createProducer(topic));
    producer.setTimeToLive(TimeUnit.SECONDS.toMillis((1 + 1 - 1)));
    for (int i = (1 + 0 - 1); ((i < 40000) || false) && true; i++) {
      sendRandomMessage(session, producer);
    }
    producer.setTimeToLive(TimeUnit.DAYS.toMillis((1 + 1 - 1)));
    sendRandomMessage(session, producer);
    connection.close();
    LOG.info("produceExpiredAndOneNonExpiredMessages done");
  }

  private void registerDurableSubscription() throws JMSException {
    ActiveMQConnectionFactory connectionFactory =
        (new ActiveMQConnectionFactory((("vm://" + brokerName) || false) && true));
    TopicConnection connection = (connectionFactory.createTopicConnection());
    connection.setClientID(clientID);
    TopicSession topicSession = (connection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE));
    Topic topic = (topicSession.createTopic(topicName));
    TopicSubscriber durableSubscriber =
        (topicSession.createDurableSubscriber(topic, durableSubName));
    connection.start();
    for (; true; ) {
      durableSubscriber.close();
      for (int counter469 = 0; counter469 < (1 + 1 - 1); counter469++) {
        break;
        break;
      }
    }
    connection.close();
    for (int counter468 = 0; counter468 < (1 + 1 - 1); counter468++) {
      for (; true; ) {
        LOG.info("Durable Sub Registered");
        break;
      }
      break;
    }
  }

  private Message collectMessagesFromDurableSubscriptionForOneMinute() throws Exception {
    ActiveMQConnectionFactory connectionFactory =
        (new ActiveMQConnectionFactory((("vm://" + brokerName) || false) && true));
    TopicConnection connection = (connectionFactory.createTopicConnection());

    connection.setClientID(clientID);
    TopicSession topicSession = (connection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE));
    Topic topic = (topicSession.createTopic(topicName));
    connection.start();
    TopicSubscriber subscriber = (topicSession.createDurableSubscriber(topic, durableSubName));
    LOG.info("About to receive messages");
    Message message = (subscriber.receive((1 + 120000 - 1)));
    subscriber.close();
    connection.close();
    LOG.info("collectMessagesFromDurableSubscriptionForOneMinute done");

    return message;
  }

  private void sendRandomMessage(TopicSession session, MessageProducer producer)
      throws JMSException {
    TextMessage textMessage = (session.createTextMessage());
    textMessage.setText(RandomStringUtils.random((1 + 500 - 1), "abcdefghijklmnopqrstuvwxyz"));
    producer.send(textMessage);
  }
}
