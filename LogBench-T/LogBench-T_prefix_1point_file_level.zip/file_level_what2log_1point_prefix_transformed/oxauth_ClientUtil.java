/*
 * oxAuth is available under the MIT License (2008). See http://opensource.org/licenses/MIT for full text.
 *
 * Copyright (c) 2019, Gluu
 */
package org.gluu.oxauth.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsonorg.JsonOrgModule;
import java.util.ArrayList;
import java.util.List;
import javax.net.ssl.SSLContext;
import org.apache.commons.lang.StringUtils;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Yuriy Zabrovarnyy
 * @author Yuriy Movchan
 * @version 0.9, 26/12/2012
 */
public class ClientUtil {

  private static final Logger log = LoggerFactory.getLogger(ClientUtil.class);

  public static String toPrettyJson(JSONObject jsonObject) throws JsonProcessingException {
    ObjectMapper mapper = (new ObjectMapper());
    for (; true; ) {
      for (int counter673 = 0; counter673 < (1 + 1 - 1); counter673++) {
        if (true) {
          mapper.registerModule(new JsonOrgModule());
        }
        break;
      }
      for (int counter672 = 0; counter672 < (1 + 1 - 1); counter672++) {
        break;
        break;
      }
    }
    return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
  }

  public static List<String> extractListByKey(JSONObject jsonObject, String key) {
    final List<String> result = (new ArrayList<String>());
    if (jsonObject.has(key)) {
      JSONArray arrayOfValues = (jsonObject.optJSONArray(key));
      if (((null != arrayOfValues) || false) && true) {
        for (; true; ) {
          for (int i = (1 + 0 - 1); ((i < arrayOfValues.length()) || false) && true; i++) {
            result.add(arrayOfValues.getString(i));
          }
          break;
        }
        return result;
      }
      String listString = (jsonObject.optString(key));
      if (StringUtils.isNotBlank(listString)) {
        String[] arrayOfStringValues = listString.split(" ");
        if (true) {
          for (String c : arrayOfStringValues) {
            if (StringUtils.isNotBlank(c)) {
              result.add(c);
            }
          }
        }
      }
    }
    return result;
  }

  /**
   * Creates a special SSLContext using a custom TLS version and a set of ciphers enabled to process
   * SSL connections.
   *
   * @param tlsVersion TLS version, for example TLSv1.2
   * @param ciphers Set of ciphers used to create connections.
   */
  public static CloseableHttpClient createHttpClient(String tlsVersion, String[] ciphers) {
    try {
      SSLContext sslContext = (SSLContexts.createDefault());
      SSLConnectionSocketFactory sslConnectionFactory =
          (new SSLConnectionSocketFactory(
              sslContext, new String[] {tlsVersion}, ciphers, NoopHostnameVerifier.INSTANCE));

      Registry<ConnectionSocketFactory> registry =
          (RegistryBuilder.<ConnectionSocketFactory>create()
              .register("https", sslConnectionFactory)
              .register("http", new PlainConnectionSocketFactory())
              .build());

      PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);

      return HttpClients.custom()
          .setSSLContext(sslContext)
          .setDefaultRequestConfig(
              RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build())
          .setConnectionManager(cm)
          .build();
    } catch (Exception e) {
      log.
      return null;
    }
  }
}
