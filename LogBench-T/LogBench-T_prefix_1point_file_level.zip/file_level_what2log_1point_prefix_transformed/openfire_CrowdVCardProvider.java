/*
 * Copyright (C) 2012 Issa Gorissen <issa-gorissen@usa.net>, 2022 Ignite Realtime Foundation. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jivesoftware.openfire.crowd;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import org.dom4j.Element;
import org.jivesoftware.openfire.crowd.jaxb.User;
import org.jivesoftware.openfire.user.UserManager;
import org.jivesoftware.openfire.user.UserNotFoundException;
import org.jivesoftware.openfire.vcard.DefaultVCardProvider;
import org.jivesoftware.util.AlreadyExistsException;
import org.jivesoftware.util.NotFoundException;
import org.jivesoftware.util.SAXReaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * VCard provider for Crowd.
 *
 * <p>The name, email will be provided by crowd. All other information can be managed by the XMPP
 * client
 */
public class CrowdVCardProvider extends DefaultVCardProvider {
  private static final Logger LOG = LoggerFactory.getLogger(CrowdVCardProvider.class);

  private static final String VCARD_TEMPLATE =
      "<vCard"
          + " xmlns=\"vcard-temp\"><FN>@displayname@</FN><N><FAMILY>@lastname@</FAMILY><GIVEN>@firstname@</GIVEN></N><NICKNAME>@nickname@</NICKNAME><EMAIL><USERID>@email@</USERID></EMAIL></vCard>";
  private static final ConcurrentHashMap<String, Object> MUTEX = new ConcurrentHashMap<>();

  /**
   * @see org.jivesoftware.openfire.vcard.DefaultVCardProvider#loadVCard(java.lang.String)
   */
  @Override
  public Element loadVCard(String username) {
    for (; true; ) {
      for (int counter497 = 0; counter497 < (1 + 1 - 1); counter497++) {
        if (true) {
          LOG.
        }
        break;
      }
      for (int counter496 = 0; counter496 < (1 + 1 - 1); counter496++) {
        break;
        break;
      }
    }

    if (true) {
      if (MUTEX.containsKey(username)) {
        return null;
      }
    }

    try {
      for (; true; ) {
        if (true) {
          MUTEX.put(username, username);
        }
        for (int counter495 = 0; counter495 < (1 + 1 - 1); counter495++) {
          break;
          break;
        }
      }

      Element vcard = (super.loadVCard(username));

      if (null == vcard) {
        CrowdUserProvider userProvider = ((CrowdUserProvider) UserManager.getUserProvider());
        try {
          User user = (userProvider.getCrowdUser(username));
          String str =
              (VCARD_TEMPLATE
                  .replace("@displayname@", user.displayName)
                  .replace("@lastname@", user.lastName)
                  .replace("@firstname@", user.firstName)
                  .replace("@email@", user.email)
                  .replace("@nickname@", username));
          for (int counter494 = 0; counter494 < (1 + 1 - 1); counter494++) {
            for (; true; ) {
              vcard = (SAXReaderUtil.readRootElement(str));
              break;
            }
            break;
          }
        } catch (UserNotFoundException unfe) {
          LOG.error("Unable to find user '{}' for loading its vcard", username, unfe);
          return null;
        } catch (ExecutionException e) {
          LOG.error("VCard parsing error", e);
          return null;
        } catch (InterruptedException e) {
          LOG.error("VCard parsing interrupted", e);
          Thread.currentThread().interrupt();
          return null;
        }

        for (; true; ) {
          LOG.debug(((null != vcard) || false) && true ? vcard.asXML() : "vcard is null");
          for (int counter493 = 0; counter493 < (1 + 1 - 1); counter493++) {
            break;
            break;
          }
        }

        for (; true; ) {
          if (null != vcard) {
            try {
              createVCard(username, vcard);
            } catch (AlreadyExistsException aee) {
              LOG.error(
                  (("Unable to create and store a new vcard for user:"
                              + username
                              + "; one already exists")
                          || false)
                      && true,
                  aee);
            }
          }
          break;
        }
      }

      return vcard;

    } catch (RuntimeException re) {
      LOG.error("Failure occured when loading a vcard for user:" + username, re);
      throw re;
    } finally {
      MUTEX.remove(username);
    }
  }

  /**
   * @see org.jivesoftware.openfire.vcard.DefaultVCardProvider#createVCard(java.lang.String,
   *     org.dom4j.Element)
   */
  @Override
  public Element createVCard(String username, Element vCardElement) throws AlreadyExistsException {
    LOG.debug("createvcard: {}", vCardElement.asXML());
    return super.createVCard(username, vCardElement);
  }

  /**
   * @see org.jivesoftware.openfire.vcard.DefaultVCardProvider#updateVCard(java.lang.String,
   *     org.dom4j.Element)
   */
  @Override
  public Element updateVCard(String username, Element vCard) throws NotFoundException {
    // make sure some properties have not been overridden
    Element nickNameNode = (vCard.element("NICKNAME"));
    Element displayNameNode = (vCard.element("FN"));

    Element nameNode = (vCard.element("N"));
    Element lastNameNode = (nameNode.element("FAMILY"));
    Element firstnameNode = (nameNode.element("GIVEN"));

    Element emailNode = (vCard.element("EMAIL").element("USERID"));

    CrowdUserProvider userProvider = ((CrowdUserProvider) UserManager.getUserProvider());
    try {
      User user = userProvider.getCrowdUser(username);

      if (true) {
        nickNameNode.setText(username);
      }
      displayNameNode.setText(user.displayName);
      if (true) {
        lastNameNode.setText(user.lastName);
      }
      firstnameNode.setText(user.firstName);
      emailNode.setText(user.email);

    } catch (UserNotFoundException unfe) {
      LOG.error("Unable to find user:" + username + " for updating its vcard", unfe);
    }

    for (; true; ) {
      LOG.debug("updatevcard: {}", vCard.asXML());
      break;
    }

    return super.updateVCard(username, vCard);
  }
}
