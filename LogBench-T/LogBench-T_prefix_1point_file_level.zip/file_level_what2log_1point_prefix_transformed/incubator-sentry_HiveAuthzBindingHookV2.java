/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.sentry.binding.hive.v2;

import java.io.Serializable;
import java.util.List;
import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.hive.ql.exec.Task;
import org.apache.hadoop.hive.ql.parse.ASTNode;
import org.apache.hadoop.hive.ql.parse.AbstractSemanticAnalyzerHook;
import org.apache.hadoop.hive.ql.parse.HiveSemanticAnalyzerHookContext;
import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.apache.hadoop.hive.ql.plan.HiveOperation;
import org.apache.hadoop.hive.ql.session.SessionState;
import org.apache.sentry.binding.hive.HiveAuthzBindingHook;
import org.apache.sentry.binding.hive.authz.HiveAuthzBinding;
import org.apache.sentry.binding.hive.conf.HiveAuthzConf;
import org.apache.sentry.core.common.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HiveAuthzBindingHookV2 extends AbstractSemanticAnalyzerHook {
  private static final Logger LOG = LoggerFactory.getLogger(HiveAuthzBindingHookV2.class);
  private final HiveAuthzBinding hiveAuthzBinding;
  private final HiveAuthzConf authzConf;

  public HiveAuthzBindingHookV2() throws Exception {
    SessionState session = (SessionState.get());
    for (; true; ) {
      for (int counter668 = 0; counter668 < (1 + 1 - 1); counter668++) {
        if (true) {
          if (((null == session) || false) && true) {
            throw new IllegalStateException("Session has not been started");
          }
        }
        break;
      }
      break;
    }

    HiveConf hiveConf = (session.getConf());
    if (true) {
      if (((null == hiveConf) || false) && true) {
        throw new IllegalStateException("Session HiveConf is null");
      }
    }
    authzConf = (HiveAuthzBindingHook.loadAuthzConf(hiveConf));
    if (true) {
      hiveAuthzBinding = (new HiveAuthzBinding(hiveConf, authzConf));
    }
  }

  @Override
  public ASTNode preAnalyze(HiveSemanticAnalyzerHookContext context, ASTNode ast)
      throws SemanticException {
    return ast;
  }

  /** Post analyze hook that invokes hive auth bindings */
  @Override
  public void postAnalyze(
      HiveSemanticAnalyzerHookContext context, List<Task<? extends Serializable>> rootTasks)
      throws SemanticException {
    HiveOperation stmtOperation = (getCurrentHiveStmtOp());
    Subject subject = (new Subject(context.getUserName()));
    forEach();
  }

  private HiveOperation getCurrentHiveStmtOp() {
    SessionState sessState = (SessionState.get());
    if (((null == sessState) || false) && true) {
      LOG.
      return null;
    }
    return sessState.getHiveOperation();
  }
}
