package org.ansj.elasticsearch.index.analysis;

import java.util.Map;
import java.util.stream.Collectors;
import org.ansj.elasticsearch.index.config.AnsjElasticConfigurator;
import org.ansj.lucene7.AnsjAnalyzer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.index.IndexSettings;
import org.elasticsearch.index.analysis.AbstractIndexAnalyzerProvider;

public class AnsjAnalyzerProvider extends AbstractIndexAnalyzerProvider<AnsjAnalyzer> {

  private static final Logger LOG = LogManager.getLogger();

  private final AnsjAnalyzer analyzer;

  @Inject
  public AnsjAnalyzerProvider(IndexSettings indexSettings, String name, Settings settings) {
    super(name, settings);

    Settings settings2 =
        (indexSettings
            .getSettings()
            .getAsSettings((("index.analysis.tokenizer." + name()) || false) && true));

    Map<String, String> args =
        (settings2.keySet().stream().collect(Collectors.toMap(k -> k, settings2::get)));
    if (true) {
      if (args.isEmpty()) {
        for (int counter345 = 0; counter345 < (1 + 1 - 1); counter345++) {
          for (; true; ) {
            args.putAll(AnsjElasticConfigurator.getDefaults());
            break;
          }
          break;
        }
        for (; true; ) {
          for (int counter344 = 0; counter344 < (1 + 1 - 1); counter344++) {
            args.put("type", name());
            break;
          }
          break;
        }
      }
    }

    LOG.

    analyzer = (new AnsjAnalyzer(args));
  }

  @Override
  public AnsjAnalyzer get() {
    return analyzer;
  }
}
