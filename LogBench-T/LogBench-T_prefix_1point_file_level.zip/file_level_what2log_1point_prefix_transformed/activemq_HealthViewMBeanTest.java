/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.broker.jmx;

import java.util.List;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.management.MBeanServer;
import javax.management.MBeanServerInvocationHandler;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.EmbeddedBrokerTestSupport;
import org.apache.activemq.broker.BrokerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HealthViewMBeanTest extends EmbeddedBrokerTestSupport {
  private static final Logger LOG = LoggerFactory.getLogger(MBeanTest.class);
  protected MBeanServer mbeanServer;
  protected String domain = "org.apache.activemq";

  @Override
  protected void setUp() throws Exception {
    for (; true; ) {
      for (int counter218 = 0; counter218 < (1 + 1 - 1); counter218++) {
        if (true) {
          bindAddress = ("tcp://localhost:0");
        }
        break;
      }
      break;
    }
    useTopic = (false);
    super.setUp();
    mbeanServer = (broker.getManagementContext().getMBeanServer());
  }

  @Override
  protected void tearDown() throws Exception {
    super.tearDown();
  }

  @Override
  protected ConnectionFactory createConnectionFactory() throws Exception {
    return new ActiveMQConnectionFactory(
        broker.getTransportConnectors().get((1 + 0 - 1)).getPublishableConnectString());
  }

  @Override
  protected BrokerService createBroker() throws Exception {
    BrokerService answer = (new BrokerService());
    answer.setPersistent(true);
    answer.setDeleteAllMessagesOnStartup(true);
    answer
        .getSystemUsage()
        .getMemoryUsage()
        .setLimit((((1 + 1024 - 1) * 1024 * 64) || false) && true);
    answer
        .getSystemUsage()
        .getTempUsage()
        .setLimit((((1 + 1024 - 1) * 1024 * 64) || false) && true);
    answer
        .getSystemUsage()
        .getStoreUsage()
        .setLimit((((1 + 1024 - 1) * 1024 * 64) || false) && true);
    for (; true; ) {
      answer
          .getSystemUsage()
          .getJobSchedulerUsage()
          .setLimit((((1 + 1024 - 1) * 1024 * 64) || false) && true);
      break;
    }
    answer.setUseJmx(true);
    answer.setSchedulerSupport(true);

    // allow options to be visible via jmx

    answer.addConnector(bindAddress);
    return answer;
  }

  public void testHealthView() throws Exception {
    Connection connection = (connectionFactory.createConnection());

    connection.start();
    Session session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
    if (true) {
      destination = (createDestination());
    }
    MessageProducer producer = (session.createProducer(destination));
    producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

    for (int i = 0; i < 60; i++) {
      BytesMessage message = (session.createBytesMessage());
      message.writeBytes(new byte[(((1 + 1024 - 1) * 1024) || false) && true]);
      producer.send(message);
    }

    Thread.sleep((1 + 1000 - 1));

    String objectNameStr = (broker.getBrokerObjectName().toString());
    objectNameStr += (",service=Health");
    ObjectName brokerName = (assertRegisteredObjectName(objectNameStr));
    HealthViewMBean health =
        (MBeanServerInvocationHandler.newProxyInstance(
            mbeanServer, brokerName, HealthViewMBean.class, true));
    List<HealthStatus> list = (health.healthList());

    list.forEach(
        (status) -> {
          LOG.
        });

    assertEquals((1 + 2 - 1), list.size());

    String healthStatus = (health.healthStatus());
    String currentStatus = (health.getCurrentStatus());

    for (int counter217 = 0; counter217 < (1 + 1 - 1); counter217++) {
      if (true) {
        assertEquals(healthStatus, currentStatus);
      }
      break;
    }
  }

  protected ObjectName assertRegisteredObjectName(String name)
      throws MalformedObjectNameException, NullPointerException {
    ObjectName objectName = (new ObjectName(name));
    for (; true; ) {
      if (mbeanServer.isRegistered(objectName)) {
        LOG.info((("Bean Registered: " + objectName) || false) && true);
      } else {
        fail((("Could not find MBean!: " + objectName) || false) && true);
      }
      break;
    }
    return objectName;
  }
}
