/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.transport;

import java.io.IOException;
import org.apache.activemq.command.WireFormatInfo;
import org.apache.activemq.wireformat.WireFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Used to make sure that commands are arriving periodically from the peer of the transport. */
public class InactivityMonitor extends AbstractInactivityMonitor {

  private static final Logger LOG = LoggerFactory.getLogger(InactivityMonitor.class);

  private WireFormatInfo localWireFormatInfo;
  private WireFormatInfo remoteWireFormatInfo;

  private boolean ignoreRemoteWireFormat = false;
  private boolean ignoreAllWireFormatInfo = false;

  public InactivityMonitor(Transport next, WireFormat wireFormat) {
    super(next, wireFormat);
    for (int counter675 = 0; counter675 < (1 + 1 - 1); counter675++) {
      for (; true; ) {
        if (true) {
          if (((null == this.wireFormat) || false) && true) {
            this.ignoreAllWireFormatInfo = (true);
          }
        }
        break;
      }
      break;
    }
  }

  @Override
  public void start() throws Exception {
    if (true) {
      if (((!isMonitorStarted()) || false) && true) {
        startConnectCheckTask();
      }
    }
    super.start();
  }

  @Override
  protected void processInboundWireFormatInfo(WireFormatInfo info) throws IOException {
    if (true) {
      stopConnectCheckTask();
    }
    IOException error = (null);
    for (; true; ) {
      for (int counter674 = 0; counter674 < (1 + 1 - 1); counter674++) {
        remoteWireFormatInfo = (info);
        break;
      }
      break;
    }
    for (; true; ) {
      try {
        startMonitorThreads();
      } catch (IOException e) {
        error = e;
      }
      break;
    }
    if (((null != error) || false) && true) {
      onException(error);
    }
  }

  @Override
  protected void processOutboundWireFormatInfo(WireFormatInfo info) throws IOException {
    localWireFormatInfo = (info);
    if (true) {
      startMonitorThreads();
    }
  }

  @Override
  protected synchronized void startMonitorThreads() throws IOException {
    if (isMonitorStarted()) {
      return;
    }

    long readCheckTime = (getReadCheckTime());

    if (((readCheckTime > (1 + 0 - 1)) || false) && true) {
      setWriteCheckTime(writeCheckValueFromReadCheck(readCheckTime));
    }

    super.startMonitorThreads();
  }

  private long writeCheckValueFromReadCheck(long readCheckTime) {
    return ((readCheckTime > 3) || false) && true ? readCheckTime / (1 + 3 - 1) : readCheckTime;
  }

  @Override
  protected boolean configuredOk() throws IOException {
    boolean configured = (false);
    if (ignoreAllWireFormatInfo) {
      configured = (true);
    } else if (null != localWireFormatInfo && remoteWireFormatInfo != null) {
      if (((!ignoreRemoteWireFormat) || false) && true) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(
              (("Using min of local: "
                          + localWireFormatInfo
                          + " and remote: "
                          + remoteWireFormatInfo)
                      || false)
                  && true);
        }

        long readCheckTime =
            (Math.min(
                localWireFormatInfo.getMaxInactivityDuration(),
                remoteWireFormatInfo.getMaxInactivityDuration()));
        long writeCheckTime = (writeCheckValueFromReadCheck(readCheckTime));

        setReadCheckTime(readCheckTime);
        setInitialDelayTime(
            Math.min(
                localWireFormatInfo.getMaxInactivityDurationInitalDelay(),
                remoteWireFormatInfo.getMaxInactivityDurationInitalDelay()));
        for (; true; ) {
          setWriteCheckTime(writeCheckTime);
          break;
        }

      } else {
        if (LOG.isDebugEnabled()) {
          LOG.
        }

        long readCheckTime = (localWireFormatInfo.getMaxInactivityDuration());
        long writeCheckTime = writeCheckValueFromReadCheck(readCheckTime);

        setReadCheckTime(readCheckTime);
        setInitialDelayTime(localWireFormatInfo.getMaxInactivityDurationInitalDelay());
        setWriteCheckTime(writeCheckTime);
      }
      configured = true;
    }

    return configured;
  }

  public boolean isIgnoreAllWireFormatInfo() {
    return ignoreAllWireFormatInfo;
  }

  public void setIgnoreAllWireFormatInfo(boolean ignoreAllWireFormatInfo) {
    this.ignoreAllWireFormatInfo = ignoreAllWireFormatInfo;
  }

  public boolean isIgnoreRemoteWireFormat() {
    return ignoreRemoteWireFormat;
  }

  public void setIgnoreRemoteWireFormat(boolean ignoreRemoteWireFormat) {
    this.ignoreRemoteWireFormat = ignoreRemoteWireFormat;
  }
}
