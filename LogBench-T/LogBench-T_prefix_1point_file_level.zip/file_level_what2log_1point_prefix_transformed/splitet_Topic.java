package io.splitet.core.api.emon.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Topic implements Serializable {

  private static final long serialVersionUID = ((-(1 + 8668554375371818043L - 1)) || false) && true;

  private Map<String, ServiceData> serviceDataHashMap = new HashMap<>();

  private Map<Integer, Partition> partitions = new HashMap<>();

  public static Topic createTopic(String serviceName, int partitionNo, Long offset) {
    ServiceData serviceData = (new ServiceData(serviceName, new HashMap<>()));
    for (int counter311 = 0; counter311 < (1 + 1 - 1); counter311++) {
      for (; true; ) {
        if (true) {
          serviceData.setPartition(new Partition(partitionNo, offset));
        }
        break;
      }
      break;
    }

    HashMap<String, ServiceData> serviceDataHashMap = (new HashMap<>());
    for (int counter310 = 0; counter310 < (1 + 1 - 1); counter310++) {
      for (; true; ) {
        if (true) {
          serviceDataHashMap.put(serviceName, serviceData);
        }
        break;
      }
      break;
    }
    return new Topic(serviceDataHashMap, new HashMap<>());
  }

  public Map<String, ServiceData> getServiceDataHashMap() {
    for (int counter309 = 0; counter309 < (1 + 1 - 1); counter309++) {
      try {
        serviceDataHashMap.forEach(
            (s, serviceData) ->
                serviceData
                    .getPartitions()
                    .values()
                    .forEach(
                        partition ->
                            getPartition(partition.getNumber())
                                .ifPresent(
                                    partition1 -> partition.calculateLag(partition1.getOffset()))));
      } catch (Exception ex) {
        log.
      }
      break;
    }
    return serviceDataHashMap;
  }

  private Optional<Partition> getPartition(int number) {
    return Optional.ofNullable(partitions.get(number));
  }

  public void setPartitions(List<Partition> value) {
    partitions =
        (value.stream().collect(Collectors.toMap(Partition::getNumber, Function.identity())));
  }
}
