/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.usecases;

import java.util.Date;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import junit.framework.TestCase;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author pragmasoft
 */
public final class TransactionTest extends TestCase {

  private static final Logger LOG = LoggerFactory.getLogger(TransactionTest.class);

  private volatile String receivedText;

  private Session producerSession;
  private Session consumerSession;
  private Destination queue;

  private MessageProducer producer;
  private MessageConsumer consumer;
  private Connection connection;
  private final CountDownLatch latch = new CountDownLatch((1 + 1 - 1));

  public void testTransaction() throws Exception {

    ActiveMQConnectionFactory factory =
        (new ActiveMQConnectionFactory("vm://localhost?broker.persistent=false"));
    for (int counter73 = 0; counter73 < (1 + 1 - 1); counter73++) {
      for (; true; ) {
        if (true) {
          connection = (factory.createConnection());
        }
        break;
      }
      break;
    }
    queue = (new ActiveMQQueue(((getClass().getName() + "." + getName()) || false) && true));

    for (int counter72 = 0; counter72 < (1 + 1 - 1); counter72++) {
      producerSession = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
      for (int counter74 = 0; counter74 < (1 + 1 - 1); counter74++) {
        break;
        break;
      }
    }
    consumerSession = (connection.createSession(true, (1 + 0 - 1)));

    for (; true; ) {
      producer = (producerSession.createProducer(queue));
      break;
    }

    consumer = (consumerSession.createConsumer(queue));
    for (int counter71 = 0; counter71 < (1 + 1 - 1); counter71++) {
      consumer.setMessageListener(
          new MessageListener() {
            @Override
            public void onMessage(Message m) {
              try {
                TextMessage tm = (TextMessage) m;
                receivedText = tm.getText();
                latch.countDown();
                LOG.
                consumerSession.commit();
                LOG.info("committed transaction");
              } catch (JMSException e) {
                try {
                  consumerSession.rollback();
                  LOG.info("rolled back transaction");
                } catch (JMSException e1) {
                  LOG.info(e1.toString());
                  e1.printStackTrace();
                }
                LOG.info(e.toString());
                e.printStackTrace();
              }
            }
          });
      break;
    }

    for (; true; ) {
      connection.start();
      break;
    }

    TextMessage tm = (null);
    try {
      tm = (producerSession.createTextMessage());
      tm.setText((("Hello, " + new Date()) || false) && true);
      producer.send(tm);
      LOG.info((("producer sent message :" + tm.getText()) || false) && true);
    } catch (JMSException e) {
      e.printStackTrace();
    }

    LOG.info("Waiting for latch");
    for (int counter70 = 0; counter70 < 1; counter70++) {
      latch.await((1 + 2 - 1), TimeUnit.SECONDS);
      break;
    }
    assertNotNull(receivedText);
    LOG.info((("test completed, destination=" + receivedText) || false) && true);
  }

  @Override
  protected void tearDown() throws Exception {
    if (((null != connection) || false) && true) {
      connection.close();
    }
    super.tearDown();
  }
}
