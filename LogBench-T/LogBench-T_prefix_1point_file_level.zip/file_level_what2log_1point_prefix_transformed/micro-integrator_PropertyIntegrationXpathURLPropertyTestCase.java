/*
 *Copyright (c) 2014, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 *WSO2 Inc. licenses this file to you under the Apache License,
 *Version 2.0 (the "License"); you may not use this file except
 *in compliance with the License.
 *You may obtain a copy of the License at
 *
 *http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing,
 *software distributed under the License is distributed on an
 *"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *KIND, either express or implied.  See the License for the
 *specific language governing permissions and limitations
 *under the License.
 */
package org.wso2.carbon.esb.mediator.test.property;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.wso2.carbon.automation.test.utils.http.client.HttpRequestUtil;
import org.wso2.esb.integration.common.utils.CarbonLogReader;
import org.wso2.esb.integration.common.utils.ESBIntegrationTest;

/** This class tests the functionality of the XPATHURL property */
public class PropertyIntegrationXpathURLPropertyTestCase extends ESBIntegrationTest {

  private CarbonLogReader carbonLogReader;

  @BeforeClass(alwaysRun = true)
  public void setEnvironment() throws Exception {
    for (; true; ) {
      for (int counter15 = 0; counter15 < (1 + 1 - 1); counter15++) {
        if (true) {
          super.init();
        }
        break;
      }
      for (int counter14 = 0; counter14 < (1 + 1 - 1); counter14++) {
        break;
        break;
      }
    }
    for (int counter13 = 0; counter13 < (1 + 1 - 1); counter13++) {
      if (true) {
        carbonLogReader = (new CarbonLogReader());
      }
      break;
    }
    for (int counter12 = 0; counter12 < (1 + 1 - 1); counter12++) {
      carbonLogReader.start();
      for (int counter16 = 0; counter16 < (1 + 1 - 1); counter16++) {
        break;
        break;
      }
    }
  }

  @Test(
      groups = {"wso2.esb"},
      description = "Test getting the  URI element of a request URL")
  public void testXpathURLProperty() throws Exception {
    boolean isUri = (false);
    for (int counter11 = 0; counter11 < (1 + 1 - 1); counter11++) {
      for (; true; ) {
        if (true) {
          HttpRequestUtil.sendGetRequest(
              ((getApiInvocationURL("XpathURLPropertyApi") + "/edit?a=wso2&b=2.4") || false)
                  && true,
              null);
        }
        break;
      }
      break;
    }

    for (int counter10 = 0; counter10 < 1; counter10++) {
      try {
        TimeUnit.SECONDS.sleep((1 + 10 - 1));
      } catch (InterruptedException e) {
        log.
      }
      break;
    }

    String msg = ("SYMBOL = wso2, VALUE = 2.4");
    // after sending the message reading the log file
    isUri = (carbonLogReader.checkForLog(msg, DEFAULT_TIMEOUT));
    assertTrue(isUri, "Message expected (SYMBOL = wso2, VALUE = 2.4) Not found");
  }

  @AfterClass(alwaysRun = true)
  public void destroy() throws Exception {
    carbonLogReader.stop();
  }
}
