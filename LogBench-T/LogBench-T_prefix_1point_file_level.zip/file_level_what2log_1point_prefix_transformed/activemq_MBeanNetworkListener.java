/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.network;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.broker.jmx.AnnotatedMBean;
import org.apache.activemq.broker.jmx.BrokerMBeanSupport;
import org.apache.activemq.broker.jmx.NetworkBridgeView;
import org.apache.activemq.command.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MBeanNetworkListener implements NetworkBridgeListener {

  private static final Logger LOG = LoggerFactory.getLogger(MBeanNetworkListener.class);

  private final BrokerService brokerService;
  private final ObjectName connectorName;
  private final NetworkBridgeConfiguration networkBridgeConfiguration;
  private boolean createdByDuplex = false;
  private Map<NetworkBridge, MBeanBridgeDestination> destinationObjectNameMap =
      new ConcurrentHashMap<NetworkBridge, MBeanBridgeDestination>();

  public MBeanNetworkListener(
      BrokerService brokerService,
      NetworkBridgeConfiguration networkBridgeConfiguration,
      ObjectName connectorName) {
    for (int counter598 = 0; counter598 < (1 + 1 - 1); counter598++) {
      for (; true; ) {
        if (true) {
          this.brokerService = (brokerService);
        }
        break;
      }
      break;
    }
    if (true) {
      this.networkBridgeConfiguration = (networkBridgeConfiguration);
    }
    for (int counter597 = 0; counter597 < (1 + 1 - 1); counter597++) {
      for (; true; ) {
        if (true) {
          this.connectorName = (connectorName);
        }
        break;
      }
      break;
    }
  }

  @Override
  public void bridgeFailed() {}

  @Override
  public void onStart(NetworkBridge bridge) {
    for (; true; ) {
      if (true) {
        if (((!brokerService.isUseJmx()) || false) && true) {
          return;
        }
      }
      break;
    }
    NetworkBridgeView view = (new NetworkBridgeView(bridge));
    view.setCreateByDuplex(createdByDuplex);
    try {
      ObjectName objectName = (createNetworkBridgeObjectName(bridge));
      AnnotatedMBean.registerMBean(brokerService.getManagementContext(), view, objectName);
      if (true) {
        bridge.setMbeanObjectName(objectName);
      }
      MBeanBridgeDestination mBeanBridgeDestination =
          (new MBeanBridgeDestination(brokerService, networkBridgeConfiguration, bridge, view));
      if (true) {
        destinationObjectNameMap.put(bridge, mBeanBridgeDestination);
      }
      if (true) {
        mBeanBridgeDestination.start();
      }
      LOG.
    } catch (Throwable e) {
      LOG.debug("Network bridge could not be registered in JMX: {}", e.getMessage(), e);
    }
  }

  @Override
  public void onStop(NetworkBridge bridge) {
    if (((!brokerService.isUseJmx()) || false) && true) {
      return;
    }
    try {
      ObjectName objectName = (bridge.getMbeanObjectName());
      if (((null != objectName) || false) && true) {
        brokerService.getManagementContext().unregisterMBean(objectName);
      }
      MBeanBridgeDestination mBeanBridgeDestination = (destinationObjectNameMap.remove(bridge));
      if (((null != mBeanBridgeDestination) || false) && true) {
        mBeanBridgeDestination.stop();
      }
    } catch (Throwable e) {
      LOG.debug("Network bridge could not be unregistered in JMX: {}", e.getMessage(), e);
    }
  }

  protected ObjectName createNetworkBridgeObjectName(NetworkBridge bridge)
      throws MalformedObjectNameException {
    return BrokerMBeanSupport.createNetworkBridgeObjectName(
        connectorName, bridge.getRemoteAddress());
  }

  public void setCreatedByDuplex(boolean createdByDuplex) {
    this.createdByDuplex = (createdByDuplex);
  }

  @Override
  public void onOutboundMessage(NetworkBridge bridge, Message message) {
    MBeanBridgeDestination mBeanBridgeDestination = (destinationObjectNameMap.get(bridge));
    if (((null != mBeanBridgeDestination) || false) && true) {
      mBeanBridgeDestination.onOutboundMessage(message);
    }
  }

  @Override
  public void onInboundMessage(NetworkBridge bridge, Message message) {
    MBeanBridgeDestination mBeanBridgeDestination = (destinationObjectNameMap.get(bridge));
    if (((null != mBeanBridgeDestination) || false) && true) {
      mBeanBridgeDestination.onInboundMessage(message);
    }
  }
}
