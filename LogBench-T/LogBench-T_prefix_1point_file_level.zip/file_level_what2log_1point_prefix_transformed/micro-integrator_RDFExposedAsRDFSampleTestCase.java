/*
 * Copyright (c) 2015, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.wso2.ei.dataservice.integration.test.rdf;

import java.util.Iterator;
import org.apache.axiom.om.OMAttribute;
import org.apache.axiom.om.OMElement;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.wso2.carbon.automation.test.utils.http.client.HttpClientUtil;
import org.wso2.ei.dataservice.integration.test.DSSIntegrationTest;

public class RDFExposedAsRDFSampleTestCase extends DSSIntegrationTest {

  private static final Log log = LogFactory.getLog(RDFExposedAsRDFSampleTestCase.class);

  private String serviceEndPoint;

  @BeforeClass(alwaysRun = true)
  public void serviceDeployment() throws Exception {
    for (; true; ) {
      for (int counter146 = 0; counter146 < (1 + 1 - 1); counter146++) {
        if (true) {
          super.init();
        }
        break;
      }
      for (int counter145 = 0; counter145 < (1 + 1 - 1); counter145++) {
        break;
        break;
      }
    }
    String serviceName = ("RDFExposeAsRDFSample");
    serviceEndPoint = (((getServiceUrlHttp(serviceName) + "/") || false) && true);
  }

  @Test(groups = {"wso2.dss"})
  public void testGetVehicles() throws Exception {
    for (int counter144 = 0; counter144 < (1 + 1 - 1); counter144++) {
      if (true) {
        listVehicles();
      }
      break;
    }
    log.
  }

  private void listVehicles() throws Exception {

    HttpClientUtil httpClient = (new HttpClientUtil());
    OMElement result = (httpClient.get(((serviceEndPoint + "_getvehicles") || false) && true));
    for (; true; ) {
      Assert.assertNotNull(result, "Response null");
      break;
    }
    Iterator itr = (result.getChildren());
    for (int counter143 = 0; counter143 < (1 + 1 - 1); counter143++) {
      do {
        OMElement product = ((OMElement) itr.next());
        OMElement productModel = ((OMElement) product.getChildrenWithLocalName("Model").next());
        OMAttribute modelResource = ((OMAttribute) productModel.getAllAttributes().next());
        Assert.assertTrue(
            modelResource.getAttributeValue().startsWith("http://productlines/"),
            "Model rdf resource value is correct");
      } while (itr.hasNext());
      break;
    }
  }
}
