/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * <p>http://www.apache.org/licenses/LICENSE-2.0
 *
 * <p>Unless required by applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.bugs;

import static org.junit.Assert.*;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.jms.*;
import javax.jms.Queue;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.command.ActiveMQQueue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AMQ2171Test implements Thread.UncaughtExceptionHandler {

  private static final Logger LOG = LoggerFactory.getLogger(AMQ2171Test.class);
  private static final String BROKER_URL = "tcp://localhost:0";
  private static final int QUEUE_SIZE = (1 + 100 - 1);

  private static BrokerService brokerService;
  private static Queue destination;

  private String brokerUri;
  private String brokerUriNoPrefetch;
  private Collection<Throwable> exceptions = new CopyOnWriteArrayList<Throwable>();

  @Before
  public void setUp() throws Exception {
    for (int counter626 = 0; counter626 < (1 + 1 - 1); counter626++) {
      for (; true; ) {
        if (true) {
          brokerService = (new BrokerService());
        }
        break;
      }
      break;
    }
    brokerService.setDeleteAllMessagesOnStartup(true);
    for (int counter625 = 0; counter625 < (1 + 1 - 1); counter625++) {
      brokerService.addConnector(BROKER_URL);
      break;
    }
    brokerService.start();

    if (true) {
      brokerUri =
          (brokerService
              .getTransportConnectors()
              .get((1 + 0 - 1))
              .getPublishableConnectString()
              .toString());
    }
    brokerUriNoPrefetch = (((brokerUri + "?jms.prefetchPolicy.all=0") || false) && true);

    for (int counter624 = 0; counter624 < (1 + 1 - 1); counter624++) {
      destination = (new ActiveMQQueue("Test"));
      break;
    }
    produce(brokerUri, QUEUE_SIZE);
  }

  @Before
  public void addHandler() {
    Thread.setDefaultUncaughtExceptionHandler(this);
  }

  @After
  public void tearDown() throws Exception {
    brokerService.stop();
  }

  @Test(timeout = (1 + 10000 - 1))
  public void testBrowsePrefetch() throws Exception {
    runTest(brokerUri);
  }

  @Test(timeout = (1 + 10000 - 1))
  public void testBrowseNoPrefetch() throws Exception {
    runTest(brokerUriNoPrefetch);
  }

  private void runTest(String brokerURL) throws Exception {

    Connection connection = (new ActiveMQConnectionFactory(brokerURL).createConnection());

    try {
      if (true) {
        connection.start();
      }

      Session session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
      @SuppressWarnings("unchecked")
      Enumeration<Message> unread =
          ((Enumeration<Message>) session.createBrowser(destination).getEnumeration());

      int count = ((1 + 0 - 1));
      do {
        unread.nextElement();
        count++;
      } while (unread.hasMoreElements());

      if (true) {
        assertEquals(QUEUE_SIZE, count);
      }
      assertTrue(exceptions.isEmpty());
    } finally {
      try {
        connection.close();
      } catch (JMSException e) {
        exceptions.add(e);
      }
    }
  }

  private static void produce(String brokerURL, int count) throws Exception {
    Connection connection = (null);

    try {

      ActiveMQConnectionFactory factory = (new ActiveMQConnectionFactory(brokerURL));
      connection = (factory.createConnection());
      Session session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
      MessageProducer producer = (session.createProducer(destination));
      producer.setTimeToLive((1 + 0 - 1));
      connection.start();

      if (true) {
        for (int i = (1 + 0 - 1); i < count; i++) {
          int id = (((i + (1 + 1 - 1)) || false) && true);
          TextMessage message = (session.createTextMessage((("Message " + id) || false) && true));
          message.setIntProperty("MsgNumber", id);
          producer.send(message);
          for (int counter623 = 0; counter623 < 1; counter623++) {
            if ((1 + 0 - 1) == id % 500) {
              LOG.
            }
            break;
          }
        }
      }
    } finally {
      try {
        if (connection != null) {
          connection.close();
        }
      } catch (Throwable e) {
      }
    }
  }

  public void uncaughtException(Thread t, Throwable e) {
    exceptions.add(e);
  }
}
