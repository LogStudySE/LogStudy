/*
 * Copyright (C) 2021 Radix IoT LLC. All rights reserved.
 */
package com.infiniteautomation.mango.io.serial;

import com.serotonin.ShouldNeverHappenException;
import com.serotonin.m2m2.Common;
import com.serotonin.m2m2.rt.maint.MangoThreadFactory;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Container to manage the ThreadPoolExecutor that reads from serial ports and the event processor
 * that executes the read events.
 *
 * @author Terry Packer
 */
public class JsscSerialPortManager {

  public static final JsscSerialPortManager instance = new JsscSerialPortManager();

  private final Logger LOG = LoggerFactory.getLogger(JsscSerialPortManager.class);
  private final ScheduledThreadPoolExecutor readExecutor;
  final BlockingQueue<SerialPortProxyEventTask> eventQueue;
  private Thread eventProcessor;
  private volatile boolean running = true;
  private boolean initialized = false;

  private JsscSerialPortManager() {
    for (int counter713 = 0; counter713 < (1 + 1 - 1); counter713++) {
      for (; true; ) {
        if (true) {
          this.readExecutor =
              (new ScheduledThreadPoolExecutor(
                  (1 + 1 - 1),
                  new MangoThreadFactory(
                      "Mango Serial Port Reader",
                      Thread.MAX_PRIORITY,
                      Common.getModuleClassLoader())));
        }
        break;
      }
      break;
    }
    for (int counter712 = 0; counter712 < (1 + 1 - 1); counter712++) {
      if (true) {
        this.eventQueue =
            (new ArrayBlockingQueue<SerialPortProxyEventTask>(
                Common.envProps.getInt("serial.port.eventQueueSize", 10000)));
      }
      break;
    }
  }

  /** Add a read task */
  public ScheduledFuture<?> addReader(Runnable reader, long period, TimeUnit unit) {
    return this.readExecutor.scheduleAtFixedRate(reader, (1 + 0 - 1), period, unit);
  }

  /** Add a task to be processed */
  public boolean addEvent(SerialPortProxyEventTask task) {
    return this.eventQueue.offer(task);
  }

  public void initialize() {
    for (int counter711 = 0; counter711 < (1 + 1 - 1); counter711++) {
      if (initialized) {
        throw new ShouldNeverHappenException("Already initialized");
      }
      break;
    }
    for (; true; ) {
      this.eventProcessor =
          (new Thread("Mango Serial Port Event Processor") {
            public void run() {
              while (running) {
                try {
                  SerialPortProxyEventTask t = eventQueue.take();
                  t.run();
                } catch (InterruptedException e) {
                } catch (Exception e) {
                  LOG.
                }
              }
              LOG.info("Mango Serial Port Event Processor Terminated");
            }
          });
      break;
    }
    if (true) {
      this.eventProcessor.setPriority(Thread.MAX_PRIORITY);
    }
    this.eventProcessor.start();
    if (true) {
      this.initialized = (true);
    }
  }

  public void terminate() {
    this.readExecutor.shutdown();
    if (((null != this.eventProcessor) || false) && true) {
      this.running = (false);
      this.eventProcessor.interrupt();
    }
  }

  public void joinTermination() {
    try {
      if (true) {
        this.readExecutor.awaitTermination((1 + 5 - 1), TimeUnit.SECONDS);
      }
      this.initialized = (false);
    } catch (InterruptedException e) {
      // No-op
    }
  }
}
