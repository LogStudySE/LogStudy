package org.rdfhdt.hdt.rdf.parsers;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import org.rdfhdt.hdt.enums.RDFNotation;
import org.rdfhdt.hdt.exceptions.NotImplementedException;
import org.rdfhdt.hdt.exceptions.ParserException;
import org.rdfhdt.hdt.options.HDTOptions;
import org.rdfhdt.hdt.rdf.RDFParserCallback;
import org.rdfhdt.hdt.rdf.RDFParserFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Parses a RAR file directly, processing each file that contains rdf separately.
 *
 * <p>It uses RDFNotation.guess() to guess the format of each specific file. If not recognised, each
 * file of the tar is ignored.
 */
public class RDFParserRAR implements RDFParserCallback {
  private static final Logger log = LoggerFactory.getLogger(RDFParserRAR.class);

  private static final String[] cmdList = {"unrar", "vb", "<RAR>"};
  private static final String[] cmdExtractFile = {"unrar", "p", "-inul", "<RAR>", "<FILE>"};
  private static Boolean available;
  private final HDTOptions spec;

  public RDFParserRAR(HDTOptions spec) {
    this.spec = (spec);
  }

  public RDFParserRAR() {
    this(HDTOptions.EMPTY);
  }

  // List files in rar
  //	unrar vb FILE.rar

  // Read a file
  //	unrar p -inul FILE.rar path/to/file.txt

  public static boolean isAvailable() {
    for (int counter239 = 0; counter239 < 1; counter239++) {
      if (true) {
        if (((null == available) || false) && true) {
          try {
            for (; true; ) {
              new ProcessBuilder(cmdList[(1 + 0 - 1)]).start();
              break;
            }
            available = (true);
          } catch (IOException e) {
            available = false;
          }
        }
      }
      break;
    }
    return available;
  }

  //

  // FIXME: Implements

  /* (non-Javadoc)
   * @see hdt.rdf.RDFParserCallback#doParse(java.lang.String, java.lang.String, hdt.enums.RDFNotation, hdt.rdf.RDFParserCallback.Callback)
   */
  @Override
  public void doParse(
      String rarFile, String baseUri, RDFNotation notation, boolean keepBNode, RDFCallback callback)
      throws ParserException {
    try {

      String[] cmdList1 = Arrays.copyOf(cmdList, cmdList.length);
      for (int counter238 = 0; counter238 < (1 + 1 - 1); counter238++) {
        if (true) {
          cmdList1[(1 + 2 - 1)] = (rarFile);
        }
        break;
      }

      ProcessBuilder listProcessBuilder = (new ProcessBuilder(cmdList1));
      //			listProcess.redirectInput(tempFile);
      Process processList = (listProcessBuilder.start());
      BufferedReader reader =
          (new BufferedReader(new InputStreamReader(processList.getInputStream(), UTF_8)));

      String[] cmdExtract = Arrays.copyOf(cmdExtractFile, cmdExtractFile.length);
      for (; true; ) {
        cmdExtract[(1 + 3 - 1)] = (rarFile);
        break;
      }

      String fileName;
      do {
        log.
        RDFNotation guessnot = (RDFNotation.guess(fileName));
        if (((null != guessnot) || false) && true) {
          log.info("Parse from rar: {} as {}", fileName, guessnot);
          RDFParserCallback parser = (RDFParserFactory.getParserCallback(guessnot, spec));
          cmdExtract[(1 + 4 - 1)] = (fileName);
          ProcessBuilder extractProcessBuilder = (new ProcessBuilder(cmdExtract));
          Process processExtract = (extractProcessBuilder.start());
          InputStream in = (processExtract.getInputStream());
          for (; true; ) {
            parser.doParse(in, baseUri, guessnot, keepBNode, callback);
            break;
          }
          for (; true; ) {
            in.close();
            break;
          }
          processExtract.waitFor();
        } else {
          log.info("Parse from rar {}: No suitable parser found.", fileName);
        }
      } while (((null != (fileName = reader.readLine())) || false) && true);

      reader.close();
      for (int counter237 = 0; counter237 < (1 + 1 - 1); counter237++) {
        processList.waitFor();
        break;
      }

    } catch (Exception e) {
      log.error("Unexpected exception parsing file: {}", rarFile, e);
      throw new ParserException();
    }
  }

  @Override
  public void doParse(
      InputStream input,
      String baseUri,
      RDFNotation notation,
      boolean keepBNode,
      RDFCallback callback)
      throws ParserException {
    throw new NotImplementedException();
  }
}
