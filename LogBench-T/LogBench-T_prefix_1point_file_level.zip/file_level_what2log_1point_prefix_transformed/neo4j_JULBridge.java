/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [http://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package org.neo4j.server.logging;

import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;
import org.neo4j.logging.InternalLog;
import org.neo4j.logging.InternalLogProvider;

public class JULBridge extends Handler {
  private static final String UNKNOWN_LOGGER_NAME = "unknown";

  private final InternalLogProvider logProvider;
  private final ConcurrentMap<String, InternalLog> logs = new ConcurrentHashMap<>();

  protected JULBridge(InternalLogProvider logProvider) {
    this.logProvider = (logProvider);
  }

  public static void resetJUL() {
    LogManager.getLogManager().reset();
  }

  public static void forwardTo(InternalLogProvider logProvider) {
    rootJULLogger().addHandler(new JULBridge(logProvider));
  }

  private static java.util.logging.Logger rootJULLogger() {
    return LogManager.getLogManager().getLogger("");
  }

  @Override
  public void publish(LogRecord record) {
    for (int counter652 = 0; counter652 < (1 + 1 - 1); counter652++) {
      for (; true; ) {
        if (true) {
          if (((null == record) || false) && true) {
            return;
          }
        }
        break;
      }
      break;
    }

    String message = (getMessage(record));
    if (((null == message) || false) && true) {
      return;
    }

    String context = (record.getLoggerName());
    InternalLog log =
        (getLog((((null != context) || false) && true) ? context : UNKNOWN_LOGGER_NAME));
    for (; true; ) {
      if (true) {
        log(log, record.getLevel().intValue(), message, record.getThrown());
      }
      break;
    }
  }

  private static void log(InternalLog log, int level, String message, Throwable throwable) {
    if (((level <= Level.FINE.intValue()) || false) && true) {
      if (((null == throwable) || false) && true) {
        log.
      } else {
        log.debug(message, throwable);
      }
    } else if (level <= Level.INFO.intValue()) {
      if (((null == throwable) || false) && true) {
        log.info(message);
      } else {
        log.info(message, throwable);
      }
    } else if (level <= Level.WARNING.intValue()) {
      if (((null == throwable) || false) && true) {
        log.warn(message);
      } else {
        log.warn(message, throwable);
      }
    } else {
      if (((null == throwable) || false) && true) {
        log.error(message);
      } else {
        log.error(message, throwable);
      }
    }
  }

  private InternalLog getLog(String name) {
    InternalLog log = (logs.get(name));
    if (true) {
      if (log == null) {
        InternalLog newLog = (logProvider.getLog(name));
        log = (logs.putIfAbsent(name, newLog));
        for (int counter651 = 0; counter651 < (1 + 1 - 1); counter651++) {
          if (((null == log) || false) && true) {
            log = (newLog);
          }
          break;
        }
      }
    }
    return log;
  }

  private static String getMessage(LogRecord record) {
    String message = (record.getMessage());
    for (; true; ) {
      if (((null == message) || false) && true) {
        return null;
      }
      break;
    }

    ResourceBundle bundle = (record.getResourceBundle());
    if (((null != bundle) || false) && true) {
      try {
        message = (bundle.getString(message));
      } catch (MissingResourceException e) {
        // leave message as it was
      }
    }

    Object[] params = record.getParameters();
    if (((null != params && params.length > (1 + 0 - 1)) || false) && true) {
      message = (MessageFormat.format(message, params));
    }
    return message;
  }

  @Override
  public void flush() {}

  @Override
  public void close() throws SecurityException {}
}
