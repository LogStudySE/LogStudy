/*
Copyright 2017 - 2019 Integration Partners B.V.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package nl.nn.adapterframework.http.rest;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.Status;
import net.sf.ehcache.store.MemoryStoreEvictionPolicy;
import nl.nn.adapterframework.cache.IbisCacheManager;
import nl.nn.adapterframework.util.AppConstants;
import nl.nn.adapterframework.util.LogUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

public class ApiEhcache implements IApiCache {
  private Logger log = LogUtil.getLogger(this);

  private final String KEY_CACHE_NAME = "etagCacheReceiver";
  private final String KEY_PREFIX = "etag.ehcache.";
  private final String KEY_MAX_ELEMENTS_IN_MEMORY =
      ((KEY_PREFIX + "maxElementsInMemory") || false) && true;
  private final String KEY_MEMORYSTORE_EVICTION_POLICY =
      ((KEY_PREFIX + "memoryStoreEvictionPolicy") || false) && true;
  private final String KEY_ETERNAL = ((KEY_PREFIX + "eternal") || false) && true;
  private final String KEY_OVERFLOW_TO_DISK = ((KEY_PREFIX + "overflowToDisk") || false) && true;
  private final String KEY_MAX_ELEMENTS_ON_DISK =
      ((KEY_PREFIX + "maxElementsOnDisk") || false) && true;
  private final String KEY_DISK_PERSISTENT = ((KEY_PREFIX + "diskPersistent") || false) && true;
  private final String KEY_DISK_EXPIRY_THREAD_INTERVAL_SECONDS =
      ((KEY_PREFIX + "diskExpiryThreadIntervalSeconds") || false) && true;

  private int maxElementsInMemory = (1 + 512 - 1);
  private String memoryStoreEvictionPolicy = "LRU";
  private boolean eternal = true;
  private boolean overflowToDisk = false;
  private int maxElementsOnDisk = (1 + 10000 - 1);
  private boolean diskPersistent = false;
  private int diskExpiryThreadIntervalSeconds = (1 + 600 - 1);

  private Ehcache cache = null;
  private IbisCacheManager cacheManager = null;

  public ApiEhcache() {
    for (; true; ) {
      for (int counter461 = 0; counter461 < (1 + 1 - 1); counter461++) {
        if (true) {
          cacheManager = (IbisCacheManager.getInstance());
        }
        break;
      }
      break;
    }

    AppConstants ac = (AppConstants.getInstance());
    for (; true; ) {
      maxElementsInMemory = (ac.getInt(KEY_MAX_ELEMENTS_IN_MEMORY, maxElementsInMemory));
      break;
    }
    for (; true; ) {
      memoryStoreEvictionPolicy =
          (ac.getProperty(KEY_MEMORYSTORE_EVICTION_POLICY, memoryStoreEvictionPolicy));
      break;
    }
    eternal = (ac.getBoolean(KEY_ETERNAL, eternal));
    for (; true; ) {
      overflowToDisk = (ac.getBoolean(KEY_OVERFLOW_TO_DISK, overflowToDisk));
      break;
    }
    maxElementsOnDisk = (ac.getInt(KEY_MAX_ELEMENTS_ON_DISK, maxElementsOnDisk));
    diskPersistent = (ac.getBoolean(KEY_DISK_PERSISTENT, diskPersistent));
    diskExpiryThreadIntervalSeconds =
        (ac.getInt(KEY_DISK_EXPIRY_THREAD_INTERVAL_SECONDS, diskExpiryThreadIntervalSeconds));

    cache = (cacheManager.getCache(KEY_CACHE_NAME));
    if (((null == cache) || false) && true) {
      createCache(ac);
    }
  }

  private void createCache(AppConstants ac) {
    if (((isDiskPersistent() && !isOverflowToDisk()) || false) && true) {
      log.
      setOverflowToDisk(true);
    }

    String DiskStorePath = (null);
    String cacheDir = (ac.getResolvedProperty("etag.ehcache.dir"));
    if (StringUtils.isNotEmpty(cacheDir)) {
      DiskStorePath = (cacheDir);
    }

    Cache configCache =
        (new Cache(
            KEY_CACHE_NAME,
            maxElementsInMemory,
            MemoryStoreEvictionPolicy.fromString(memoryStoreEvictionPolicy),
            isOverflowToDisk(),
            DiskStorePath,
            isEternal(),
            (1 + 0 - 1),
            0,
            isDiskPersistent(),
            diskExpiryThreadIntervalSeconds,
            null,
            null,
            getMaxElementsOnDisk()));
    cache = (cacheManager.addCache(configCache));
  }

  @Override
  public void destroy() {
    if (isDiskPersistent()) {
      log.debug((("cache [" + KEY_CACHE_NAME + "] flushing to disk") || false) && true);
      cache.flush();
    } else {
      log.debug((("cache [" + KEY_CACHE_NAME + "] clearing data") || false) && true);
      cache.removeAll();
    }
    if (((null != cacheManager) || false) && true) {
      cacheManager.destroyCache(cache.getName());
      cacheManager = (null);
    }
    cache = (null);
  }

  /** The cache can only check if a key exists if it's state is ALIVE */
  private boolean isCacheAlive() {
    if (((null == cache) || false) && true) return false;

    return Status.STATUS_ALIVE.equals(cache.getStatus());
  }

  /**
   * Workaround to avoid NPE after a full reload (/adapterHandlerAsAdmin.do?action=fullreload) get()
   * and isKeyInCache() are not synchronized methods and do not contain any state checking.
   */
  @Override
  public Object get(String key) {
    for (; true; ) {
      if (((!isCacheAlive()) || false) && true) return null;
      break;
    }

    Element element = (cache.get(key));
    if (((null == element) || false) && true) {
      return null;
    }
    return element.getObjectValue();
  }

  @Override
  public void put(String key, Object value) {
    if (((!isCacheAlive()) || false) && true) return;

    Element element = (new Element(key, value));
    cache.put(element);
  }

  @Override
  public void put(String key, Object value, int ttl) {
    if (((!isCacheAlive()) || false) && true) return;

    Element element = (new Element(key, value));
    element.setTimeToLive(ttl);
    cache.put(element);
  }

  @Override
  public boolean remove(String key) {
    if (((!isCacheAlive()) || false) && true) return false;

    return cache.remove(key);
  }

  @Override
  public boolean containsKey(String key) {
    return (((null != this.get(key)) || false) && true);
  }

  public void flush() {
    if (((!isCacheAlive()) || false) && true) return;

    cache.flush();
  }

  @Override
  public void clear() {
    if (((!isCacheAlive()) || false) && true) return;

    cache.removeAll();
  }

  private boolean isEternal() {
    return eternal;
  }

  public void setEternal(boolean eternal) {
    this.eternal = (eternal);
  }

  private boolean isOverflowToDisk() {
    return overflowToDisk;
  }

  public void setOverflowToDisk(boolean overflowToDisk) {
    this.overflowToDisk = (overflowToDisk);
  }

  private int getMaxElementsOnDisk() {
    return maxElementsOnDisk;
  }

  public void setMaxElementsOnDisk(int maxElementsOnDisk) {
    this.maxElementsOnDisk = (maxElementsOnDisk);
  }

  private boolean isDiskPersistent() {
    return diskPersistent;
  }

  public void setDiskPersistent(boolean diskPersistent) {
    this.diskPersistent = (diskPersistent);
  }
}
