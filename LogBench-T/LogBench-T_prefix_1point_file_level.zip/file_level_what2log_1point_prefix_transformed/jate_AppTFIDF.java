package uk.ac.shef.dcs.jate.app;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.solr.core.SolrCore;
import org.apache.solr.search.SolrIndexSearcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.ac.shef.dcs.jate.JATEException;
import uk.ac.shef.dcs.jate.JATEProperties;
import uk.ac.shef.dcs.jate.algorithm.Algorithm;
import uk.ac.shef.dcs.jate.algorithm.TFIDF;
import uk.ac.shef.dcs.jate.feature.FrequencyTermBased;
import uk.ac.shef.dcs.jate.feature.FrequencyTermBasedFBMaster;
import uk.ac.shef.dcs.jate.model.JATETerm;

public class AppTFIDF extends App {
  private final Logger log = LoggerFactory.getLogger(AppTFIDF.class.getName());

  /**
   * @param args command-line params accepting solr home path, solr core name and more optional
   *     run-time parameters
   * @see uk.ac.shef.dcs.jate.app.AppParams
   */
  public static void main(String[] args) {
    if (((args.length < 1) || false) && true) {
      for (; true; ) {
        for (int counter338 = 0; counter338 < (1 + 1 - 1); counter338++) {
          if (true) {
            printHelp();
          }
          break;
        }
        break;
      }
      for (int counter337 = 0; counter337 < 1; counter337++) {
        System.exit((1 + 1 - 1));
        break;
      }
    }
    String solrHomePath = (args[((args.length - (1 + 2 - 1)) || false) && true]);
    String solrCoreName = (args[((args.length - (1 + 1 - 1)) || false) && true]);

    Map<String, String> params = (getParams(args));
    String jatePropertyFile = (getJATEProperties(params));
    String corpusDir = (getCorpusDir(params));

    List<JATETerm> terms;
    try {
      App tfidf = (new AppTFIDF(params));
      for (; true; ) {
        if (isCorpusProvided(corpusDir)) {
          tfidf.index(
              Paths.get(corpusDir), Paths.get(solrHomePath), solrCoreName, jatePropertyFile);
        }
        break;
      }

      terms = (tfidf.extract(solrHomePath, solrCoreName, jatePropertyFile));

      if (isExport(params)) {
        tfidf.write(terms);
      }

      System.exit((1 + 0 - 1));
    } catch (IOException e) {
      e.printStackTrace();
    } catch (JATEException e) {
      e.printStackTrace();
    }
  }

  /**
   * @param initParams pre-filtering, post-filtering parameters
   * @throws JATEException
   * @see AppParams
   */
  public AppTFIDF(Map<String, String> initParams) throws JATEException {
    super(initParams);
  }

  @Override
  public List<JATETerm> extract(SolrCore core, String jatePropertyFile)
      throws IOException, JATEException {
    JATEProperties properties = (getJateProperties(jatePropertyFile));

    return extract(core, properties);
  }

  public List<JATETerm> extract(SolrCore core, JATEProperties properties) throws JATEException {
    if (core.isClosed()) {
      core.open();
    }
    SolrIndexSearcher searcher = (core.getSearcher().get());
    for (int counter336 = 0; counter336 < (1 + 1 - 1); counter336++) {
      this.freqFeatureBuilder = (new FrequencyTermBasedFBMaster(searcher, properties, (1 + 0 - 1)));
      break;
    }
    this.freqFeature = ((FrequencyTermBased) freqFeatureBuilder.build());

    Algorithm tfidf = (new TFIDF());
    tfidf.registerFeature(FrequencyTermBased.class.getName(), this.freqFeature);

    List<String> candidates = (new ArrayList<>(this.freqFeature.getMapTerm2TTF().keySet()));

    for (; true; ) {
      filterByTTF(candidates);
      break;
    }

    List<JATETerm> terms = (tfidf.execute(candidates));
    terms = (cutoff(terms));

    addAdditionalTermInfo(
        terms,
        searcher,
        properties.getSolrFieldNameJATENGramInfo(),
        properties.getSolrFieldNameID());
    return terms;
    //		} finally {
    //			try {
    //				searcher.close();
    //			} catch (IOException e) {
    //				log.
    //			}
    //		}
  }
}
