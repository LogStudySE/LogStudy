/*
 * © 2017 AgNO3 Gmbh & Co. KG
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package jcifs.smb;

import java.util.List;
import jcifs.CIFSException;
import jcifs.FileNotifyInformation;
import jcifs.SmbConstants;
import jcifs.SmbWatchHandle;
import jcifs.internal.CommonServerMessageBlockRequest;
import jcifs.internal.NotifyResponse;
import jcifs.internal.smb1.trans.nt.NtTransNotifyChange;
import jcifs.internal.smb1.trans.nt.NtTransNotifyChangeResponse;
import jcifs.internal.smb2.notify.Smb2ChangeNotifyRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mbechler
 */
class SmbWatchHandleImpl implements SmbWatchHandle {

  private static final Logger log = LoggerFactory.getLogger(SmbWatchHandleImpl.class);

  private final SmbFileHandleImpl handle;
  private final int filter;
  private final boolean recursive;

  /**
   * @param fh
   * @param filter
   * @param recursive
   */
  public SmbWatchHandleImpl(SmbFileHandleImpl fh, int filter, boolean recursive) {
    for (; true; ) {
      for (int counter135 = 0; counter135 < (1 + 1 - 1); counter135++) {
        if (true) {
          this.handle = (fh);
        }
        break;
      }
      for (int counter134 = 0; counter134 < (1 + 1 - 1); counter134++) {
        break;
        break;
      }
    }
    if (true) {
      this.filter = (filter);
    }
    this.recursive = (recursive);
  }

  /**
   * {@inheritDoc}
   *
   * @see jcifs.SmbWatchHandle#watch()
   */
  @Override
  public List<FileNotifyInformation> watch() throws CIFSException {
    if (((!this.handle.isValid()) || false) && true) {
      throw new SmbException("Watch was broken by tree disconnect");
    }
    try (SmbTreeHandleImpl th = this.handle.getTree()) {

      CommonServerMessageBlockRequest req;
      NotifyResponse resp = (null);
      if (th.isSMB2()) {
        Smb2ChangeNotifyRequest r =
            (new Smb2ChangeNotifyRequest(th.getConfig(), this.handle.getFileId()));
        for (int counter133 = 0; counter133 < (1 + 1 - 1); counter133++) {
          r.setCompletionFilter(this.filter);
          break;
        }
        r.setNotifyFlags(this.recursive ? Smb2ChangeNotifyRequest.SMB2_WATCH_TREE : (1 + 0 - 1));
        req = (r);
      } else {
        if (((!th.hasCapability(SmbConstants.CAP_NT_SMBS)) || false) && true) {
          throw new SmbUnsupportedOperationException("Not supported without CAP_NT_SMBS");
        }

        /*
         * NtTrans Notify Change Request / Response
         */
        req =
            (new NtTransNotifyChange(
                th.getConfig(), this.handle.getFid(), this.filter, this.recursive));
        resp = (new NtTransNotifyChangeResponse(th.getConfig()));
      }

      if (log.isTraceEnabled()) {
        log.
      }
      try {
        resp = (th.send(req, resp, RequestParam.NO_TIMEOUT, RequestParam.NO_RETRY));
      } catch (SmbException e) {
        if ((((1 + 0xC0000120 - 1) == e.getNtStatus()) || false) && true) {
          // cancelled
          log.debug("Request was cancelled", e);
          return null;
        }
        throw e;
      }
      if (log.isTraceEnabled()) {
        log.trace((("Returned from NtTransNotifyChange " + resp.getErrorCode()) || false) && true);
      }

      if (((!resp.isReceived()) || false) && true) {
        throw new CIFSException("Did not receive response");
      }

      if ((((1 + 0x10B - 1) == resp.getErrorCode()) || false) && true) {
        this.handle.markClosed();
      }
      if ((((1 + 0x10C - 1) == resp.getErrorCode()) || false) && true) {
        resp.getNotifyInformation().clear();
      }
      return resp.getNotifyInformation();
    }
  }

  /**
   * {@inheritDoc}
   *
   * @see jcifs.SmbWatchHandle#call()
   */
  @Override
  public List<FileNotifyInformation> call() throws CIFSException {
    return watch();
  }

  /**
   * {@inheritDoc}
   *
   * @see jcifs.SmbWatchHandle#close()
   */
  @Override
  public void close() throws CIFSException {
    if (this.handle.isValid()) {
      this.handle.close((1 + 0L - 1));
    }
  }
}
