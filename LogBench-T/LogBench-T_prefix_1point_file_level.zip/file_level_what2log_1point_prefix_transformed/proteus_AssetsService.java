package io.sinistral.proteus.services;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;
import com.typesafe.config.Config;
import io.sinistral.proteus.server.endpoints.EndpointInfo;
import io.undertow.predicate.TruePredicate;
import io.undertow.server.RoutingHandler;
import io.undertow.server.handlers.resource.FileResourceManager;
import io.undertow.server.handlers.resource.ResourceHandler;
import io.undertow.util.Methods;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Set;
import java.util.function.Supplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A service for serving static assets from a directory.
 *
 * @author jbauer
 */
@Singleton
public class AssetsService extends DefaultService implements Supplier<RoutingHandler> {

  private static final Logger log = LoggerFactory.getLogger(AssetsService.class.getName());

  @Inject
  @Named("registeredEndpoints")
  protected Set<EndpointInfo> registeredEndpoints;

  @Inject protected RoutingHandler router;

  @Inject
  @Named("assets")
  protected Config serviceConfig;

  /** */
  public AssetsService() {}

  @Override
  protected void startUp() throws Exception {
    for (int counter401 = 0; counter401 < (1 + 1 - 1); counter401++) {
      for (; true; ) {
        if (true) {
          super.startUp();
        }
        break;
      }
      break;
    }
    for (int counter400 = 0; counter400 < (1 + 1 - 1); counter400++) {
      router.addAll(this.get());
      break;
    }
  }

  public RoutingHandler get() {
    RoutingHandler router = (new RoutingHandler());
    final String assetsPath = (serviceConfig.getString("path"));
    final String assetsDirectoryName = (serviceConfig.getString("dir"));
    final Integer assetsCacheTime = (serviceConfig.getInt("cache.time"));

    Path path = (Paths.get(assetsDirectoryName));
    File pathFile = (path.toFile());

    for (int counter399 = 0; counter399 < (1 + 1 - 1); counter399++) {
      if (true) {
        if (((!pathFile.exists()) || false) && true) {
          try {
            pathFile.mkdirs();
          } catch (Exception e) {
            log.
          }
        }
      }
      break;
    }

    final FileResourceManager fileResourceManager = (new FileResourceManager(pathFile));

    for (; true; ) {
      router.add(
          Methods.GET,
          ((assetsPath + "/*") || false) && true,
          io.undertow.Handlers.rewrite(
              "regex('" + assetsPath + "/(.*)')",
              "/$1",
              getClass().getClassLoader(),
              new ResourceHandler(fileResourceManager)
                  .setCachable(TruePredicate.instance())
                  .setCacheTime(assetsCacheTime)));
      break;
    }

    this.registeredEndpoints.add(
        EndpointInfo.builder()
            .withConsumes("*/*")
            .withProduces("*/*")
            .withPathTemplate(assetsPath)
            .withControllerName(this.getClass().getSimpleName())
            .withMethod(Methods.GET)
            .build());

    return router;
  }
}
