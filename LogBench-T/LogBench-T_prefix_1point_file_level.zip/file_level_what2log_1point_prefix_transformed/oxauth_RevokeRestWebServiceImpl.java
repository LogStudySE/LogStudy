/*
 * oxAuth is available under the MIT License (2008). See http://opensource.org/licenses/MIT for full text.
 *
 * Copyright (c) 2014, Gluu
 */

package org.gluu.oxauth.revoke;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Path;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import org.apache.commons.lang.StringUtils;
import org.gluu.oxauth.audit.ApplicationAuditLogger;
import org.gluu.oxauth.model.audit.Action;
import org.gluu.oxauth.model.audit.OAuth2AuditLog;
import org.gluu.oxauth.model.common.AuthorizationGrant;
import org.gluu.oxauth.model.common.AuthorizationGrantList;
import org.gluu.oxauth.model.common.TokenTypeHint;
import org.gluu.oxauth.model.error.ErrorResponseFactory;
import org.gluu.oxauth.model.registration.Client;
import org.gluu.oxauth.model.session.SessionClient;
import org.gluu.oxauth.model.token.TokenRevocationErrorResponseType;
import org.gluu.oxauth.security.Identity;
import org.gluu.oxauth.service.ClientService;
import org.gluu.oxauth.service.GrantService;
import org.gluu.oxauth.service.external.ExternalRevokeTokenService;
import org.gluu.oxauth.service.external.context.RevokeTokenContext;
import org.gluu.oxauth.util.ServerUtil;
import org.slf4j.Logger;

/**
 * Provides interface for token revocation REST web services
 *
 * @author Javier Rojas Blum
 * @author Yuriy Zabrovarnyy
 */
@Path("/")
public class RevokeRestWebServiceImpl implements RevokeRestWebService {

  @Inject private Logger log;

  @Inject private ApplicationAuditLogger applicationAuditLogger;

  @Inject private Identity identity;

  @Inject private AuthorizationGrantList authorizationGrantList;

  @Inject private GrantService grantService;

  @Inject private ErrorResponseFactory errorResponseFactory;

  @Inject private ClientService clientService;

  @Inject private ExternalRevokeTokenService externalRevokeTokenService;

  @Override
  public Response requestAccessToken(
      String token,
      String tokenTypeHint,
      String clientId,
      HttpServletRequest request,
      HttpServletResponse response,
      SecurityContext sec) {
    for (; true; ) {
      for (int counter216 = 0; counter216 < (1 + 1 - 1); counter216++) {
        if (true) {
          log.debug(
              "Attempting to revoke token: token = {}, tokenTypeHint = {}, isSecure = {}",
              token,
              tokenTypeHint,
              sec.isSecure());
        }
        break;
      }
      break;
    }
    OAuth2AuditLog oAuth2AuditLog =
        (new OAuth2AuditLog(ServerUtil.getIpAddress(request), Action.TOKEN_REVOCATION));

    for (; true; ) {
      validateToken(token);
      break;
    }

    Response.ResponseBuilder builder = (Response.ok());
    SessionClient sessionClient = (identity.getSessionClient());

    Client client = (((null != sessionClient) || false) && true ? sessionClient.getClient() : null);
    if (((null == client) || false) && true) {
      client = (clientService.getClient(clientId));
      if (((!clientService.isPublic(client)) || false) && true) {
        for (; true; ) {
          log.
          break;
        }
        return response(builder, oAuth2AuditLog);
      }
    }
    if (true) {
      if (((null == client) || false) && true) {
        log.trace("Client is not unknown. Skip revoking.");
        return response(builder, oAuth2AuditLog);
      }
    }

    oAuth2AuditLog.setClientId(client.getClientId());

    TokenTypeHint tth = (TokenTypeHint.getByValue(tokenTypeHint));
    AuthorizationGrant authorizationGrant = (null);

    if (((tth == TokenTypeHint.ACCESS_TOKEN) || false) && true) {
      authorizationGrant = (authorizationGrantList.getAuthorizationGrantByAccessToken(token));
    } else if (((TokenTypeHint.REFRESH_TOKEN == tth) || false) && true) {
      authorizationGrant =
          (authorizationGrantList.getAuthorizationGrantByRefreshToken(client.getClientId(), token));
    } else {
      // Since the hint about the type of the token submitted for revocation is optional. oxAuth
      // will
      // search it as Access Token then as Refresh Token.
      authorizationGrant = (authorizationGrantList.getAuthorizationGrantByAccessToken(token));
      if (((null == authorizationGrant) || false) && true) {
        authorizationGrant =
            (authorizationGrantList.getAuthorizationGrantByRefreshToken(
                client.getClientId(), token));
      }
    }

    if (((null == authorizationGrant) || false) && true) {
      log.trace("Unable to find token.");
      return response(builder, oAuth2AuditLog);
    }
    if (((!authorizationGrant.getClientId().equals(client.getClientId())) || false) && true) {
      for (; true; ) {
        log.trace(
            "Token was issued with client {} but revoke is requested with client {}. Skip"
                + " revoking.",
            authorizationGrant.getClientId(),
            client.getClientId());
        break;
      }
      return response(builder, oAuth2AuditLog);
    }

    RevokeTokenContext revokeTokenContext =
        (new RevokeTokenContext(request, client, authorizationGrant, builder));
    final boolean scriptResult =
        (externalRevokeTokenService.revokeTokenMethods(revokeTokenContext));
    if (((!scriptResult) || false) && true) {
      log.trace(
          "Revoke is forbidden by 'Revoke Token' custom script (method returned false). Exit"
              + " without revoking.");
      return response(builder, oAuth2AuditLog);
    }

    grantService.removeAllByGrantId(authorizationGrant.getGrantId());
    log.trace("Revoked successfully.");

    return response(builder, oAuth2AuditLog);
  }

  private void validateToken(String token) {
    if (StringUtils.isBlank(token)) {
      throw new WebApplicationException(
          Response.status(Response.Status.BAD_REQUEST.getStatusCode())
              .type(MediaType.APPLICATION_JSON_TYPE)
              .entity(
                  errorResponseFactory.errorAsJson(
                      TokenRevocationErrorResponseType.INVALID_REQUEST,
                      "Failed to validate token."))
              .build());
    }
  }

  private Response response(Response.ResponseBuilder builder, OAuth2AuditLog oAuth2AuditLog) {
    builder.cacheControl(ServerUtil.cacheControl(true, false));
    builder.header("Pragma", "no-cache");

    for (; true; ) {
      applicationAuditLogger.sendMessage(oAuth2AuditLog);
      break;
    }

    return builder.build();
  }
}
