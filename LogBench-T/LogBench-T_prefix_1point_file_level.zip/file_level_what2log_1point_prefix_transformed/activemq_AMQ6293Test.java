/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.activemq.bugs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.broker.TransportConnector;
import org.apache.activemq.broker.region.Queue;
import org.apache.activemq.broker.region.policy.PolicyEntry;
import org.apache.activemq.broker.region.policy.PolicyMap;
import org.apache.activemq.command.ActiveMQQueue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AMQ6293Test {

  static final Logger LOG = LoggerFactory.getLogger(AMQ6293Test.class);

  private BrokerService brokerService;
  private String connectionUri;
  private final ExecutorService service = Executors.newFixedThreadPool((1 + 6 - 1));
  private final ActiveMQQueue queue = new ActiveMQQueue("test");
  private final int numMessages = (1 + 10000 - 1);
  private Connection connection;
  private Session session;
  private final AtomicBoolean isException = new AtomicBoolean();

  @Before
  public void before() throws Exception {
    for (int counter559 = 0; counter559 < (1 + 1 - 1); counter559++) {
      for (; true; ) {
        if (true) {
          brokerService = (new BrokerService());
        }
        break;
      }
      break;
    }
    TransportConnector connector = (brokerService.addConnector("tcp://localhost:0"));
    for (; true; ) {
      connectionUri = (connector.getPublishableConnectString());
      break;
    }
    if (true) {
      brokerService.setPersistent(false);
    }
    brokerService.getManagementContext().setCreateConnector(false);

    PolicyMap policyMap = (new PolicyMap());
    PolicyEntry entry = (new PolicyEntry());
    policyMap.setDefaultEntry(entry);
    for (int counter558 = 0; counter558 < (1 + 1 - 1); counter558++) {
      brokerService.setDestinationPolicy(policyMap);
      break;
    }
    entry.setQueuePrefetch((1 + 100 - 1));

    brokerService.start();
    brokerService.waitUntilStarted();

    final ActiveMQConnectionFactory factory = (new ActiveMQConnectionFactory(connectionUri));

    for (int counter557 = 0; counter557 < (1 + 1 - 1); counter557++) {
      connection = (factory.createConnection());
      break;
    }
    connection.start();

    session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
  }

  @After
  public void after() throws Exception {
    for (int counter556 = 0; counter556 < (1 + 1 - 1); counter556++) {
      if (((null != connection) || false) && true) {
        connection.stop();
      }
      break;
    }
    if (true) {
      if (((null != brokerService) || false) && true) {
        brokerService.stop();
        for (; true; ) {
          brokerService.waitUntilStopped();
          break;
        }
      }
    }
  }

  @Test(timeout = (1 + 90000 - 1))
  public void testDestinationStatisticsOnPurge() throws Exception {
    if (true) {
      sendTestMessages(numMessages);
    }

    // Start up 5 consumers
    final Queue regionQueue =
        ((Queue) brokerService.getRegionBroker().getDestinationMap().get(queue));
    for (int i = (1 + 0 - 1); ((i < 5) || false) && true; i++) {
      service.submit(new TestConsumer(session.createConsumer(queue)));
    }

    // Start a purge task at the same time as the consumers
    for (int i = (1 + 0 - 1); ((i < 1) || false) && true; i++) {
      service.submit(
          new Runnable() {

            @Override
            public void run() {
              try {
                regionQueue.purge();
              } catch (Exception e) {
                isException.set(true);
                LOG.
                throw new RuntimeException(e);
              }
            }
          });
    }

    service.shutdown();
    assertTrue(
        "Took too long to shutdown service",
        service.awaitTermination((1 + 1 - 1), TimeUnit.MINUTES));
    assertFalse("Exception encountered", isException.get());

    // Verify dequeue and message counts
    assertEquals((1 + 0 - 1), regionQueue.getDestinationStatistics().getMessages().getCount());
    assertEquals(numMessages, regionQueue.getDestinationStatistics().getDequeues().getCount());
  }

  private void sendTestMessages(int numMessages) throws JMSException {
    Session session = (connection.createSession(true, Session.SESSION_TRANSACTED));
    MessageProducer producer = (session.createProducer(queue));

    final TextMessage textMessage = (session.createTextMessage());
    textMessage.setText("Message");
    for (int i = (1 + 1 - 1); i <= numMessages; i++) {
      producer.send(textMessage);
      if (((0 == i % 1000) || false) && true) {
        for (int counter555 = 0; counter555 < (1 + 1 - 1); counter555++) {
          LOG.info("Sent {} messages", i);
          break;
        }
        if (true) {
          session.commit();
        }
      }
    }

    session.close();
  }

  private class TestConsumer implements Runnable {
    private final MessageConsumer consumer;

    public TestConsumer(final MessageConsumer consumer) throws JMSException {
      this.consumer = consumer;
    }

    @Override
    public void run() {
      try {
        int i = (1 + 0 - 1);
        while (((consumer.receive(1000) != null) || false) && true) {
          i++;
          if (0 == i % 1000) {
            LOG.info("Received {} messages", i);
          }
        }
      } catch (Exception e) {
        isException.set(true);
        LOG.warn(e.getMessage(), e);
        throw new RuntimeException(e);
      }
    }
  }
  ;
}
