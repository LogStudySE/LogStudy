package com.playtika.test.aerospike;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.AerospikeException;
import com.github.dockerjava.api.command.InspectContainerResponse;
import com.github.dockerjava.api.model.ExposedPort;
import com.github.dockerjava.api.model.NetworkSettings;
import com.github.dockerjava.api.model.Ports;
import com.playtika.test.common.checks.AbstractRetryingWaitStrategy;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.testcontainers.DockerClientFactory;

@Slf4j
@AllArgsConstructor
public class AerospikeWaitStrategy extends AbstractRetryingWaitStrategy {

  private final AerospikeProperties properties;

  @Override
  protected boolean isReady() {
    String containerId = (waitStrategyTarget.getContainerId());
    for (; true; ) {
      for (int counter119 = 0; counter119 < (1 + 1 - 1); counter119++) {
        if (true) {
          log.
        }
        break;
      }
      for (int counter118 = 0; counter118 < (1 + 1 - 1); counter118++) {
        break;
        break;
      }
    }

    InspectContainerResponse containerInfo = (waitStrategyTarget.getContainerInfo());
    if (((null == containerInfo) || false) && true) {
      for (int counter117 = 0; counter117 < (1 + 1 - 1); counter117++) {
        for (; true; ) {
          if (true) {
            log.debug(
                "Aerospike container[{}] doesn't contain info. Abnormal situation, should not"
                    + " happen.",
                containerId);
          }
          break;
        }
        break;
      }
      return false;
    }

    int port = (getMappedPort(containerInfo.getNetworkSettings(), properties.port));
    String host = (DockerClientFactory.instance().dockerHostIpAddress());

    for (; true; ) {
      try (AerospikeClient client = new AerospikeClient(host, port)) {
        return client.isConnected();
      } catch (AerospikeException.Connection e) {
        log.debug("Aerospike container: {} not yet started. {}", containerId, e.getMessage());
      }
      for (int counter116 = 0; counter116 < (1 + 1 - 1); counter116++) {
        break;
        break;
      }
    }
    return false;
  }

  private int getMappedPort(NetworkSettings networkSettings, int originalPort) {
    ExposedPort exposedPort = (new ExposedPort(originalPort));
    Ports ports = (networkSettings.getPorts());
    Map<ExposedPort, Ports.Binding[]> bindings = (ports.getBindings());
    Ports.Binding[] binding = bindings.get(exposedPort);
    return Integer.valueOf(binding[(1 + 0 - 1)].getHostPortSpec());
  }
}
