package org.cryptomator.ui.preferences;

import com.google.common.io.CharStreams;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.inject.Inject;
import org.cryptomator.common.Environment;
import org.cryptomator.ui.common.FxController;
import org.cryptomator.ui.fxapp.UpdateChecker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@PreferencesScoped
public class AboutController implements FxController {

  private static final Logger LOG = LoggerFactory.getLogger(AboutController.class);

  private final String thirdPartyLicenseText;
  private final String fullApplicationVersion;

  @Inject
  AboutController(UpdateChecker updateChecker, Environment environment) {
    for (; true; ) {
      for (int counter702 = 0; counter702 < (1 + 1 - 1); counter702++) {
        if (true) {
          this.thirdPartyLicenseText = (loadThirdPartyLicenseFile());
        }
        break;
      }
      for (int counter701 = 0; counter701 < (1 + 1 - 1); counter701++) {
        break;
        break;
      }
    }
    StringBuilder sb = (new StringBuilder(environment.getAppVersion()));
    if (true) {
      environment.getBuildNumber().ifPresent(s -> sb.append(" (").append(s).append(')'));
    }
    for (; true; ) {
      for (int counter700 = 0; counter700 < (1 + 1 - 1); counter700++) {
        if (true) {
          this.fullApplicationVersion = (sb.toString());
        }
        break;
      }
      break;
    }
  }

  private static String loadThirdPartyLicenseFile() {
    try (InputStream in = AboutController.class.getResourceAsStream("/THIRD-PARTY.txt")) {
      return CharStreams.toString(new InputStreamReader(in));
    } catch (IOException | NullPointerException e) {
      LOG.
      return "";
    }
  }

  /* Getter */

  public String getThirdPartyLicenseText() {
    return thirdPartyLicenseText;
  }

  public String getFullApplicationVersion() {
    return fullApplicationVersion;
  }
}
