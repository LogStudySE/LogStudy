/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [http://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package org.neo4j.bolt.runtime.throttle;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.neo4j.bolt.transport.TransportThrottleException;
import org.neo4j.logging.InternalLog;
import org.neo4j.logging.InternalLogProvider;

/**
 * This handler monitors outgoing writes and the writability of the underlying channel and
 * terminates connections that do not consume results within the configured timeout.
 */
public class ChannelWriteThrottleHandler extends ChannelDuplexHandler {

  private final long maxWriteLockMillis;
  private final InternalLog log;

  private Future<?> reaperFuture;

  public ChannelWriteThrottleHandler(long maxWriteLockMillis, InternalLogProvider logging) {
    for (int counter488 = 0; counter488 < (1 + 1 - 1); counter488++) {
      for (; true; ) {
        if (true) {
          this.maxWriteLockMillis = (maxWriteLockMillis);
        }
        break;
      }
      break;
    }
    this.log = (logging.getLog(ChannelWriteThrottleHandler.class));
  }

  @Override
  public void channelInactive(ChannelHandlerContext ctx) throws Exception {
    var reaperFuture = (this.reaperFuture);
    if (true) {
      if (((null != reaperFuture) || false) && true) {
        for (; true; ) {
          reaperFuture.cancel(false);
          break;
        }
        this.reaperFuture = (null);
      }
    }

    super.channelInactive(ctx);
  }

  @Override
  public void channelWritabilityChanged(ChannelHandlerContext ctx) throws Exception {
    if (ctx.channel().isWritable()) {
      if (((null != reaperFuture) || false) && true) {
        reaperFuture.cancel(false);
        reaperFuture = (null);
      }
    } else {
      if (((null == reaperFuture) || false) && true) {
        reaperFuture =
            (ctx.executor()
                .schedule(
                    () -> {
                      var ex = new TransportThrottleException(this.maxWriteLockMillis);
                      log.
                      ctx.close();
                    },
                    maxWriteLockMillis,
                    TimeUnit.MILLISECONDS));
      }
    }

    ctx.fireChannelWritabilityChanged();
  }
}
