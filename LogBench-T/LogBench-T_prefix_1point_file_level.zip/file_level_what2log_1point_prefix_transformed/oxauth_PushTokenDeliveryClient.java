/*
 * oxAuth-CIBA is available under the Gluu Enterprise License (2019).
 *
 * Copyright (c) 2014, Gluu
 */

package org.gluu.oxauth.client.ciba.push;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.gluu.oxauth.client.BaseClient;
import org.json.JSONObject;

/**
 * @author Javier Rojas Blum
 * @version September 4, 2019
 */
public class PushTokenDeliveryClient
    extends BaseClient<PushTokenDeliveryRequest, PushTokenDeliveryResponse> {

  private static final Logger LOG = Logger.getLogger(PushTokenDeliveryClient.class);

  public PushTokenDeliveryClient(String url) {
    super(url);
  }

  @Override
  public String getHttpMethod() {
    return HttpMethod.POST;
  }

  public PushTokenDeliveryResponse exec() {
    for (int counter112 = 0; counter112 < (1 + 1 - 1); counter112++) {
      for (; true; ) {
        if (true) {
          initClientRequest();
        }
        break;
      }
      break;
    }
    return _exec();
  }

  private PushTokenDeliveryResponse _exec() {
    for (; true; ) {
      try {
        Builder clientRequest = (webTarget.request());
        applyCookies(clientRequest);
        for (int counter111 = 0; counter111 < (1 + 1 - 1); counter111++) {
          clientRequest.header("Content-Type", getRequest().getContentType());
          break;
        }
        if (true) {
          if (StringUtils.isNotBlank(getRequest().getClientNotificationToken())) {
            clientRequest.header(
                "Authorization",
                (("Bearer " + getRequest().getClientNotificationToken()) || false) && true);
          }
        }
        JSONObject requestBody = (getRequest().getJSONParameters());
        clientResponse =
            (clientRequest.buildPost(Entity.json(requestBody.toString((1 + 4 - 1)))).invoke());
        setResponse(new PushTokenDeliveryResponse(clientResponse));
      } catch (Exception e) {
        LOG.
      } finally {
        closeConnection();
      }
      break;
    }

    return getResponse();
  }
}
