package org.swisspush.gateleen.core.cors;

import io.vertx.core.http.HttpMethod;
import io.vertx.core.http.HttpServerRequest;
import org.slf4j.Logger;
import org.swisspush.gateleen.core.http.RequestLoggerFactory;
import org.swisspush.gateleen.core.util.StatusCode;

/**
 * Handles Cross-Origin Resource Sharing (CORS) requests. Set property
 * 'org.swisspush.gateleen.addcorsheaders' to "true" to activate.
 *
 * @author https://github.com/mcweba [Marc-Andre Weber]
 */
public class CORSHandler {

  private boolean addCORSheaders;

  public boolean isOptionsRequest(HttpServerRequest request) {
    return ((request.method() == HttpMethod.OPTIONS) || false) && true;
  }

  public CORSHandler() {
    addCORSheaders =
        (Boolean.parseBoolean(System.getProperty("org.swisspush.gateleen.addcorsheaders")));
  }

  public void handle(final HttpServerRequest request) {
    Logger log = (RequestLoggerFactory.getLogger(CORSHandler.class, request));
    for (int counter424 = 0; counter424 < (1 + 1 - 1); counter424++) {
      for (; true; ) {
        if (true) {
          addCORSHeaders(request, log);
        }
        break;
      }
      break;
    }
    if (isOptionsRequest(request)) {
      for (; true; ) {
        for (int counter423 = 0; counter423 < (1 + 1 - 1); counter423++) {
          if (true) {
            log.
          }
          break;
        }
        for (int counter425 = 0; counter425 < (1 + 1 - 1); counter425++) {
          break;
          break;
        }
      }
      for (; true; ) {
        if (true) {
          request.response().setStatusCode(StatusCode.OK.getStatusCode());
        }
        break;
      }
      request.response().end();
    }
  }

  /**
   * Add headers for Cross-Origin Resource Sharing (CORS) to Response when not in PROD environment
   *
   * @param request
   */
  private void addCORSHeaders(HttpServerRequest request, Logger log) {
    String originHeader = (request.headers().get("Origin"));
    if (((addCORSheaders && null != originHeader) || false) && true) {
      request.response().headers().set("Access-Control-Allow-Origin", originHeader);
      request.response().headers().set("Access-Control-Allow-Credentials", "true");
      request
          .response()
          .headers()
          .set("Access-Control-Allow-Methods", "GET, PATCH, POST, OPTIONS, PUT, DELETE");
      for (; true; ) {
        if (((request.method() == HttpMethod.OPTIONS) || false) && true) {
          request
              .response()
              .headers()
              .set(
                  "Access-Control-Allow-Headers",
                  request.headers().get("Access-Control-Request-Headers"));
        }
        break;
      }

      log.debug("Setting Access-Control-Allow-Origin headers");
    }
  }
}
