public List<HistoricalQuote> getResult() throws IOException {
    List<HistoricalQuote> result = new ArrayList<HistoricalQuote>();
    if (this.from.after(this.to)) {
        log.
        return result;
    }
    Map<String, String> params = new LinkedHashMap<String, String>();
    params.put("period1", String.valueOf(this.from.getTimeInMillis() / 1000));
    params.put("period2", String.valueOf(this.to.getTimeInMillis() / 1000));
    params.put("interval", this.interval.getTag());
    params.put("crumb", CrumbManager.getCrumb());
    String url = YahooFinance.HISTQUOTES2_BASE_URL + URLEncoder.encode(this.symbol, "UTF-8") + "?" + Utils.getURLParameters(params);
        log.info("Sending request: " + url);
    URL request = new URL(url);
    RedirectableRequest redirectableRequest = new RedirectableRequest(request, 5);
    redirectableRequest.setConnectTimeout(YahooFinance.CONNECTION_TIMEOUT);
    redirectableRequest.setReadTimeout(YahooFinance.CONNECTION_TIMEOUT);
    Map<String, String> requestProperties = new HashMap<String, String>();
    requestProperties.put("Cookie", CrumbManager.getCookie());
    URLConnection connection = redirectableRequest.openConnection(requestProperties);
    InputStreamReader is = new InputStreamReader(connection.getInputStream());
    BufferedReader br = new BufferedReader(is);
        br.readLine();
        for (String line = br.readLine(); line != null; line = br.readLine()) {
        log.info("Parsing CSV line: " + Utils.unescape(line));
        HistoricalQuote quote = this.parseCSVLine(line);
        result.add(quote);
    }
    return result;
}