public void tryUpdateAtomically(Consumer<TelemetryLocalStorage> updater) {
    try {
        updateAtomically(updater);
    } catch (Exception e) {
        if (InternalDebug.isEnabled()) {
            LOG.
            throw new IllegalStateException(e);
        }
    }
}