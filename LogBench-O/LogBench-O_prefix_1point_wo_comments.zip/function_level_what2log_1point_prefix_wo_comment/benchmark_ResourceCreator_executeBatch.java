@SneakyThrows
private Map<R, CreationResult<C>> executeBatch(List<R> batch) {
    log.
    Thread.sleep(interBatchDelayMs);
    return invokeBatchFn.apply(batch).entrySet().stream().collect(toMap(Map.Entry::getKey, e -> complete.apply(e.getValue())));
}