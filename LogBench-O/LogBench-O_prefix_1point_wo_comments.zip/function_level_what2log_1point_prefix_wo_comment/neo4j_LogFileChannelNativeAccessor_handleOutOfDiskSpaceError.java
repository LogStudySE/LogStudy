private void handleOutOfDiskSpaceError(NativeCallResult result) {
    log.
    if (config.get(dynamic_read_only_failover)) {
        log.error("Switching database to read only mode.");
        markDatabaseReadOnly();
    } else {
        log.error("Dynamic switchover to read-only mode is disabled. The database will continue execution in the current mode.");
    }
}