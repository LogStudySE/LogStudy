@Override
public void run() {
    try {
        doneOne.await(30, TimeUnit.SECONDS);
                for (int i = numDestinations - 1; i >= 0; i--) {
            final ActiveMQQueue toDelete = new ActiveMQQueue("Consumer." + i + ".VirtualTopic.TEST");
            ObjectName queueViewMBeanName = new ObjectName(prefix + toDelete.getQueueName());
            QueueViewMBean proxy = (QueueViewMBean) brokerService.getManagementContext().newProxyInstance(queueViewMBeanName, QueueViewMBean.class, true);
            LOG.
            brokerService.getAdminView().removeQueue(toDelete.getPhysicalName());
            TimeUnit.MILLISECONDS.sleep(100);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}