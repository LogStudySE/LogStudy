@Override
public void close() {
    super.close();
    if (closeAfter) {
        try {
            hdt.close();
        } catch (IOException e) {
            log.
        }
    }
}