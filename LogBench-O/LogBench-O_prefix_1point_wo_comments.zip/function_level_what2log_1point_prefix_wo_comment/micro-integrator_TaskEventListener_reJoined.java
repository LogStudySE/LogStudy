@Override
public void reJoined(String nodeId) {
    LOG.
    try {
                                taskStore.unAssignAndUpdateState(nodeId);
    } catch (Throwable e) {
                LOG.error("Error occurred while cleaning the tasks of node " + nodeId, e);
    }
        CoordinatedTaskScheduleManager scheduleManager = new CoordinatedTaskScheduleManager(taskManager, taskStore, clusterCoordinator, locationResolver);
    scheduleManager.startTaskScheduler(" upon rejoining the cluster");
}