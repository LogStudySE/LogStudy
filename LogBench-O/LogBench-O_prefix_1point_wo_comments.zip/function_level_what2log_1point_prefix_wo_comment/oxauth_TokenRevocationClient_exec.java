
public TokenRevocationResponse exec() {
        initClientRequest();
    if (StringUtils.isNotBlank(getRequest().getToken())) {
        requestForm.param(TokenRevocationRequestParam.TOKEN, getRequest().getToken());
    }
    if (getRequest().getTokenTypeHint() != null) {
        requestForm.param(TokenRevocationRequestParam.TOKEN_TYPE_HINT, getRequest().getTokenTypeHint().toString());
    }
    if (request.getAuthUsername() != null && !request.getAuthUsername().isEmpty()) {
        requestForm.param("client_id", request.getAuthUsername());
    }
    Builder clientRequest = webTarget.request();
    applyCookies(clientRequest);
    new ClientAuthnEnabler(clientRequest, requestForm).exec(request);
    clientRequest.header("Content-Type", request.getContentType());
            try {
        clientResponse = clientRequest.buildPost(Entity.form(requestForm)).invoke();
        final TokenRevocationResponse tokenResponse = new TokenRevocationResponse(clientResponse);
        setResponse(tokenResponse);
    } catch (Exception e) {
        LOG.
    } finally {
        closeConnection();
    }
    return getResponse();
}