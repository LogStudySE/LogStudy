@Test(groups = "wso2.esb", description = "Testcase to check preservation of SOAP headers during MSMP scenario")
public void testPreservationOfSoapHeadersMSMPScennario() throws IOException, InterruptedException {
    String payload = "<soapenv:Envelope xmlns:soapenv=\"http:    String expectedSOAPHeaderSnippetAtMP = "<wsa:To xmlns:wsa=\"http:    boolean expectedHeaderFound = false;
    Map<String, String> headers = new HashMap<String, String>();
        headers.put("Content-Type", "application/xml");
    headers.put("Authorization", "Basic YWRtaW46YWRtaW4=");
    headers.put("Content-Type", "text/xml;charset=UTF-8");
    headers.put("SOAPAction", "urn:mediate");
        SimpleHttpClient httpClient = new SimpleHttpClient();
    httpClient.doPost(getProxyServiceURLHttps("messageProcessorSoapHeaderTestProxy"), headers, payload, "application/xml");
    String response = wireServer.getCapturedMessage();
    log.
    if (response.contains(expectedSOAPHeaderSnippetAtMP)) {
        expectedHeaderFound = true;
    }
    Assert.assertTrue(expectedHeaderFound, "Expected SOAP Header not available at Message Processor sequence");
}