@Override
public void filterWrite(NextFilter nextFilter, IoSession session, WriteRequest writeRequest) throws Exception {
    if (!session.isClosing()) {
                long pendingBytes = session.getScheduledWriteBytes();
        if (pendingBytes > bytesCap) {
                        long writeTime = session.getLastWriteTime();
            int pendingRequests = session.getScheduledWriteMessages();
            Log.
                        session.close(false);
            throw new IOException("Closing session that seems to be stalled. Preventing OOM");
        }
    }
        super.filterWrite(nextFilter, session, writeRequest);
}