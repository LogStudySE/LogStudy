
@SuppressWarnings("deprecation")
@Override
public void start() throws ServletException {
    log.
    rtmpsEngine = new StandardEngine();
    rtmpsEngine.setName("red5RTMPSEngine");
    rtmpsEngine.setDefaultHost(host.getName());
    rtmpsEngine.setRealm(embedded.getEngine().getRealm());
    Service service = new StandardService();
    service.setName("red5RTMPSEngine");
    service.setContainer(rtmpsEngine);
        for (Valve valve : valves) {
        log.debug("Adding host valve: {}", valve);
        ((StandardHost) host).addValve(valve);
    }
        File appDirBase = new File(webappFolder);
    String webappContextDir = FileUtil.formatPath(appDirBase.getAbsolutePath(), "/root");
    Context ctx = embedded.addWebapp("/", webappContextDir);
        ctx.setReloadable(false);
    log.debug("Context name: {}", ctx.getName());
    Object ldr = ctx.getLoader();
    log.trace("Context loader (null if the context has not been started): {}", ldr);
    if (ldr == null) {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
                ctx.setParentClassLoader(classLoader);
        WebappLoader wldr = new WebappLoader(classLoader);
                ctx.setLoader(wldr);
    }
    appDirBase = null;
    webappContextDir = null;
    host.addChild(ctx);
        StandardWrapper wrapper = new StandardWrapper();
    wrapper.setServletName("RTMPTServlet");
    wrapper.setServletClass("org.red5.server.net.rtmpt.RTMPTServlet");
    ctx.addChild(wrapper);
        ctx.addServletMapping("/open/*", "RTMPTServlet");
    ctx.addServletMapping("/close/*", "RTMPTServlet");
    ctx.addServletMapping("/send/*", "RTMPTServlet");
    ctx.addServletMapping("/idle/*", "RTMPTServlet");
        rtmpsEngine.addChild(host);
        embedded.getServer().addService(service);
    try {
                for (TomcatConnector tomcatConnector : connectors) {
                        Connector connector = tomcatConnector.getConnector();
                        service.addConnector(connector);
            log.trace("Connector oName: {}", connector.getObjectName());
            log.info("Starting RTMPS engine");
                        connector.start();
        }
    } catch (Exception e) {
        log.error("Error initializing RTMPS server instance", e);
    } finally {
        registerJMX();
    }
}