@Bean
@ConditionalOnMissingBean(Network.class)
Network toxiproxyNetwork() {
    Network network = Network.newNetwork();
    log.
    return network;
}