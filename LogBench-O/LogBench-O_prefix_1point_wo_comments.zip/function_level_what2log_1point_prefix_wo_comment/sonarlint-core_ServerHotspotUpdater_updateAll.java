public void updateAll(HotspotApi hotspotApi, String projectKey, String branchName, Supplier<Version> serverVersionSupplier, ProgressMonitor progress) {
    if (hotspotApi.permitsTracking(serverVersionSupplier)) {
        var projectHotspots = hotspotApi.getAll(projectKey, branchName, progress);
        serverIssueStoresManager.get(projectKey).replaceAllHotspotsOfBranch(branchName, projectHotspots);
    } else {
        LOG.
    }
}