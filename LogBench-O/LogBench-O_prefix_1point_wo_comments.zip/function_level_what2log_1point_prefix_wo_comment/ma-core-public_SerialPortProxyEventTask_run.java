
public void run() {
    try {
        if (LOG.isDebugEnabled())
            LOG.
        this.event.setTimeExecuted(Common.timer.currentTimeMillis());
        listener.serialEvent(this.event);
    } catch (Exception e) {
        LOG.error("An error occurred", e);
    }
}