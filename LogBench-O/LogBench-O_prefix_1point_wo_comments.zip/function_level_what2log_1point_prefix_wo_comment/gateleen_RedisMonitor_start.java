public void start() {
    timer = vertx.setPeriodic(period, timer -> {
        redisAPI.info(new ArrayList<>()).onComplete(event -> {
            if (event.succeeded()) {
                collectMetrics(event.result().toBuffer());
            } else {
                log.
            }
        });
        if (metricName != null && elementCountKey != null) {
            redisAPI.zcard(elementCountKey, reply -> {
                if (reply.succeeded()) {
                    long value = reply.result().toLong();
                    publisher.publishMetric(metricName, value);
                } else {
                    log.warn("Cannot collect zcard from redis for key {}", elementCountKey);
                }
            });
        }
    });
}