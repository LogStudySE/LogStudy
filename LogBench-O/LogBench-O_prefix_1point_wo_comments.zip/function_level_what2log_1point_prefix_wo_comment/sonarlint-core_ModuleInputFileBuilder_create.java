public SonarLintInputFile create(ClientInputFile inputFile) {
    var defaultInputFile = new SonarLintInputFile(inputFile, f -> {
        LOG.
        var charset = f.charset();
        InputStream stream;
        try {
            stream = f.inputStream();
        } catch (IOException e) {
            throw new IllegalStateException("Failed to open a stream on file: " + f.uri(), e);
        }
        return fileMetadata.readMetadata(stream, charset != null ? charset : Charset.defaultCharset(), f.uri(), null);
    });
    defaultInputFile.setType(inputFile.isTest() ? Type.TEST : Type.MAIN);
    var fileLanguage = inputFile.language();
    if (fileLanguage != null) {
        LOG.debug("Language of file '{}' is set to '{}'", inputFile.uri(), fileLanguage);
        defaultInputFile.setLanguage(fileLanguage);
    } else {
        defaultInputFile.setLanguage(langDetection.language(defaultInputFile));
    }
    return defaultInputFile;
}