public boolean isTokenExpired(String homeRealm, RequestContext context) throws Exception {
    SecurityToken idpToken = (SecurityToken) WebUtils.getAttributeFromExternalContext(context, homeRealm);
    if (idpToken == null) {
        return true;
    }
    if (tokenExpirationValidation && idpToken.isExpired()) {
        LOG.
        return true;
    }
    return false;
}