public void add(String userInum, String clientId, Set<String> scopes) {
    log.
    Client client = clientService.getClient(clientId);
                    prepareBranch();
    ClientAuthorization clientAuthorization = find(userInum, clientId);
    if (clientAuthorization == null) {
        final String id = createId(userInum, clientId);
        clientAuthorization = new ClientAuthorization();
        clientAuthorization.setId(id);
        clientAuthorization.setDn(createDn(id));
        clientAuthorization.setClientId(clientId);
        clientAuthorization.setUserId(userInum);
        clientAuthorization.setScopes(scopes.toArray(new String[scopes.size()]));
        clientAuthorization.setDeletable(!client.getAttributes().getKeepClientAuthorizationAfterExpiration());
        clientAuthorization.setExpirationDate(client.getExpirationDate());
        clientAuthorization.setTtl(appConfiguration.getDynamicRegistrationExpirationTime());
        ldapEntryManager.persist(clientAuthorization);
    } else if (ArrayUtils.isNotEmpty(clientAuthorization.getScopes())) {
        Set<String> set = new HashSet<>(scopes);
        set.addAll(Arrays.asList(clientAuthorization.getScopes()));
        if (set.size() != clientAuthorization.getScopes().length) {
            clientAuthorization.setScopes(set.toArray(new String[set.size()]));
            ldapEntryManager.merge(clientAuthorization);
        }
    }
}