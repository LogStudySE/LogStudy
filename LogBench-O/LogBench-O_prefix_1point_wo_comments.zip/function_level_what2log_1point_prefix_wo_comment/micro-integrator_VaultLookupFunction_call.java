
@Override
public Object call(Context context, List args) throws FunctionCallException {
    boolean traceOn = synCtx.getTracingState() == SynapseConstants.TRACING_ON;
    boolean traceOrDebugOn = traceOn || log.
    if (args == null || args.size() == 0) {
        if (traceOrDebugOn) {
            traceOrDebug(traceOn, "vault value for lookup is not specified");
        }
        return NULL_STRING;
    }
    String argOne = StringFunction.evaluate(args.get(0), context.getNavigator());
    SecureVaultLookupHandler mediationSecurity;
    try {
        mediationSecurity = SecureVaultLookupHandlerImpl.getDefaultSecurityService();
        return mediationSecurity.evaluate(argOne, getSecretSourceInfo(args), synCtx);
    } catch (Exception msg) {
        throw new FunctionCallException(msg);
    }
}