
void clearConstraints() {
    log.
    this.constraints.clear();
}