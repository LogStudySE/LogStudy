@FXML
public void unlock() {
    LOG.
    unlockInProgress.set(true);
    CharSequence pwFieldContents = passwordField.getCharacters();
    Passphrase pw = Passphrase.copyOf(pwFieldContents);
    result.complete(new PassphraseEntryResult(pw, savePasswordCheckbox.isSelected()));
    startUnlockAnimation();
}