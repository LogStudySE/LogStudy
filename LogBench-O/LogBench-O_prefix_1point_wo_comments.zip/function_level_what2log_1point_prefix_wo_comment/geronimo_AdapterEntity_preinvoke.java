public Servant preinvoke(byte[] oid, POA poa, String operation, CookieHolder cookie) {
        Object pk = null;
    try {
        ObjectInputStream is = new ObjectInputStream(new ByteArrayInputStream(oid));
        pk = is.readObject();
        is.close();
        EjbDeployment deployment = getDeployment();
        return new StandardServant(getOrb(), InterfaceType.EJB_OBJECT, deployment, pk);
    } catch (IOException e) {
                throw (OBJECT_NOT_EXIST) new OBJECT_NOT_EXIST(0, org.omg.CORBA.CompletionStatus.COMPLETED_NO).initCause(e);
    } catch (Exception e) {
        log.
        return null;
    }
}