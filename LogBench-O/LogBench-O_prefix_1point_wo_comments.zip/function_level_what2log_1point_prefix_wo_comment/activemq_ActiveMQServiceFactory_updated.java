@Override
synchronized public void updated(String pid, Dictionary<String, ?> properties) throws ConfigurationException {
        deleted(pid);
    String config = (String) properties.get("config");
    if (config == null) {
        throw new ConfigurationException("config", "Property must be set");
    }
    String name = (String) properties.get("broker-name");
    if (name == null) {
        throw new ConfigurationException("broker-name", "Property must be set");
    }
    LOG.
    try {
        Thread.currentThread().setContextClassLoader(BrokerService.class.getClassLoader());
        Resource resource = Utils.resourceFromString(config);
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(new String[] { resource.getURL().toExternalForm() }, false);
        if (isCamelContextFactoryBeanExist()) {
            ctx.addBeanFactoryPostProcessor(new BeanFactoryPostProcessor() {

                @Override
                public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
                    beanFactory.addBeanPostProcessor(new BeanPostProcessor() {

                        @Override
                        public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
                            if (bean instanceof CamelContextFactoryBean) {
                                ((CamelContextFactoryBean) bean).setBundleContext(bundleContext);
                            }
                            return bean;
                        }

                        @Override
                        public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
                            return bean;
                        }
                    });
                }
            });
        }
                PropertyPlaceholderConfigurer configurator = new PropertyPlaceholderConfigurer();
                Properties props = new Properties();
        Enumeration<?> elements = properties.keys();
        while (elements.hasMoreElements()) {
            Object key = elements.nextElement();
            props.put(key, properties.get(key));
        }
        configurator.setProperties(props);
        configurator.setIgnoreUnresolvablePlaceholders(true);
        ctx.addBeanFactoryPostProcessor(configurator);
        ctx.refresh();
                BrokerService broker = ctx.getBean(BrokerService.class);
        if (broker == null) {
            throw new ConfigurationException(null, "Broker not defined");
        }
                SpringBrokerContext brokerContext = new SpringBrokerContext();
        brokerContext.setConfigurationUrl(resource.getURL().toExternalForm());
        brokerContext.setApplicationContext(ctx);
        broker.setBrokerContext(brokerContext);
        broker.setStartAsync(true);
        broker.start();
        if (!broker.isSlave())
            broker.waitUntilStarted();
        brokers.put(pid, broker);
        brokerRegs.put(pid, bundleContext.registerService(BrokerService.class, broker, properties));
    } catch (Exception e) {
        throw new ConfigurationException(null, "Cannot start the broker", e);
    }
}