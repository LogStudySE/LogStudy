public void start(Xid arg0, int arg1) throws XAException {
    LOG.
    transactionContext.start(arg0, arg1);
    try {
        setInManagedTx(true);
    } catch (JMSException e) {
        throw (XAException) new XAException(XAException.XAER_PROTO).initCause(e);
    }
}