public static void main(String[] args) throws JATEException, IOException, SolrServerException {
    String workingDir = System.getProperty("user.dir");
    Path solrHome = Paths.get(workingDir, "testdata", "solr-testbed");
    String solrHomeDir = solrHome.toString();
    String solrCoreName = "ACLRDTEC";
    EmbeddedSolrServer server = null;
    try {
        CoreContainer solrContainer = new CoreContainer(solrHomeDir);
        solrContainer.load();
        server = new EmbeddedSolrServer(solrContainer, solrCoreName);
        JATEDocument jateDocument = new JATEDocument("sample");
        jateDocument.setContent("Compatibility of systems of linear constraints over the set of natural numbers \n" + "Criteria of compatibility of a system of linear Diophantine equations, strict inequations, and " + "nonstrict inequations are considered. Upper bounds for components of a minimal set of solutions " + "and algorithms of construction of minimal generating sets of solutions for all types of systems " + "are given. These criteria and the corresponding algorithms for constructing a minimal " + "supporting set of solutions can be used in solving all the considered types of systems " + "and systems of mixed types.");
        JATEProperties jateProp = new JATEProperties();
        JATEUtil.addNewDoc(server, jateDocument.getId(), jateDocument.getId(), jateDocument.getContent(), jateProp, true);
        LOG.
        List<JATETerm> terms = new ArrayList<>();
        Map<String, String> initParam = new HashMap<>();
        initParam.put(AppParams.PREFILTER_MIN_TERM_TOTAL_FREQUENCY.getParamKey(), "1");
        initParam.put(AppParams.CUTOFF_TOP_K_PERCENT.getParamKey(), "1");
        AppRAKE appRAKE = new AppRAKE(initParam);
        terms = appRAKE.extract(server.getCoreContainer().getCore(solrCoreName), jateProp);
        LOG.info("complete ranking and filtering.");
        assert terms != null;
        assert terms.size() == 20;
        Map<String, Double> termScoreMap = new HashMap<>();
        for (JATETerm term : terms) {
            termScoreMap.put(term.getString(), term.getScore());
            System.out.println(term.getString() + "," + term.getScore());
        }
        
        Assert.assertEquals(Double.valueOf(8.5), termScoreMap.get("linear diophantine equation"));
        Assert.assertEquals(Double.valueOf(7.916666666666666), termScoreMap.get("minimal supporting set"));
        Assert.assertEquals(Double.valueOf(4.916666666666666), termScoreMap.get("minimal set"));
        Assert.assertEquals(Double.valueOf(4.5), termScoreMap.get("corresponding algorithm"));
        Assert.assertEquals(Double.valueOf(4.5), termScoreMap.get("linear constraint"));
        Assert.assertEquals(Double.valueOf(4.0), termScoreMap.get("strict inequation"));
        Assert.assertEquals(Double.valueOf(4.0), termScoreMap.get("nonstrict inequation"));
        Assert.assertEquals(Double.valueOf(3.666666666666667), termScoreMap.get("mixed type"));
        Assert.assertEquals(Double.valueOf(2.5), termScoreMap.get("solutions and algorithm"));
        Assert.assertEquals(Double.valueOf(2.25), termScoreMap.get("set"));
        Assert.assertEquals(Double.valueOf(1.6666666666666667), termScoreMap.get("type"));
        Assert.assertEquals(Double.valueOf(3.166666666666667), termScoreMap.get("considered type"));
        Assert.assertEquals(Double.valueOf(1.4), termScoreMap.get("system"));
        Assert.assertEquals(Double.valueOf(1.4), termScoreMap.get("systems and system"));
        Assert.assertEquals(Double.valueOf(1.0), termScoreMap.get("upper"));
        Assert.assertEquals(Double.valueOf(1.0), termScoreMap.get("component"));
        Assert.assertEquals(Double.valueOf(1.0), termScoreMap.get("solution"));
        Assert.assertEquals(Double.valueOf(1.0), termScoreMap.get("construction"));
        Assert.assertEquals(Double.valueOf(1.0), termScoreMap.get("compatibility"));
    } finally {
        if (server != null) {
            server.getCoreContainer().getCore(solrCoreName).close();
            server.getCoreContainer().shutdown();
            server.close();
        }
    }
    System.exit(0);
}