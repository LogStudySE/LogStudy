private TimeStatisticImpl executeTest(String preallocationStrategy) throws Exception {
    int randInt = rand.nextInt(100);
    File dataDirectory = new File("./target/activemq-data/kahadb" + randInt);
    final KahaDBStore store = new KahaDBStore();
    store.setCheckpointInterval(5000);
    store.setJournalMaxFileLength(32 * 1204 * 1024);
    store.deleteAllMessages();
    store.setDirectory(dataDirectory);
    store.setPreallocationStrategy(preallocationStrategy);
    store.setPreallocationScope(Journal.PreallocationScope.ENTIRE_JOURNAL_ASYNC.name());
    store.start();
    final File journalLog = new File(dataDirectory, "db-1.log");
    assertTrue("file exists", Wait.waitFor(new Wait.Condition() {

        @Override
        public boolean isSatisified() throws Exception {
            return journalLog.exists();
        }
    }));
    final Journal journal = store.getJournal();
    ByteSequence byteSequence = new ByteSequence(new byte[16 * 1024]);
    TimeStatisticImpl timeStatistic = new TimeStatisticImpl("append", "duration");
    for (int i = 0; i < 5000; i++) {
        final long start = System.currentTimeMillis();
        journal.write(byteSequence, true);
        timeStatistic.addTime(System.currentTimeMillis() - start);
    }
    LOG.
    store.stop();
    return timeStatistic;
}