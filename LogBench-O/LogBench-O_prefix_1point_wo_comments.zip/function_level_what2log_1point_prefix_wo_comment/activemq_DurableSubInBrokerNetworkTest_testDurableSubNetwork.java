
public void testDurableSubNetwork() throws Exception {
    LOG.
        ActiveMQConnectionFactory fact = new ActiveMQConnectionFactory(connector.getConnectUri().toString());
    Connection conn = fact.createConnection();
    conn.setClientID("clientID1");
    Session session = conn.createSession(false, 1);
    Destination dest = session.createTopic(topicName);
    TopicSubscriber sub = session.createDurableSubscriber((Topic) dest, subName);
    LOG.info("Durable subscription of name " + subName + "created.");
    Thread.sleep(100);
            assertTrue(foundSubInLocalBroker(subName));
    assertTrue(foundSubInRemoteBrokerByTopicName(topicName));
        sub.close();
    session.unsubscribe(subName);
    LOG.info("Unsubscribed from durable subscription.");
    Thread.sleep(100);
            assertFalse(foundSubInLocalBroker(subName));
    assertFalse("Durable subscription not unregistered on remote broker", foundSubInRemoteBrokerByTopicName(topicName));
}