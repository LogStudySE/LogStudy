
@RequestMapping(value = { "add" }, method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_UTF8_VALUE })
@ResponseBody
public RestTriggerResponse addEntity(@RequestBody String body) {
    log.
    Map<String, Object> valuesChanges = (Map<String, Object>) convertToMap(body).get("data");
    RestTriggerRequest<CandidateWorkHistory> restTriggerRequest = convertToObject(body);
    Integer entityID = restTriggerRequest.getMeta().getEntityId();
    Integer updatingUserID = restTriggerRequest.getMeta().getUserId();
    CandidateWorkHistoryRestTriggerTraverser traverser = new CandidateWorkHistoryRestTriggerTraverser(entityID, valuesChanges, updatingUserID, false, getRelatedEntityFields());
    return handleRequest(traverser, valuesChanges);
}