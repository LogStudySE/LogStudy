public void testCreateTemporaryQueueThenCreateAQueueFromItsName() throws Exception {
    Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
    Queue tempQueue = session.createTemporaryQueue();
    String name = tempQueue.getQueueName();
    LOG.
    Queue createdQueue = session.createQueue(name);
    assertEquals("created queue not equal to temporary queue", tempQueue, createdQueue);
}