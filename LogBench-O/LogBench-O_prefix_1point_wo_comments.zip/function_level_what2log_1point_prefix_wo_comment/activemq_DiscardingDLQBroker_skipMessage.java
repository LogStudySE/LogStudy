private void skipMessage(String prefix, MessageReference msgRef) {
    log.
}