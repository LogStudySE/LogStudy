@POST
@Consumes({ UmaConstants.JSON_MEDIA_TYPE })
@Produces({ UmaConstants.JSON_MEDIA_TYPE })
public Response registerPermission(@Context HttpServletRequest request, @HeaderParam("Authorization") String authorization, String requestAsString) {
    try {
        final AuthorizationGrant authorizationGrant = umaValidationService.assertHasProtectionScope(authorization);
                UmaPermissionList permissionList = parseRequest(requestAsString);
        umaValidationService.validatePermissions(permissionList, authorizationGrant.getClient());
        String ticket = permissionService.addPermission(permissionList, tokenService.getClientDn(authorization));
        return Response.status(Response.Status.CREATED).type(MediaType.APPLICATION_JSON_TYPE).entity(new PermissionTicket(ticket)).build();
    } catch (Exception ex) {
        if (ex instanceof WebApplicationException) {
            throw (WebApplicationException) ex;
        }
        log.
        throw errorResponseFactory.createWebApplicationException(Response.Status.INTERNAL_SERVER_ERROR, UmaErrorResponseType.SERVER_ERROR, "Internal error.");
    }
}