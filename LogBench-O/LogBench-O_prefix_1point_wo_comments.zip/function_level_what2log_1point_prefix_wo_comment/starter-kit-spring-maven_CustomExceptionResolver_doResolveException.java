@Override
protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
    log.
    log.error(ex.getMessage());
    response.setStatus(HttpStatus.BAD_REQUEST.value());
    return super.doResolveException(request, response, handler, ex);
}