public static <T> void unregisterService(Bundle bundle, Class<T> serviceClass, Class<? extends T> implClass) {
    try {
        if (LOG.isLoggable(Level.FINE)) {
            LOG.
        }
        ServiceReference<?> ref = bundle.getBundleContext().getServiceReference(implClass);
        if (ref != null) {
            bundle.getBundleContext().ungetService(ref);
        }
    } catch (Exception e) {
        LOG.log(Level.SEVERE, "Failed to unload service: " + implClass.getName(), e);
    }
}