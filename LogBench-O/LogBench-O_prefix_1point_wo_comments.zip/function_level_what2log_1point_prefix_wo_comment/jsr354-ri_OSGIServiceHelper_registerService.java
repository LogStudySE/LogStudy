public static <T> void registerService(Bundle bundle, Class<T> serviceClass, Class<? extends T> implClass) {
    try {
                if (LOG.isLoggable(Level.WARNING)) {
            LOG.
        }
                Hashtable<String, Object> props = new Hashtable<>();
        props.put(Constants.VERSION_ATTRIBUTE, bundle.getVersion().toString());
        String vendor = bundle.getHeaders().get(Constants.BUNDLE_VENDOR);
        props.put(Constants.SERVICE_VENDOR, (vendor != null ? vendor : "anonymous"));
                props.put(Constants.SERVICE_RANKING, Integer.valueOf(PriorityServiceComparator.getPriority(implClass)));
                JDKUtilServiceFactory<T> factory = new JDKUtilServiceFactory<>(implClass);
        BundleContext bundleContext = bundle.getBundleContext();
        bundleContext.registerService(serviceClass.getName(), factory, props);
        if (LOG.isLoggable(Level.FINE)) {
            LOG.fine("Registered service class: " + implClass.getName() + "(" + serviceClass.getName() + ")");
        }
    } catch (Exception e) {
        LOG.log(Level.SEVERE, "Failed to load service: " + implClass.getName(), e);
    }
}