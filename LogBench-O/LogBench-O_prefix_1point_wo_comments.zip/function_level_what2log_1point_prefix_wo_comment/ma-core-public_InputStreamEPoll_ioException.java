public void ioException(IOException e) {
    if (LOG.isDebugEnabled())
        LOG.
}