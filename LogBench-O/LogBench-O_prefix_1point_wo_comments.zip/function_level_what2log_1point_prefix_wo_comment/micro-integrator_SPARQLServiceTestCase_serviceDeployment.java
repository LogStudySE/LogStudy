@BeforeClass(alwaysRun = true)
public void serviceDeployment() throws Exception {
    super.init();
    serviceEndPoint = getServiceUrlHttp(serviceName);
    String resourceFileLocation = getResourceLocation();
    deployService(serviceName, new DataHandler(new URL("file:    log.
}