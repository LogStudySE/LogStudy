@GetMapping
public ResponseEntity<Map<String, TopicResponseDto>> getEvents() {
    try {
        Map<String, TopicResponseDto> result = topicsMap.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, o -> new TopicResponseDto(o.getValue().getServiceDataHashMap(), o.getValue().getPartitions())));
        return new ResponseEntity<>(result, HttpStatus.OK);
    } catch (Exception e) {
        log.
        return ResponseEntity.status(500).build();
    }
}