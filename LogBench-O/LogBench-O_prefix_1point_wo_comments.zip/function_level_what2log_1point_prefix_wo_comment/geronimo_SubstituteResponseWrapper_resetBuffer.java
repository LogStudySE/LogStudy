@Override
public void resetBuffer() {
    log.
    super.resetBuffer();
    if (substituteRequired()) {
                if (stream != null) {
            stream.reset();
        } else if (writer != null) {
            writer.reset();
        }
    }
}