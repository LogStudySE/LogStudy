@Test(timeout = 600000)
public void testMaxFrameSizeApplied() throws Exception {
    LOG.
    final CountDownLatch failed = new CountDownLatch(1);
    AmqpClient client = createAmqpClient();
    AmqpConnection connection = trackConnection(client.createConnection());
    connection.setListener(new AmqpConnectionListener() {

        @Override
        public void onException(Throwable ex) {
            failed.countDown();
        }
    });
    connection.setIdleTimeout(TEST_IDLE_TIMEOUT);
    connection.connect();
    AmqpSession session = connection.createSession();
    AmqpSender sender = session.createSender("queue:    byte[] payload = new byte[maxFrameSize * 2];
    for (int i = 0; i < payload.length; ++i) {
        payload[i] = 42;
    }
    AmqpMessage message = new AmqpMessage();
    message.setBytes(payload);
    sender.send(message);
    assertTrue("Connection should have failed", failed.await(30, TimeUnit.SECONDS));
    assertNotNull(getProxyToQueue(getTestName()));
    assertEquals(0, getProxyToQueue(getTestName()).getQueueSize());
    connection.close();
}