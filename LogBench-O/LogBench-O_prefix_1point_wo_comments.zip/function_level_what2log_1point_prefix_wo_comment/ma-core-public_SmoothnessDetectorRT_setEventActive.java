@Override
protected void setEventActive(long timestamp) {
    this.eventActive = true;
        if (limitBreech)
        raiseEvent(limitBreechActiveTime + getDurationMS(), createEventContext());
    else {
                log.
        eventActive = false;
    }
}