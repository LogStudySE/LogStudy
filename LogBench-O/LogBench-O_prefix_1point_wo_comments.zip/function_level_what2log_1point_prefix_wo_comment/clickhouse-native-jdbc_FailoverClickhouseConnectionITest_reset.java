@BeforeEach
public void reset() throws SQLException {
    resetDriverManager();
    container.start();
    containerHA.start();
    CK_PORT = container.getMappedPort(ClickHouseContainer.NATIVE_PORT);
    HA_HOST = containerHA.getHost();
    HA_PORT = containerHA.getMappedPort(ClickHouseContainer.NATIVE_PORT);
    LOG.
}