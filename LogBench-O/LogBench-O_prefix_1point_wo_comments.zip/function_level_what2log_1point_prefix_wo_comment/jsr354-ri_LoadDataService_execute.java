public boolean execute(String resourceId, Map<String, LoadableURLResource> resources) {
    LoadableURLResource load = resources.get(resourceId);
    if (Objects.nonNull(load)) {
        try {
            if (load.load()) {
                LOG.
                listener.trigger(resourceId, load);
                LOG.log(Level.FINE, "New data successfully loaded from: " + load.getRemoteResources());
                return true;
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Failed to read/load resource (checking fallback): " + resourceId, e);
        }
        try {
            if (load.loadFallback()) {
                LOG.log(Level.WARNING, "Read fallback data from: " + load.getFallbackResource());
                listener.trigger(resourceId, load);
                LOG.log(Level.WARNING, "Loaded fallback data from: " + load.getFallbackResource());
                return true;
            }
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Failed to read/load fallback resource: " + resourceId, e);
        }
    } else {
        throw new IllegalArgumentException("No such resource: " + resourceId);
    }
    return false;
}