@Override
protected Object handleGetObject(String key) {
    try {
        ConsoleResourceRegistry resourceRegistry = (ConsoleResourceRegistry) PortletManager.getKernel().getGBean(ConsoleResourceRegistry.class);
        String value = resourceRegistry.handleGetObject(BASENAME, getLocale(), key);
        return value == null ? key : value;
    } catch (Exception e) {
        log.
    }
    return null;
}