
public void destroy() {
    log.
    if (!startUpControllersList.isEmpty()) {
        for (StartUpController sc : startUpControllersList) {
            sc.destroy();
        }
        startUpControllersList.clear();
    } else if (!inboundRunnersThreadsMap.isEmpty()) {
        Iterator itr = inboundRunnersThreadsMap.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry entry = (Map.Entry) itr.next();
            Thread thread = (Thread) entry.getKey();
            InboundRunner inboundRunner = (InboundRunner) entry.getValue();
            inboundRunner.terminate();
            thread.interrupt();
            try {
                thread.join();
            } catch (InterruptedException e) {
                thread.interrupt();
                log.error("Error while stopping the inbound thread.");
            }
        }
        inboundRunnersThreadsMap.clear();
    }
}