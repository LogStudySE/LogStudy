
@AfterReturning(value = "this(io.splitet.core.api.EventHandler+) && execution(* execute(..))", returning = "retVal")
public void afterReturning(Object retVal) throws Throwable {
    log.
    operationContext.clearCommandContext();
    userContext.clearUserContext();
}