@Reference(name = "config.context.service", service = Axis2ConfigurationContextService.class, cardinality = ReferenceCardinality.MANDATORY, policy = ReferencePolicy.DYNAMIC, unbind = "unsetConfigurationContextService")
protected void setConfigurationContextService(Axis2ConfigurationContextService configurationContextService) {
    log.
    ServiceReferenceHolder.getInstance().setConfigurationContextService(configurationContextService);
}