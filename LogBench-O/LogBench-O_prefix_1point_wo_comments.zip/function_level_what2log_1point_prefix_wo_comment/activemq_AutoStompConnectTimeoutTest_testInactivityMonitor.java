@Test(timeout = 15000)
public void testInactivityMonitor() throws Exception {
    Thread t1 = new Thread() {

        @Override
        public void run() {
            try {
                connection = createSocket();
                connection.getOutputStream().write('C');
                connection.getOutputStream().flush();
            } catch (Exception ex) {
                LOG.
                exceptions.add(ex);
            }
        }
    };
    t1.start();
    assertTrue("one connection", Wait.waitFor(new Wait.Condition() {

        @Override
        public boolean isSatisified() throws Exception {
            AutoTcpTransportServer server = (AutoTcpTransportServer) brokerService.getTransportConnectorByScheme(getConnectorScheme()).getServer();
            return 1 == server.getCurrentTransportCount().get();
        }
    }, TimeUnit.SECONDS.toMillis(15), TimeUnit.MILLISECONDS.toMillis(250)));
        assertTrue("no dangling connections", Wait.waitFor(new Wait.Condition() {

        @Override
        public boolean isSatisified() throws Exception {
            AutoTcpTransportServer server = (AutoTcpTransportServer) brokerService.getTransportConnectorByScheme(getConnectorScheme()).getServer();
            return 0 == server.getCurrentTransportCount().get();
        }
    }, TimeUnit.SECONDS.toMillis(15), TimeUnit.MILLISECONDS.toMillis(500)));
    assertTrue("no exceptions", exceptions.isEmpty());
}