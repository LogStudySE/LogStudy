
public void post_init(ORBInitInfo info) {
    try {
        if (log.isDebugEnabled())
            log.
        try {
            info.add_server_request_interceptor(new ServiceContextInterceptor());
        } catch (DuplicateName dn) {
            log.error("Error registering interceptor", dn);
        }
    } catch (RuntimeException re) {
        log.error("Error registering interceptor", re);
        throw re;
    }
}