@Override
public void onStart(ITestContext ctx) {
    log.
    FbTestGlobalSettings.setRunningFromMaven(true);
}