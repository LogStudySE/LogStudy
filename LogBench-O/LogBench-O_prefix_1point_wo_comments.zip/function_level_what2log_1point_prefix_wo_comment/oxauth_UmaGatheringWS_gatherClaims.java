public Response gatherClaims(String clientId, String ticket, String claimRedirectUri, String state, Boolean reset, Boolean authenticationRedirect, HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
    try {
        log.
        SessionId session = sessionService.getSession(httpRequest, httpResponse);
        if (authenticationRedirect != null && authenticationRedirect) {
                        log.debug("Authentication redirect, restoring parameters from session ...");
            if (session == null) {
                log.error("Session is null however authentication=true. Wrong workflow! Please correct custom Glaims-Gathering Script.");
                throw errorResponseFactory.createWebApplicationException(BAD_REQUEST, INVALID_SESSION, "Session is null however authentication=true. Wrong workflow! Please correct custom Glaims-Gathering Script.");
            }
            clientId = sessionService.getClientId(session);
            ticket = sessionService.getTicket(session);
            claimRedirectUri = sessionService.getClaimsRedirectUri(session);
            state = sessionService.getState(session);
            log.debug("Restored parameters from session, clientId: {}, ticket: {}, claims_redirect_uri: {}, state: {}", clientId, ticket, claimRedirectUri, state);
        }
        validationService.validateClientAndClaimsRedirectUri(clientId, claimRedirectUri, state);
        List<UmaPermission> permissions = validationService.validateTicketWithRedirect(ticket, claimRedirectUri, state);
        String[] scriptNames = validationService.validatesGatheringScriptNames(getScriptNames(permissions), claimRedirectUri, state);
        CustomScriptConfiguration script = external.determineScript(scriptNames);
        if (script == null) {
            log.error("Failed to determine claims-gathering script for names: " + Arrays.toString(scriptNames));
            throw new UmaWebException(claimRedirectUri, errorResponseFactory, INVALID_CLAIMS_GATHERING_SCRIPT_NAME, state);
        }
        sessionService.configure(session, script.getName(), reset, permissions, clientId, claimRedirectUri, state);
        UmaGatherContext context = new UmaGatherContext(script.getConfigurationAttributes(), httpRequest, session, sessionService, permissionService, pctService, new HashMap<String, String>(), userService, null, appConfiguration);
        int step = sessionService.getStep(session);
        int stepsCount = external.getStepsCount(script, context);
        if (step < stepsCount) {
            String page = external.getPageForStep(script, step, context);
            context.persist();
            String baseEndpoint = StringUtils.removeEnd(appConfiguration.getBaseEndpoint(), "/");
            baseEndpoint = StringUtils.removeEnd(baseEndpoint, "restv1");
            baseEndpoint = StringUtils.removeEnd(baseEndpoint, "/");
            String fullUri = baseEndpoint + page;
            fullUri = StringUtils.removeEnd(fullUri, ".xhtml") + ".htm";
            log.trace("Redirecting to page: '{}', fullUri: {}", page, fullUri);
            return Response.status(FOUND).location(new URI(fullUri)).build();
        } else {
            log.error("Step '{}' is more or equal to stepCount: '{}'", stepsCount);
        }
    } catch (Exception ex) {
        log.error("Exception happened", ex);
        if (ex instanceof WebApplicationException) {
            throw (WebApplicationException) ex;
        }
    }
    log.error("Failed to handle call to UMA Claims Gathering Endpoint.");
    throw errorResponseFactory.createWebApplicationException(Response.Status.INTERNAL_SERVER_ERROR, UmaErrorResponseType.SERVER_ERROR, "Failed to handle call to UMA Claims Gathering Endpoint.");
}