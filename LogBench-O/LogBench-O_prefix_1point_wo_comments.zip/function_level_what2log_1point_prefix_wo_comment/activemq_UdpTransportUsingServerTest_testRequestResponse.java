public void testRequestResponse() throws Exception {
    ConsumerInfo expected = new ConsumerInfo();
    expected.setSelector("Edam");
    expected.setResponseRequired(true);
    LOG.
    Response response = (Response) producer.request(expected, 2000);
    LOG.info("Received: " + response);
    assertNotNull("Received a response", response);
    assertTrue("Should not be an exception", !response.isException());
}