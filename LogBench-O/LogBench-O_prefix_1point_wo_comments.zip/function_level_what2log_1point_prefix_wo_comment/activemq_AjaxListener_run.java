@Override
public void run() {
    LOG.
    client.closeConsumers();
}