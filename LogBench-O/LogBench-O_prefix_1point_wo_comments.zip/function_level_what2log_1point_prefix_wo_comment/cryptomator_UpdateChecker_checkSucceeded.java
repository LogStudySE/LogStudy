private void checkSucceeded(WorkerStateEvent event) {
    String latestVersion = updateCheckerService.getValue();
    LOG.
    if (semVerComparator.compare(currentVersion, latestVersion) < 0) {
                latestVersionProperty.set(latestVersion);
    } else {
        latestVersionProperty.set(null);
    }
}