@Override
public String getHostname() {
    final String fqdn = JiveGlobals.getXMLProperty("fqdn");
    if (fqdn != null && !fqdn.trim().isEmpty()) {
        return fqdn.trim().toLowerCase();
    }
    try {
        return InetAddress.getLocalHost().getCanonicalHostName().toLowerCase();
    } catch (UnknownHostException ex) {
        Log.
        return "localhost";
    }
}