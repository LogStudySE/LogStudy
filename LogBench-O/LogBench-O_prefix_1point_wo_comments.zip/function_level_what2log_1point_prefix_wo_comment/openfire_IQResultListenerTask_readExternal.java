@Override
public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
    final String xml = ExternalizableUtil.getInstance().readSafeUTF(in);
    try {
        final Element el = DocumentHelper.parseText(xml).getRootElement();
        packet = new IQ(el);
    } catch (Exception e) {
        Log.
    }
}