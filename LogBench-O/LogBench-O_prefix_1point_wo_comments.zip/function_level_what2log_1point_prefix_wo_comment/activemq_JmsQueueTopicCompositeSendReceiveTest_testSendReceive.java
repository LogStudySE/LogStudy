
public void testSendReceive() throws Exception {
    super.testSendReceive();
    messages.clear();
    consumer2.setMessageListener(this);
    assertMessagesAreReceived();
    LOG.
}