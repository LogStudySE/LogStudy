private MessageConsumer consumeVerifyOrder(Session session, final int num, final int base) throws Exception {
    MessageConsumer messageConsumer = session.createConsumer(dest);
    for (int i = 0; i < num; ) {
        Message message = messageConsumer.receive(4000);
        if (message != null) {
            assertEquals(i + base, message.getIntProperty("Order"));
            i++;
            LOG.
        }
    }
    return messageConsumer;
}