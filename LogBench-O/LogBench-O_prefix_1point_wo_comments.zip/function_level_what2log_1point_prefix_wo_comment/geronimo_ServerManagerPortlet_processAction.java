public void processAction(ActionRequest actionRequest, ActionResponse actionResponse) throws PortletException, IOException {
    Bundle framework = ((BundleReference) getClass().getClassLoader()).getBundle().getBundleContext().getBundle(0);
    if (actionRequest.getParameter("reboot") != null) {
        log.
        try {
            framework.update();
        } catch (BundleException e) {
            log.info("Problem rebooting", e);
        }
                                                                                    } else if (actionRequest.getParameter("shutdown") != null) {
        log.info("Shutting down by user request: " + actionRequest.getUserPrincipal().getName());
                        try {
            framework.stop();
        } catch (BundleException e) {
            log.info("Problem rebooting", e);
        }
    }
}