@Override
@SuppressWarnings("restriction")
protected Provider getProvider() {
    if (this.provider == null) {
        
        String aPKCS11LibraryFileName = this.getPkcs11Path();
        aPKCS11LibraryFileName = this.escapePath(aPKCS11LibraryFileName);
        final StringBuilder pkcs11Config = new StringBuilder();
        pkcs11Config.append("name = SmartCard").append(UUID.randomUUID().toString()).append("\n");
        pkcs11Config.append("library = \"").append(aPKCS11LibraryFileName).append("\"").append("\n");
        pkcs11Config.append("slotListIndex = ").append(this.getSlotListIndex());
        final String configString = pkcs11Config.toString();
        LOG.
        try (ByteArrayInputStream confStream = new ByteArrayInputStream(configString.getBytes("ISO-8859-1"))) {
            final sun.security.pkcs11.SunPKCS11 sunPKCS11 = new sun.security.pkcs11.SunPKCS11(confStream);
                        Security.addProvider(sunPKCS11);
            this.provider = sunPKCS11;
            return this.provider;
        } catch (final Exception e) {
            throw new DSSException("Unable to instantiate SunPKCS11", e);
        }
    }
    return this.provider;
}