@Override
public void run() {
    try {
        BytesMessage message = producerSession.createBytesMessage();
        message.writeBytes(payload.data, payload.offset, payload.length);
        producer.send(message);
        LOG.
        sentAll.countDown();
    } catch (JMSException e) {
        LOG.warn("Send of message did not complete.");
    }
}