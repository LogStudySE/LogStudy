@Before
public void refreshTestData() {
    try {
        MockBullhornData mockBullhornData = (MockBullhornData) this.bullhornData;
        mockBullhornData.refreshTestData();
    } catch (ClassCastException e) {
        log.
    }
}