private boolean readCustomLogo(HttpServletResponse response, GluuOrganization organization) {
    if (organization.getOxAuthLogoPath() == null || StringUtils.isEmpty(organization.getOxAuthLogoPath())) {
        return false;
    }
    File directory = new File(BASE_OXAUTH_LOGO_PATH);
    if (!directory.exists()) {
        directory.mkdir();
    }
    File logoPath = new File(organization.getOxAuthLogoPath());
    if (!logoPath.exists()) {
        return false;
    }
    try (InputStream in = new FileInputStream(logoPath);
        OutputStream out = response.getOutputStream()) {
        IOUtils.copy(in, out);
        return true;
    } catch (IOException e) {
        log.
        return false;
    }
}