@Override
public void open() throws ListenerException {
    if (StringUtils.isEmpty(getServiceName())) {
        log.
        ServiceDispatcher.getInstance().registerServiceClient(getName(), this);
    } else {
        log.debug("registering listener [" + getName() + "] with ServiceDispatcher by serviceName [" + getServiceName() + "]");
        ServiceDispatcher.getInstance().registerServiceClient(getServiceName(), this);
    }
    super.open();
}