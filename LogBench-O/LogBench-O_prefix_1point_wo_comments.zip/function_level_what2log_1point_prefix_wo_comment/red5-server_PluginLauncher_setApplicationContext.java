public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    log.
    this.applicationContext = applicationContext;
}