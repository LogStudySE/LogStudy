@Test
public void testStartBrokerUsingXmlConfig1() throws Exception {
    BrokerService broker = null;
    LOG.
    System.err.println("Broker config: " + configUrl);
    broker = BrokerFactory.createBroker(configUrl);
    broker.start();
    broker.waitUntilStarted(5000l);
        try {
        for (TransportConnector transport : broker.getTransportConnectors()) {
            final URI UriToConnectTo = URISupport.removeQuery(transport.getConnectUri());
            if (UriToConnectTo.getScheme().startsWith("stomp")) {
                LOG.info("validating alive with connection to: " + UriToConnectTo);
                StompConnection connection = new StompConnection();
                connection.open(UriToConnectTo.getHost(), UriToConnectTo.getPort());
                connection.close();
                break;
            } else if (UriToConnectTo.getScheme().startsWith("tcp")) {
                LOG.info("validating alive with connection to: " + UriToConnectTo);
                ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(UriToConnectTo);
                Connection connection = connectionFactory.createConnection(secProps.getProperty("activemq.username"), secProps.getProperty("activemq.password"));
                connection.start();
                connection.close();
                break;
            } else {
                LOG.info("not validating connection to: " + UriToConnectTo);
            }
        }
    } finally {
        if (broker != null) {
            broker.stop();
            broker.waitUntilStopped();
            broker = null;
        }
    }
}