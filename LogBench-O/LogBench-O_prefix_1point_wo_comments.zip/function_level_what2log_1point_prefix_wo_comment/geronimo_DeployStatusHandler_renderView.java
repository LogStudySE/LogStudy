public void renderView(RenderRequest request, RenderResponse response, MultiPageModel model) throws PortletException, IOException {
    WARConfigData data = getWARSessionData(request);
    try {
        File moduleFile = new File(new URI(data.getUploadedWarUri()));
        File planFile = File.createTempFile("console-deployment", ".xml");
        planFile.deleteOnExit();
        FileWriter out = new FileWriter(planFile);
        out.write(data.getDeploymentPlan());
        out.close();
        String[] status = JSR88_Util.deploy(request, moduleFile, planFile);
        if (null != status[1] && 0 != status[1].length()) {
            portlet.addErrorMessage(request, portlet.getLocalizedString(request, status[0]), status[1]);
        } else {
            portlet.addInfoMessage(request, portlet.getLocalizedString(request, status[0]));
        }
    } catch (URISyntaxException e) {
        log.
    }
    request.setAttribute(DATA_PARAMETER, data);
}