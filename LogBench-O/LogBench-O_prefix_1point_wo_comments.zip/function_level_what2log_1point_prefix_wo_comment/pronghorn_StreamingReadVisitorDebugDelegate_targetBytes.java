@Override
public ByteBuffer targetBytes(String name, long id, int length) {
    log.
    return delegate.targetBytes(name, id, length);
}