protected void restoreThreadContext() {
    if (savedThreadContext != null) {
        log.
        ThreadContext.putAll(savedThreadContext);
        savedThreadContext = null;
    }
}