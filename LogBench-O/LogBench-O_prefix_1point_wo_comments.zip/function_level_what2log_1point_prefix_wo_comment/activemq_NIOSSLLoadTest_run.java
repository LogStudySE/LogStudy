@Override
public void run() {
    for (int i = 0; i < 100; i++) {
        Connection conn = null;
        try {
            conn = factory.createConnection();
            conn.start();
            Session sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
            int sleepTime = rand.nextInt((3000 - 1000) + 1) + 1000;
            LOG.
            Thread.sleep(sleepTime);
        } catch (Exception e) {
            e.printStackTrace();
            errors.incrementAndGet();
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
            }
            LOG.info(getName() + " iteration " + i);
        }
    }
    LOG.info(getName() + " finished");
    latch.countDown();
}