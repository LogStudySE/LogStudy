public void dispose() {
    if (disposed) {
        return;
    }
    disposed = true;
    try {
        dataFile.closeRandomAccessFile(file);
    } catch (IOException e) {
        LOG.
    }
}