private static void addEventData(Object[] eventData, StructuringArtifact structuringArtifact) {
    
    eventData[0] = String.valueOf(structuringArtifact.getHashcode());
    
    eventData[1] = String.valueOf(structuringArtifact.getName());
    ArrayList<StructuringElement> elementList = structuringArtifact.getList();
    String jsonString = null;
    try {
        jsonString = mapper.writeValueAsString(elementList);
    } catch (JsonProcessingException e) {
        log.
    }
    
    eventData[2] = jsonString;
}