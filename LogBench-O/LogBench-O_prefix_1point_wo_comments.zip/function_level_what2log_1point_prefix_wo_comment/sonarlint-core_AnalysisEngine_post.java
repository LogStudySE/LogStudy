public <T> CompletableFuture<T> post(Command<T> command, ProgressMonitor progressMonitor) {
    if (termination.get() != null) {
        LOG.
        return CompletableFuture.completedFuture(null);
    }
    if (!analysisThread.isAlive()) {
        LOG.error("Analysis engine not started, ignoring command");
        return CompletableFuture.completedFuture(null);
    }
    var asyncCommand = new AsyncCommand<>(command, progressMonitor);
    try {
        commandQueue.put(asyncCommand);
    } catch (InterruptedException e) {
        asyncCommand.future.completeExceptionally(e);
    }
    return asyncCommand.future;
}