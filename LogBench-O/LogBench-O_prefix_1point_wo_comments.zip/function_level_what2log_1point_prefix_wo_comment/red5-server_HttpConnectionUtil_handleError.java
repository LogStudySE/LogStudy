
public static void handleError(HttpResponse response) throws ParseException, IOException {
    log.
    HttpEntity entity = response.getEntity();
    if (entity != null) {
        log.debug("{}", EntityUtils.toString(entity));
    }
}