@Test
public void testAddress() {
    ECKey key = AccountTool.newPriKey();
    log.
    log.info("pub key is :" + key.getPublicKeyAsHex());
    log.info("pub key not compressed is :" + key.getPublicKeyAsHex(false));
    int i = 0;
    while (true) {
        Address address = AccountTool.newAddress(network, network.getSystemAccountVersion());
        log.info("new address is :" + address);
        if (!address.getBase58().startsWith("u")) {
            System.err.println("==============");
            return;
        }
        i++;
        if (i == 100) {
            break;
        }
    }
    Address address = Address.fromP2PKHash(network, network.getSystemAccountVersion(), Utils.sha256hash160(ECKey.fromPrivate(new BigInteger("61914497277584841097702477783063064420681667313180238384957944936487927892583")).getPubKey(false)));
    assertEquals(address.getBase58(), "uMRDgrtfDvG5qkWBs1cHoTt8YbxFf7cDch");
    address = AccountTool.newAddressFromPrikey(network, network.getSystemAccountVersion(), new BigInteger(Hex.decode("18E14A7B6A307F426A94F8114701E7C8E774E7F9A47E2C2035DB29A206321725")));
    assertEquals(address.getBase58(), "uK2twT5bjB7WMknf1inMN73ZaktkGMSMnP");
    address = Address.fromBase58(network, "uK2twT5bjB7WMknf1inMN73ZaktkGMSMnP");
    assertEquals(address.getHash160AsHex(), "010966776006953d5567439e5e39f86a0d273bee");
}