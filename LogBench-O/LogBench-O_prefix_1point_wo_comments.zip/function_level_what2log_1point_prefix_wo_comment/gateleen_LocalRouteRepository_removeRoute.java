@Override
public void removeRoute(String urlPattern) {
    log.
    String routeKey = findFirstMatchingKey(routes, urlPattern);
    if (routeKey != null) {
        cleanupRoute(getRoute(routeKey));
        routes.remove(routeKey);
    }
}