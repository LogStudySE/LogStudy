public static void createMigrationDirectoryIfNotExists() {
    String migrationDirPath = Paths.get(carbonHome, "migration").toString();
    File migrationDir = new File(migrationDirPath);
    if (!migrationDir.exists()) {
        log.
        if (migrationDir.mkdir()) {
            log.info("Created directory " + migrationDir.getAbsolutePath());
        } else {
            log.error("Could not create directory " + migrationDirPath + "." + " Please create the directory manually and re-run the service");
        }
    }
}