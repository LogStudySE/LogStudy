public void starting(Artifact configurationId) {
    log.
}