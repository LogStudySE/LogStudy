@Override
public String[] getUserRoles(MessageContext messageContext) throws DataServiceFault {
    log.
    String[] roleArray = { "admin", "sampleRole1", "sampleRole2", userRole };
    return roleArray;
}