public void unsubscribe(String subscriptionID) throws RemoteException {
    log.
    EventBrokerServiceStub service = new EventBrokerServiceStub(configurationContext, backendUrl);
    configureCookie(service._getServiceClient());
    ServiceClient serviceClient = service._getServiceClient();
    OMElement header = omFactory.createOMElement(new QName(WSE_EVENTING_NS, WSE_EN_IDENTIFIER));
    header.setText(subscriptionID);
    serviceClient.addHeader(header);
    service.unsubscribe(new OMElement[] {});
}