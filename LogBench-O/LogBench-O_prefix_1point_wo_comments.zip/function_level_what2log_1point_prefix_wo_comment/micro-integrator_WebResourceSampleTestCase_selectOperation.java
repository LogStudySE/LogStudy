@Test(groups = { "wso2.dss" }, invocationCount = 5, description = "invoke the service five times", enabled = false)
public void selectOperation() throws AxisFault, InterruptedException, XPathExpressionException {
    OMFactory fac = OMAbstractFactory.getOMFactory();
    OMNamespace omNs = fac.createOMNamespace("http:    OMElement payload = fac.createOMElement("getAppInfo", omNs);
    Thread.sleep(1000);
    OMElement result = new AxisServiceClient().sendReceive(payload, getServiceUrlHttp(serviceName), "getAppInfo");
    Assert.assertNotNull(result, "Service invocation returns null response");
    Assert.assertTrue(result.toString().contains("<Title>"));
    Assert.assertTrue(result.toString().contains("<Description>"));
    log.
}