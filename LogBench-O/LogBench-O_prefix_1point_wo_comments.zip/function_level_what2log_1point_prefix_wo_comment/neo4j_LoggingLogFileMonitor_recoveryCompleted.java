@Override
public void recoveryCompleted(int numberOfRecoveredTransactions, long recoveryTimeInMilliseconds) {
    if (numberOfRecoveredTransactions != 0) {
        log.
    } else {
        log.info("No recovery required");
    }
}