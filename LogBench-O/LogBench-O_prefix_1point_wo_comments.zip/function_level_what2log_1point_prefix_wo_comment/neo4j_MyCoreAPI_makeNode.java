public long makeNode(Transaction tx, String label) throws ProcedureException {
    try {
        KernelTransaction ktx = ((InternalTransaction) tx).kernelTransaction();
        long nodeId = ktx.dataWrite().nodeCreate();
        int labelId = ktx.tokenWrite().labelGetOrCreateForName(label);
        ktx.dataWrite().nodeAddLabel(nodeId, labelId);
        return nodeId;
    } catch (Exception e) {
        log.
        throw new ProcedureException(Status.Procedure.ProcedureCallFailed, "Failed to create node: " + e.getMessage(), e);
    }
}