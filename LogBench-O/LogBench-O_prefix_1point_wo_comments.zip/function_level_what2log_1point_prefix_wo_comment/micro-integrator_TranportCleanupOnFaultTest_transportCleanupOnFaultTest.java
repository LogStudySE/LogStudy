@Test(groups = { "wso2.esb" })
public void transportCleanupOnFaultTest() throws AxisFault {
    try {
        axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "SUN");
    } catch (AxisFault axisFault) {
        log.
    }
    try {
        axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "SUN");
    } catch (AxisFault axisFault) {
        log.info("Fault message received");
    }
    try {
        axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "SUN");
    } catch (AxisFault axisFault) {
        log.info("Fault message received");
    }
    try {
        axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "SUN");
    } catch (AxisFault axisFault) {
        log.info("Fault message received");
    }
    OMElement response = axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "IBM");
    boolean ResponseContainsIBM = response.getFirstElement().toString().contains("IBM");
    assertTrue(ResponseContainsIBM);
}