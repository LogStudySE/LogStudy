@Override
public void onSharedObjectDisconnect(ISharedObjectBase so) {
    log.
}