@ParameterizedTest
@MethodSource("data")
void testCli(String browser, String driver) {
    log.
    WebDriverManager.main(new String[] { "resolveDriverFor", browser });
    File driverFile = new File(driver);
    boolean exists = driverFile.exists();
    assertThat(exists).isTrue();
    boolean delete = driverFile.delete();
    log.debug("CLI test resolving driver for {} OK (driver deleted: {})", browser, delete);
}