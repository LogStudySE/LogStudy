public void initTimer() {
    log.
    this.isActive = new AtomicBoolean(false);
    expiringMap = ExpiringMap.builder().expirationPolicy(ExpirationPolicy.CREATED).maxSize(appConfiguration.getExpirationNotificatorMapSizeLimit()).variableExpiration().build();
    expiringMap.addExpirationListener(this);
    timerEvent.fire(new TimerEvent(new TimerSchedule(DEFAULT_INTERVAL, DEFAULT_INTERVAL), new ExpirationEvent(), Scheduled.Literal.INSTANCE));
    this.lastFinishedTime = System.currentTimeMillis();
}