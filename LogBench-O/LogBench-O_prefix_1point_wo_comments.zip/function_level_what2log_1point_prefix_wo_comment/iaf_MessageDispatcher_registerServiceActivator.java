private void registerServiceActivator(Object bean, Method method, SubscribableChannel channel, BusTopic topic) {
    String componentName = bean.getClass().getSimpleName() + "." + method.getName();
    ServiceActivatingHandler serviceActivator = new ServiceActivatingHandler(bean, method);
        serviceActivator.setComponentName(componentName);
    serviceActivator.setManagedName("@" + componentName);
    initializeBean(serviceActivator);
    MessageSelectorChain selectors = new MessageSelectorChain();
    ActionSelector action = AnnotationUtils.findAnnotation(method, ActionSelector.class);
    if (action != null) {
        selectors.add(actionSelector(action.value()));
    }
    selectors.add(topicSelector(topic));
    selectors.add(activeSelector(applicationContext));
    MessageFilter filter = new MessageFilter(selectors);
    filter.setDiscardChannel(nullChannel);
    initializeBean(filter);
    List<MessageHandler> handlers = new ArrayList<>();
    handlers.add(filter);
    handlers.add(serviceActivator);
    MessageHandlerChain chain = new MessageHandlerChain();
    chain.setHandlers(handlers);
    chain.setComponentName(componentName);
    initializeBean(chain);
    if (channel.subscribe(chain)) {
        log.
    } else {
        log.info("unable to register ServiceActivator [{}]", componentName);
    }
}