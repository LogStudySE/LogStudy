private void restrictTopics(String username, Collection<String> topics) {
    if (!topics.isEmpty()) {
        log.
        for (String topic : topics) {
            String[] topicConsumerACLsCmd = getTopicConsumerACLCmd(username, topic, zookeeperProperties.getZookeeperConnect());
            String[] topicProducerACLsCmd = getTopicProducerACLCmd(username, topic, zookeeperProperties.getZookeeperConnect());
            Container.ExecResult topicConsumerACLsOutput = executeInContainer(this.kafka, topicConsumerACLsCmd);
            Container.ExecResult topicProducerACLsOutput = executeInContainer(this.kafka, topicProducerACLsCmd);
            log.debug("Topic={} consumer ACLs cmd='{}' execResult={}, producer ACLs cmd='{}' execResult={}", topic, topicConsumerACLsCmd, topicConsumerACLsOutput, topicProducerACLsCmd, topicProducerACLsOutput.getExitCode());
        }
        log.info("Created ACLs for Kafka topics: {}", topics);
    }
}