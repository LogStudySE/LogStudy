@Override
public void resourceChanged(String resourceUri, Buffer resource) {
    if (configResourceUri() != null && configResourceUri().equals(resourceUri)) {
        log.
        initializeConstraintConfiguration(resource);
    }
}