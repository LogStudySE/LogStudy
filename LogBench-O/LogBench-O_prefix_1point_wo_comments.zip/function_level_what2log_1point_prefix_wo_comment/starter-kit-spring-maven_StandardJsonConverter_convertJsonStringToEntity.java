@Override
public <T, E> T convertJsonStringToEntity(String jsonString, Class<T> parameterizedType, Class<E> parameterType) {
    T entity = null;
    try {
        JavaType type = objectMapperStandard.getTypeFactory().constructParametrizedType(parameterizedType, parameterizedType, parameterType);
        entity = objectMapperStandard.readValue(jsonString, type);
    } catch (IOException e) {
        log.
    }
    return entity;
}