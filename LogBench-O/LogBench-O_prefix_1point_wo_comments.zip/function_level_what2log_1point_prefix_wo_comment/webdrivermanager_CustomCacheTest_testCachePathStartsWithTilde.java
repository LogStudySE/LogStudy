@Test
void testCachePathStartsWithTilde() {
    String customPath = "~webdrivers";
    wdm.config().setCachePath(customPath);
    String cachePath = wdm.config().getCachePath();
    log.
    assertThat(cachePath).startsWith(customPath);
}