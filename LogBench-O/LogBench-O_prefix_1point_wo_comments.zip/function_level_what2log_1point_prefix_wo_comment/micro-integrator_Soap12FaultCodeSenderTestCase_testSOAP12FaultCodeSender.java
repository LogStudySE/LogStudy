@Test(groups = { "wso2.esb" }, description = "Creating SOAP1.2 fault code Sender")
public void testSOAP12FaultCodeSender() throws AxisFault {
    String proxyServiceName = "Soap12FaultCodeSenderTestCaseProxy";
    try {
        axis2Client.sendSimpleStockQuoteSoap12(getProxyServiceURLHttp(proxyServiceName), "http:        fail("This query must throw an exception.");
    } catch (AxisFault expected) {
        log.
        assertEquals(expected.getReason(), "Soap12FaultCodeSenderTestCase", "Fault Reason Mismatched");
        assertEquals(expected.getFaultCode().getLocalPart(), "Sender", "Fault code value mismatched");
        assertEquals(expected.getFaultCode().getPrefix(), "soap12Env", "Fault code prefix mismatched");
    }
}