
public Serializable decrypt(String source) {
    SecretKeySpec spec = getSecretKeySpec();
    try {
        byte[] data = Base64.decode(source);
        Cipher c = Cipher.getInstance(spec.getAlgorithm());
        c.init(Cipher.DECRYPT_MODE, spec);
        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(data));
        SealedObject so = (SealedObject) in.readObject();
        return (Serializable) so.getObject(c);
    } catch (Exception e) {
        log.
        return null;
    }
}