public boolean remove(SessionId sessionId) {
    try {
        persistenceEntryManager.remove(sessionId.getDn(), SessionId.class);
        externalApplicationSessionService.externalEvent(new SessionEvent(SessionEventType.GONE, sessionId));
        return true;
    } catch (Exception e) {
        log.
        return false;
    }
}