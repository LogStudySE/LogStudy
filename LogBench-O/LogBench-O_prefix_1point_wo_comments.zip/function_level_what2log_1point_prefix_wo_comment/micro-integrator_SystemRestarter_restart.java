public static void restart() {
    log.
    log.info("Halting JVM");
    if (System.getProperty("wrapper.key") != null) {
                WrapperManager.restart();
    } else {
                System.exit(EXIT_CODE);
    }
}