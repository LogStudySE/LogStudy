public void stopGenerateReport() {
    writeWithIndent(0, "</test-report>");
    this.getWriter().flush();
    this.getWriter().close();
    LOG.
}