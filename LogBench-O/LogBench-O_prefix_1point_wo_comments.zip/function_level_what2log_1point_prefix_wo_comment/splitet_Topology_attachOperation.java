public void attachOperation(OperationEvent operation) {
    if (operationState != TransactionState.RUNNING)
        log.
    this.endTime = operation.getOpDate();
    if (Objects.equals(operation.getSender(), getInitiatorService()) && Objects.equals(operation.getAggregateId(), getInitiatorCommand())) {
        operationState = operation.getTransactionState();
        this.operation = operation;
    } else {
        boolean result = producedEvents.stream().anyMatch(producedEvent -> producedEvent.attachOperation(operation));
        if (result)
            operationState = operation.getTransactionState();
        else {
            log.debug("We Couldn't attach, " + opId + " Adding to UnAssigned Operation Event:" + operation);
            unassignedOperations.add(operation);
        }
    }
}