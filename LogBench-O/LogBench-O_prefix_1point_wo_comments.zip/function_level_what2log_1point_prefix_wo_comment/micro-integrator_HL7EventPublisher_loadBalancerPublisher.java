private void loadBalancerPublisher(EventPublisherConfig eventPublisherConfig, StreamDefinition streamDef, String key, List<Object> correlationData, List<Object> metaData, List<Object> payLoadData, Map<String, String> arbitraryDataMap) throws HL7Exception {
    if (log.isDebugEnabled()) {
        log.
    }
    if (eventPublisherConfig == null) {
        if (log.isDebugEnabled()) {
            log.debug("Newly creating publisher configuration.");
        }
        synchronized (HL7EventPublisher.class) {
            eventPublisherConfig = new EventPublisherConfig();
            DataPublisher loadBalancingDataPublisher;
            try {
                if (serverConfig.getSecureUrl() != null) {
                    loadBalancingDataPublisher = new DataPublisher(DataEndpointConstants.THRIFT_DATA_AGENT_TYPE, serverConfig.getUrl(), serverConfig.getSecureUrl(), serverConfig.getUsername(), serverConfig.getPassword());
                } else {
                    loadBalancingDataPublisher = new DataPublisher(serverConfig.getUrl(), serverConfig.getUsername(), serverConfig.getPassword());
                }
            } catch (DataEndpointAgentConfigurationException | DataEndpointException | DataEndpointConfigurationException | DataEndpointAuthenticationException | TransportException e) {
                String errorMsg = "Error occurred while creating data publisher";
                log.error(errorMsg);
                throw new HL7Exception(errorMsg, e);
            }
            if (log.isDebugEnabled()) {
                log.debug("Created stream definition.");
            }
            eventPublisherConfig.setLoadBalancingDataPublisher(loadBalancingDataPublisher);
            if (log.isDebugEnabled()) {
                log.debug("Adding config info to map.");
            }
            EventPublishConfigHolder.getEventPublisherConfigMap().put(key, eventPublisherConfig);
        }
    }
    DataPublisher loadBalancingDataPublisher = eventPublisherConfig.getLoadBalancingDataPublisher();
    loadBalancingDataPublisher.publish(DataBridgeCommonsUtils.generateStreamId(streamDef.getName(), streamDef.getVersion()), getObjectArray(metaData), getObjectArray(correlationData), getObjectArray(payLoadData), arbitraryDataMap);
    if (log.isDebugEnabled()) {
        log.debug("Successfully published data.");
    }
}