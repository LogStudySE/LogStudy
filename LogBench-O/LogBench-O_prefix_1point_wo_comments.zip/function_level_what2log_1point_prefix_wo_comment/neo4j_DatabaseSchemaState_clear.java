@Override
public void clear() {
    state.clear();
    log.
}