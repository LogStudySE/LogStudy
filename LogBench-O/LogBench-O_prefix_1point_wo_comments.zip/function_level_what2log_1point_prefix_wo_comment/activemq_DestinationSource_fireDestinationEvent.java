protected void fireDestinationEvent(DestinationEvent event) {
        ActiveMQDestination destination = event.getDestination();
    boolean add = event.isAddOperation();
    if (destination instanceof ActiveMQQueue) {
        ActiveMQQueue queue = (ActiveMQQueue) destination;
        if (add) {
            queues.add(queue);
        } else {
            queues.remove(queue);
        }
    } else if (destination instanceof ActiveMQTopic) {
        ActiveMQTopic topic = (ActiveMQTopic) destination;
        if (add) {
            topics.add(topic);
        } else {
            topics.remove(topic);
        }
    } else if (destination instanceof ActiveMQTempQueue) {
        ActiveMQTempQueue queue = (ActiveMQTempQueue) destination;
        if (add) {
            temporaryQueues.add(queue);
        } else {
            temporaryQueues.remove(queue);
        }
    } else if (destination instanceof ActiveMQTempTopic) {
        ActiveMQTempTopic topic = (ActiveMQTempTopic) destination;
        if (add) {
            temporaryTopics.add(topic);
        } else {
            temporaryTopics.remove(topic);
        }
    } else {
        LOG.
    }
    if (listener != null) {
        listener.onDestinationEvent(event);
    }
}