public void run() {
    try {
        String[] xmls = null;
        if (Configure.RUN_MODE == 1) {
            xmls = new String[] { "classpath:/applicationContext-mainnet.xml", "classpath:/applicationContext.xml" };
        } else if (Configure.RUN_MODE == 2) {
            xmls = new String[] { "classpath:/applicationContext-testnet.xml", "classpath:/applicationContext.xml" };
        } else {
            xmls = new String[] { "classpath:/applicationContext-unit.xml", "classpath:/applicationContext.xml" };
        }
        springContext = new ClassPathXmlApplicationContext(xmls);
        springContext.start();
                TestNetworkParams network = springContext.getBean(TestNetworkParams.class);
                        network.getSeedManager().add(new Seed(new InetSocketAddress("192.168.1.12", 6888)));
        AppKit appKit = springContext.getBean(AppKit.class);
        appKit.startSyn();
        log.
    } catch (RuntimeException e) {
        e.printStackTrace();
    }
}