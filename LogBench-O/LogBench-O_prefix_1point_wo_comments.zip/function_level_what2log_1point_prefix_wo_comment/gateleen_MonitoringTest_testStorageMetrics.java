@Test
public void testStorageMetrics(TestContext context) throws Exception {
    Async async = context.async();
        delete();
            String metricName = "mainstorage";
        JsonObject storageRule = TestUtils.createRoutingRule(ImmutableMap.<String, Serializable>builder().put("description", "a routing for the metric tests").put("metricName", metricName).put("path", "/$1").put("storage", "main").put("logExpiry", 0).build());
    JsonObject rules = TestUtils.addRoutingRule(new JsonObject(), "/(.*)", storageRule);
    TestUtils.putRoutingRules(rules);
        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
        String beanName = "metrics:name=" + PREFIX + "routing." + metricName + ".duration";
    ObjectName beanNameObject = new ObjectName(beanName);
        for (int count = 0; count < 10; count++) {
        given().body("{ \"name\" : \"test" + count + "\" }").put("res" + count).then().assertThat().statusCode(200);
        TestUtils.waitSomeTime(1);
        get("res" + count).then().assertThat().statusCode(200);
        TestUtils.waitSomeTime(1);
    }
        for (int count = 0; count < 10; count++) {
        delete("res" + count);
        given().body("{ \"name\" : \"test" + count + "\" }").put("res" + count).then().assertThat().statusCode(200);
        get("res" + count).then().assertThat().statusCode(200);
    }
        for (int count = 0; count < 1000; count++) {
        given().body("{ \"name\" : \"test" + count + "\" }").put("newres" + count).then().assertThat().statusCode(200);
    }
        TestUtils.waitSomeTime(1);
        if (mbs.isRegistered(beanNameObject)) {
        log.
        log.info(" > Mean:   {}", mbs.getAttribute(beanNameObject, "Mean"));
        log.info(" > Max:    {}", mbs.getAttribute(beanNameObject, "Max"));
        log.info(" > Count:  {}", mbs.getAttribute(beanNameObject, "Count"));
        log.info(" > StdDev: {}", mbs.getAttribute(beanNameObject, "StdDev"));
                context.assertTrue((Long) mbs.getAttribute(beanNameObject, "Max") <= MAX_DURATION_THRESHOLD, "'Max' should be below the threshold");
                context.assertTrue((Double) mbs.getAttribute(beanNameObject, "Mean") <= MEAN_DURATION_THRESHOLD, "'Mean' should be below the threshold");
    } else {
        context.fail("could not found mbean " + beanName);
    }
    async.complete();
}