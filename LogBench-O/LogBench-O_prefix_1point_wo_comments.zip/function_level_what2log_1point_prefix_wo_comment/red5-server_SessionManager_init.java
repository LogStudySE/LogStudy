public void init() {
    if (schedulingService != null) {
                schedulingService.addScheduledJob(3600000, new ReaperJob());
    } else {
        log.
    }
}