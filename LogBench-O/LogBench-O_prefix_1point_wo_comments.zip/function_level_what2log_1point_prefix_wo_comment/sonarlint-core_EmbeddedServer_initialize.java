public void initialize(HostInfoDto clientInfo) {
    final var socketConfig = SocketConfig.custom().setSoTimeout(15, TimeUnit.SECONDS).    setSoReuseAddress(true).setTcpNoDelay(true).build();
    port = INVALID_PORT;
    var triedPort = STARTING_PORT;
    HttpServer startedServer = null;
    while (port < 0 && triedPort <= ENDING_PORT) {
        try {
            startedServer = ServerBootstrap.bootstrap().setLocalAddress(InetAddress.getLoopbackAddress()).            setConnectionReuseStrategy(new DontKeepAliveReuseStrategy()).setListenerPort(triedPort).setSocketConfig(socketConfig).addFilterFirst("CORS", new CorsFilter()).register("/sonarlint/api/status", new StatusRequestHandler(client, connectionService, clientInfo)).register("/sonarlint/api/token", new GeneratedUserTokenHandler(awaitingUserTokenFutureRepository)).register("/sonarlint/api/hotspots/show", new ShowHotspotRequestHandler(client, connectionService, configurationService, bindingSuggestionProvider, serverApiProvider, telemetryService)).create();
            startedServer.start();
            port = triedPort;
        } catch (Exception t) {
            LOG.
            triedPort++;
            if (startedServer != null) {
                startedServer.close();
            }
        }
    }
    if (port > 0) {
        LOG.info("Started embedded server on port " + port);
        server = startedServer;
    } else {
        LOG.error("Unable to start request handler");
        server = null;
    }
}